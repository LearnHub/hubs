# AVN Cloud Connect Client

A TypeScript client library for accessing AVN Cloud Connect services. Provides support for both Node.js and standalone browser environments.

## Installation

This package is currently private and not published to npm. To use it in your project:

### Using npm link (for local development)

```bash
# In the connect-client directory
npm run pack
npm link

# In your project directory
npm link @avn/connect-client
```

### Using file path (for local projects)

```bash
# In your project's package.json, add:
{
  "dependencies": {
    "@avn/connect-client": "file:../path/to/connect-client"
  }
}
```

## Usage

```typescript
import {
  PB,
  Avnfs,
  MediaUtils,
  CryptoUtils,
  ConsoleUtils,
  HttpUtils,
  Utils
} from '@avn/connect-client';

// Use the client services
// Example usage here
```

## Development

### Building

```bash
# Clean build artifacts
npm run clean

# Build Node.js version (unbundled, external dependencies)
npm run build:node

# Build browser bundle (bundled with all dependencies)
npm run build:browser

# Build both Node.js and browser versions
npm run build

# Generate TypeScript from protobuf files
npm run build:buf

# Complete build process (clean, generate protobuf, build both versions)
npm run pack
```

### Protobuf

The `build:buf` script generates TypeScript from the protobuf files in the root folder.

### Package Output

The package now supports **dual builds** for maximum compatibility:

- **Node.js** (`dist/`):
  - Built with `tsc`
  - Dependencies remain external (not bundled)
  - Dynamic imports for Node.js modules (`crypto`, `fs`, `stream`) work normally
  - Used automatically when imported in Node.js environments

- **Browser** (`pack/`):
  - Built with `microbundle`
  - All dependencies bundled into a single file
  - Node.js modules (`crypto`, `fs`, `stream`) are shimmed to `undefined`
  - Used automatically when imported in browser environments via bundlers (webpack, esbuild, etc.)

The package.json `exports` field ensures the correct version is used automatically based on the environment.

### Local Deployment

Update installation for ClassConnect Server project and lambda transforms:

```bash
npm run copy
```

This will copy the built package to various dependent projects in the LearnHub workspace

### Unit testing with Vitest

Vitest is an better version of Jest: https://vitest.dev/guide/

[Vitest VS Code extension](https://github.com/vitest-dev/vscode) works best if the project is in it's own workspace so it can read the .vscode/launch.json file.

## Notes

Bundling for standalone browser https://github.com/developit/microbundle/issues/633