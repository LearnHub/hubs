import { Interceptor, Client } from '@connectrpc/connect';
import { GenMessage, GenFile, GenEnum, GenService, GenExtension } from '@bufbuild/protobuf/codegenv2';
import { Timestamp, EmptySchema, FieldOptions } from '@bufbuild/protobuf/wkt';
import * as wkt from '@bufbuild/protobuf/wkt';
export { wkt as BufWkt };
import { Message, JsonObject } from '@bufbuild/protobuf';
import * as protobuf from '@bufbuild/protobuf';
export { protobuf as Buf };

/**
 * Describes the file avn/connect/v1/interaction_permissions.proto.
 */
declare const file_avn_connect_v1_interaction_permissions: GenFile;
/**
 * @generated from message avn.connect.v1.InteractionPermissions
 */
type InteractionPermissions = Message<"avn.connect.v1.InteractionPermissions"> & {
    /**
     * Should the BACK button be enabled?
     *
     * @generated from field: bool allow_back = 1;
     */
    allowBack: boolean;
    /**
     * Can the user select a new scene?
     *
     * @generated from field: bool allow_explore = 2;
     */
    allowExplore: boolean;
    /**
     * Can the user follow links between rooms?
     *
     * @generated from field: bool allow_navigation = 3;
     */
    allowNavigation: boolean;
    /**
     * Can the user invite others?
     *
     * @generated from field: bool allow_invite = 10;
     */
    allowInvite: boolean;
    /**
     * Can the user issue hall passes?
     *
     * @generated from field: bool allow_pass = 11;
     */
    allowPass: boolean;
    /**
     * Can the user change their avatar?
     *
     * @generated from field: bool allow_change_avatar = 12;
     */
    allowChangeAvatar: boolean;
    /**
     * Should the teacher notes be shown?
     *
     * @generated from field: bool allow_teacher_notes = 13;
     */
    allowTeacherNotes: boolean;
    /**
     * Should the student notes be shown?
     *
     * @generated from field: bool allow_student_notes = 14;
     */
    allowStudentNotes: boolean;
    /**
     * Should the list of people in the room be visible?
     *
     * @generated from field: bool allow_people_menu = 15;
     */
    allowPeopleMenu: boolean;
    /**
     * Can the user change lesson focus?
     *
     * @generated from field: bool allow_focus = 20;
     */
    allowFocus: boolean;
    /**
     * Can the user mute everyone?
     *
     * @generated from field: bool allow_mute = 21;
     */
    allowMute: boolean;
    /**
     * Can the user send messages to every room in the dimension?
     *
     * @generated from field: bool allow_broadcast = 22;
     */
    allowBroadcast: boolean;
    /**
     * Is VoIP enabled?
     *
     * @generated from field: bool allow_voip = 31;
     */
    allowVoip: boolean;
    /**
     * Is text chat enabled?
     *
     * @generated from field: bool allow_text = 32;
     */
    allowText: boolean;
    /**
     * Can user move media?
     *
     * @generated from field: bool allow_move_media = 33;
     */
    allowMoveMedia: boolean;
    /**
     * Can user pin media?
     *
     * @generated from field: bool allow_pin_media = 34;
     */
    allowPinMedia: boolean;
    /**
     * Can user show reactions?
     *
     * @generated from field: bool allow_react = 35;
     */
    allowReact: boolean;
    /**
     * Can user share upload media to a room?
     *
     * @generated from field: bool allow_share_media = 36;
     */
    allowShareMedia: boolean;
    /**
     * Can user share their screen?
     *
     * @generated from field: bool allow_share_screen = 37;
     */
    allowShareScreen: boolean;
    /**
     * Can user fly?
     *
     * @generated from field: bool allow_fly = 38;
     */
    allowFly: boolean;
    /**
     * Can user write with the pen tool?
     *
     * @generated from field: bool allow_pen = 39;
     */
    allowPen: boolean;
};
/**
 * Describes the message avn.connect.v1.InteractionPermissions.
 * Use `create(InteractionPermissionsSchema)` to create a new message.
 */
declare const InteractionPermissionsSchema: GenMessage<InteractionPermissions>;

/**
 * Describes the file avn/connect/v1/features.proto.
 */
declare const file_avn_connect_v1_features: GenFile;
/**
 * @generated from message avn.connect.v1.UserInterfaceFeatures
 */
type UserInterfaceFeatures = Message<"avn.connect.v1.UserInterfaceFeatures"> & {
    /**
     * @generated from field: bool show_navbar = 1;
     */
    showNavbar: boolean;
    /**
     * @generated from field: bool show_sidebar = 2;
     */
    showSidebar: boolean;
    /**
     * @generated from field: bool show_room_entry_flow = 3;
     */
    showRoomEntryFlow: boolean;
    /**
     * @generated from field: bool show_teacher_notes = 10;
     */
    showTeacherNotes: boolean;
    /**
     * @generated from field: bool show_student_notes = 11;
     */
    showStudentNotes: boolean;
    /**
     * @generated from field: bool show_sign_in = 12;
     */
    showSignIn: boolean;
    /**
     * @generated from field: bool show_change_avatar = 13;
     */
    showChangeAvatar: boolean;
    /**
     * @generated from field: bool show_invite = 14;
     */
    showInvite: boolean;
    /**
     * @generated from field: bool show_pass = 15;
     */
    showPass: boolean;
    /**
     * @generated from field: bool show_object_list = 16;
     */
    showObjectList: boolean;
    /**
     * @generated from field: bool show_camera = 17;
     */
    showCamera: boolean;
    /**
     * @generated from field: bool show_photo = 18;
     */
    showPhoto: boolean;
    /**
     * @generated from field: bool show_voip = 19;
     */
    showVoip: boolean;
    /**
     * @generated from field: bool show_text = 20;
     */
    showText: boolean;
    /**
     * @generated from field: bool show_people_menu = 21;
     */
    showPeopleMenu: boolean;
    /**
     * @generated from field: bool show_account_info = 22;
     */
    showAccountInfo: boolean;
    /**
     * @generated from field: bool show_dimension_info = 23;
     */
    showDimensionInfo: boolean;
    /**
     * @generated from field: bool show_device_qr_invite = 24;
     */
    showDeviceQrInvite: boolean;
    /**
     * @generated from field: bool show_focus = 30;
     */
    showFocus: boolean;
    /**
     * @generated from field: bool show_mute = 31;
     */
    showMute: boolean;
    /**
     * @generated from field: bool show_analytics = 32;
     */
    showAnalytics: boolean;
    /**
     * @generated from field: bool show_start_tour = 33;
     */
    showStartTour: boolean;
};
/**
 * Describes the message avn.connect.v1.UserInterfaceFeatures.
 * Use `create(UserInterfaceFeaturesSchema)` to create a new message.
 */
declare const UserInterfaceFeaturesSchema: GenMessage<UserInterfaceFeatures>;
/**
 * @generated from message avn.connect.v1.AvailableContent
 */
type AvailableContent = Message<"avn.connect.v1.AvailableContent"> & {
    /**
     * Hint of what channels should be shown for browsing (POSSIBLY DEPRECATED AS SHOULD BE FILTERED BY CLIENT)
     *
     * @generated from field: repeated int32 browsable_channels = 1;
     */
    browsableChannels: number[];
    /**
     * Published content from these channels is available
     *
     * @generated from field: repeated int32 licensed_channels = 2;
     */
    licensedChannels: number[];
    /**
     * Available features by custom SKU ID
     *
     * @generated from field: repeated int32 licensed_features = 3;
     */
    licensedFeatures: number[];
    /**
     * Published content in these categories is available
     *
     * @generated from field: repeated int32 licensed_categories = 4;
     */
    licensedCategories: number[];
    /**
     * Published content owned by these channels is available
     *
     * @generated from field: repeated int32 permitted_channels = 5;
     */
    permittedChannels: number[];
};
/**
 * Describes the message avn.connect.v1.AvailableContent.
 * Use `create(AvailableContentSchema)` to create a new message.
 */
declare const AvailableContentSchema: GenMessage<AvailableContent>;

/**
 * Describes the file avn/connect/v1/user.proto.
 */
declare const file_avn_connect_v1_user: GenFile;
/**
 * Registered Eduverse user
 *
 * @generated from message avn.connect.v1.User
 */
type User = Message<"avn.connect.v1.User"> & {
    /**
     * User ID
     *
     * @generated from field: int32 user_id = 1;
     */
    userId: number;
    /**
     * User email address
     *
     * @generated from field: string email = 2;
     */
    email: string;
    /**
     * User display name
     *
     * @generated from field: string name = 3;
     */
    name: string;
    /**
     * User country (ISO 3166-1 alpha-2)
     *
     * @generated from field: string country_id = 4;
     */
    countryId: string;
    /**
     * User's preferred display language (IETF BCP 47)
     *
     * @generated from field: string language_id = 5;
     */
    languageId: string;
    /**
     * Is this user deleted?
     *
     * @generated from field: bool deleted = 6;
     */
    deleted: boolean;
    /**
     * Is the user's email address verified?
     *
     * @generated from field: optional bool email_verified = 10;
     */
    emailVerified?: boolean;
    /**
     * Picture of user
     *
     * @generated from field: optional string picture_url = 11;
     */
    pictureUrl?: string;
    /**
     * User's phone number
     *
     * @generated from field: optional string phone = 12;
     */
    phone?: string;
    /**
     * When user first signed into an Eduverse portal
     *
     * @generated from field: optional google.protobuf.Timestamp first_login = 13;
     */
    firstLogin?: Timestamp;
    /**
     * When user last signed into an Eduverse portal
     *
     * @generated from field: optional google.protobuf.Timestamp last_login = 14;
     */
    lastLogin?: Timestamp;
    /**
     * Languages that the user is allowed to translate
     *
     * @generated from field: repeated string translation_ids = 15;
     */
    translationIds: string[];
};
/**
 * Describes the message avn.connect.v1.User.
 * Use `create(UserSchema)` to create a new message.
 */
declare const UserSchema: GenMessage<User>;

/**
 * Describes the file avn/connect/v1/credentials.proto.
 */
declare const file_avn_connect_v1_credentials: GenFile;
/**
 * @generated from message avn.connect.v1.ConnectionInstance
 */
type ConnectionInstance = Message<"avn.connect.v1.ConnectionInstance"> & {
    /**
     * Dimension connection credentials
     *
     * @generated from field: avn.connect.v1.ConnectionCredentials credentials = 1;
     */
    credentials?: ConnectionCredentials;
    /**
     * Client ID
     *
     * @generated from field: string client_id = 2;
     */
    clientId: string;
    /**
     * Eduverse user (if authenticated)
     *
     * @generated from field: optional avn.connect.v1.User user = 3;
     */
    user?: User;
    /**
     * Dimension status and permissions
     *
     * @generated from field: avn.connect.v1.ConnectionStatus status = 6;
     */
    status: ConnectionStatus;
    /**
     * Content available though this dimension
     *
     * @generated from field: avn.connect.v1.AvailableContent content = 7;
     */
    content?: AvailableContent;
    /**
     * User-specific permissions within this dimension
     *
     * @generated from field: avn.connect.v1.InteractionPermissions permissions = 8;
     */
    permissions?: InteractionPermissions;
    /**
     * Recommended user interface features for this use
     *
     * @generated from field: avn.connect.v1.UserInterfaceFeatures features = 9;
     */
    features?: UserInterfaceFeatures;
};
/**
 * Describes the message avn.connect.v1.ConnectionInstance.
 * Use `create(ConnectionInstanceSchema)` to create a new message.
 */
declare const ConnectionInstanceSchema: GenMessage<ConnectionInstance>;
/**
 * ConnectionCredentials are disposable credentials issued when a user joins a dimension
 *
 * @generated from message avn.connect.v1.ConnectionCredentials
 */
type ConnectionCredentials = Message<"avn.connect.v1.ConnectionCredentials"> & {
    /**
     * Unqiue connection ID
     *
     * @generated from field: string connection_id = 1;
     */
    connectionId: string;
    /**
     * Connection secret for authentication
     *
     * @generated from field: string connection_secret = 2;
     */
    connectionSecret: string;
    /**
     * ID of the dimension joined
     *
     * @generated from field: string dimension_id = 3;
     */
    dimensionId: string;
};
/**
 * Describes the message avn.connect.v1.ConnectionCredentials.
 * Use `create(ConnectionCredentialsSchema)` to create a new message.
 */
declare const ConnectionCredentialsSchema: GenMessage<ConnectionCredentials>;
/**
 * Clients are disposable credentials for tracking and to provide the lowest form of authentication
 *
 * @generated from message avn.connect.v1.ClientCredentials
 */
type ClientCredentials = Message<"avn.connect.v1.ClientCredentials"> & {
    /**
     * Unique ID of client
     *
     * @generated from field: string client_id = 1;
     */
    clientId: string;
    /**
     * Private client secret for authentication
     *
     * @generated from field: optional string client_secret = 2;
     */
    clientSecret?: string;
};
/**
 * Describes the message avn.connect.v1.ClientCredentials.
 * Use `create(ClientCredentialsSchema)` to create a new message.
 */
declare const ClientCredentialsSchema: GenMessage<ClientCredentials>;
/**
 * @generated from enum avn.connect.v1.ConnectionStatus
 */
declare enum ConnectionStatus {
    /**
     * @generated from enum value: CONNECTION_STATUS_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Connection is not authenticated
     *
     * @generated from enum value: CONNECTION_STATUS_ANONYMOUS = 1;
     */
    ANONYMOUS = 1,
    /**
     * Connection is authenticated
     *
     * @generated from enum value: CONNECTION_STATUS_AUTHENTICATED = 2;
     */
    AUTHENTICATED = 2,
    /**
     * Connection is an administrator of this dimension
     *
     * @generated from enum value: CONNECTION_STATUS_ADMIN = 3;
     */
    ADMIN = 3,
    /**
     * Connection is the owner of this dimension
     *
     * @generated from enum value: CONNECTION_STATUS_OWNER = 4;
     */
    OWNER = 4
}
/**
 * Describes the enum avn.connect.v1.ConnectionStatus.
 */
declare const ConnectionStatusSchema: GenEnum<ConnectionStatus>;

/**
 * Describes the file avn/connect/v1/authorization.proto.
 */
declare const file_avn_connect_v1_authorization: GenFile;
/**
 * Authorization to content and services from one or more sources
 *
 * @generated from message avn.connect.v1.Authorization
 */
type Authorization = Message<"avn.connect.v1.Authorization"> & {
    /**
     * The OpenID JWT of the authenticated user
     *
     * @generated from field: optional string user_jwt = 1;
     */
    userJwt?: string;
    /**
     * Dimensions have intrinsic authorization parameters
     *
     * @generated from field: optional string dimension_id = 2;
     */
    dimensionId?: string;
    /**
     * The dimension connection credentials
     *
     * @generated from field: optional avn.connect.v1.ConnectionCredentials connection_credentials = 3;
     */
    connectionCredentials?: ConnectionCredentials;
    /**
     * API key used exlusively for CC1 legacy access
     *
     * @generated from field: optional string user_api_key = 4;
     */
    userApiKey?: string;
    /**
     * JWT for a device
     *
     * @generated from field: optional string device_jwt = 5;
     */
    deviceJwt?: string;
    /**
     * Hall passes can grant content access
     *
     * @generated from field: optional string pass_id = 6;
     */
    passId?: string;
    /**
     * Simple client credentials
     *
     * @generated from field: optional avn.connect.v1.ClientCredentials client_credentials = 7;
     */
    clientCredentials?: ClientCredentials;
};
/**
 * Describes the message avn.connect.v1.Authorization.
 * Use `create(AuthorizationSchema)` to create a new message.
 */
declare const AuthorizationSchema: GenMessage<Authorization>;
/**
 * Utility message for services that only required authorization
 *
 * @generated from message avn.connect.v1.AuthOnlyRequest
 */
type AuthOnlyRequest = Message<"avn.connect.v1.AuthOnlyRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
};
/**
 * Describes the message avn.connect.v1.AuthOnlyRequest.
 * Use `create(AuthOnlyRequestSchema)` to create a new message.
 */
declare const AuthOnlyRequestSchema: GenMessage<AuthOnlyRequest>;
/**
 * @generated from enum avn.connect.v1.IdentityProvider
 */
declare enum IdentityProvider {
    /**
     * @generated from enum value: IDENTITY_PROVIDER_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: IDENTITY_PROVIDER_ANONYMOUS = 1;
     */
    ANONYMOUS = 1,
    /**
     * @generated from enum value: IDENTITY_PROVIDER_CLASSCONNECT = 2;
     */
    CLASSCONNECT = 2,
    /**
     * @generated from enum value: IDENTITY_PROVIDER_GOOGLE = 3;
     */
    GOOGLE = 3,
    /**
     * @generated from enum value: IDENTITY_PROVIDER_MICROSOFT = 4;
     */
    MICROSOFT = 4,
    /**
     * @generated from enum value: IDENTITY_PROVIDER_CLEVER = 5;
     */
    CLEVER = 5,
    /**
     * @generated from enum value: IDENTITY_PROVIDER_CLASSLINK = 6;
     */
    CLASSLINK = 6
}
/**
 * Describes the enum avn.connect.v1.IdentityProvider.
 */
declare const IdentityProviderSchema: GenEnum<IdentityProvider>;

/**
 * Describes the file avn/connect/v1/operations.proto.
 */
declare const file_avn_connect_v1_operations: GenFile;
/**
 * A long-running operation. Services whose work may outlast a single request
 * (slow model inference, media generation) run it as a durable job behind a
 * single RPC: the request carries a `phase` oneof, where a first call sets the
 * service's task payload to submit the work and subsequent calls set `job_id`
 * to poll it (e.g. MediaService.TranscodeVideo). Every call waits up to
 * `wait_seconds` for a terminal state and returns this envelope on the
 * service's own response message, which also carries the typed result once the
 * state is COMPLETE. Job state is held in a durable store so any server
 * instance can answer a poll.
 *
 * Terminal states: COMPLETE, SUCCESS, ERROR, CANCELED, FORBIDDEN, NOT_FOUND, EXPIRED.
 *
 * @generated from message avn.connect.v1.Job
 */
type Job = Message<"avn.connect.v1.Job"> & {
    /**
     * Opaque identifier used to poll for completion.
     *
     * @generated from field: string id = 1;
     */
    id: string;
    /**
     * Current state of the operation.
     *
     * @generated from field: avn.connect.v1.OperationState state = 2;
     */
    state: OperationState;
    /**
     * Normalized progress 0.0-1.0, when the operation can report it.
     *
     * @generated from field: optional float progress = 3;
     */
    progress?: number;
    /**
     * Human-readable status or error detail.
     *
     * @generated from field: optional string detail = 4;
     */
    detail?: string;
    /**
     * When the job last changed. For a non-terminal job a stale `updated` is a hint
     * that the worker may have died — callers can use it to judge liveness.
     *
     * @generated from field: google.protobuf.Timestamp updated = 5;
     */
    updated?: Timestamp;
    /**
     * When the job was submitted. Never changes once set, so `updated` - `created`
     * gives the elapsed run time. Unset on a synthesized NOT_FOUND envelope, where
     * there is no record to have created.
     *
     * @generated from field: google.protobuf.Timestamp created = 6;
     */
    created?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.Job.
 * Use `create(JobSchema)` to create a new message.
 */
declare const JobSchema: GenMessage<Job>;
/**
 * Generic operation result
 *
 * @generated from enum avn.connect.v1.OperationState
 */
declare enum OperationState {
    /**
     * @generated from enum value: OPERATION_STATE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: OPERATION_STATE_OPEN = 1;
     */
    OPEN = 1,
    /**
     * @generated from enum value: OPERATION_STATE_CLOSED = 2;
     */
    CLOSED = 2,
    /**
     * @generated from enum value: OPERATION_STATE_NOT_FOUND = 3;
     */
    NOT_FOUND = 3,
    /**
     * @generated from enum value: OPERATION_STATE_FORBIDDEN = 4;
     */
    FORBIDDEN = 4,
    /**
     * @generated from enum value: OPERATION_STATE_EXPIRED = 5;
     */
    EXPIRED = 5,
    /**
     * @generated from enum value: OPERATION_STATE_PROCESSING = 6;
     */
    PROCESSING = 6,
    /**
     * @generated from enum value: OPERATION_STATE_SUCCESS = 7;
     */
    SUCCESS = 7,
    /**
     * @generated from enum value: OPERATION_STATE_CANCELED = 8;
     */
    CANCELED = 8,
    /**
     * @generated from enum value: OPERATION_STATE_TOO_MANY_REQUESTS = 9;
     */
    TOO_MANY_REQUESTS = 9,
    /**
     * @generated from enum value: OPERATION_STATE_ERROR = 10;
     */
    ERROR = 10,
    /**
     * @generated from enum value: OPERATION_STATE_QUEUED = 11;
     */
    QUEUED = 11,
    /**
     * @generated from enum value: OPERATION_STATE_TRANSCODING = 12;
     */
    TRANSCODING = 12,
    /**
     * @generated from enum value: OPERATION_STATE_TRANSFERRING = 13;
     */
    TRANSFERRING = 13,
    /**
     * @generated from enum value: OPERATION_STATE_COMPLETE = 14;
     */
    COMPLETE = 14,
    /**
     * @generated from enum value: OPERATION_STATE_INITIALIZING = 15;
     */
    INITIALIZING = 15
}
/**
 * Describes the enum avn.connect.v1.OperationState.
 */
declare const OperationStateSchema: GenEnum<OperationState>;

/**
 * Describes the file avn/connect/v1/media.proto.
 */
declare const file_avn_connect_v1_media: GenFile;
/**
 * @generated from message avn.connect.v1.GetPreviewImageRequest
 */
type GetPreviewImageRequest = Message<"avn.connect.v1.GetPreviewImageRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * AVNFS input URL
     *
     * @generated from field: string media_url = 2;
     */
    mediaUrl: string;
};
/**
 * Describes the message avn.connect.v1.GetPreviewImageRequest.
 * Use `create(GetPreviewImageRequestSchema)` to create a new message.
 */
declare const GetPreviewImageRequestSchema: GenMessage<GetPreviewImageRequest>;
/**
 * @generated from message avn.connect.v1.GetPreviewImageResponse
 */
type GetPreviewImageResponse = Message<"avn.connect.v1.GetPreviewImageResponse"> & {
    /**
     * AVNFS output URL or unset if no preview could be created for the given file
     *
     * @generated from field: optional string media_url = 1;
     */
    mediaUrl?: string;
};
/**
 * Describes the message avn.connect.v1.GetPreviewImageResponse.
 * Use `create(GetPreviewImageResponseSchema)` to create a new message.
 */
declare const GetPreviewImageResponseSchema: GenMessage<GetPreviewImageResponse>;
/**
 * @generated from message avn.connect.v1.GetMetadataRequest
 */
type GetMetadataRequest = Message<"avn.connect.v1.GetMetadataRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * AVNFS input URL
     *
     * @generated from field: string media_url = 2;
     */
    mediaUrl: string;
};
/**
 * Describes the message avn.connect.v1.GetMetadataRequest.
 * Use `create(GetMetadataRequestSchema)` to create a new message.
 */
declare const GetMetadataRequestSchema: GenMessage<GetMetadataRequest>;
/**
 * @generated from message avn.connect.v1.GetImageMetadataResponse
 */
type GetImageMetadataResponse = Message<"avn.connect.v1.GetImageMetadataResponse"> & {
    /**
     * Width
     *
     * @generated from field: float width = 1;
     */
    width: number;
    /**
     * Height
     *
     * @generated from field: float height = 2;
     */
    height: number;
    /**
     * Media type
     *
     * @generated from field: string media_type = 3;
     */
    mediaType: string;
    /**
     * Width of image. One of: in,mm,cm,pt,pc,px,em,ex
     *
     * @generated from field: string width_units = 4;
     */
    widthUnits: string;
    /**
     * Height of image. One of: in,mm,cm,pt,pc,px,em,ex
     *
     * @generated from field: string height_units = 5;
     */
    heightUnits: string;
    /**
     * Orientation of image
     *
     * @generated from field: optional int32 orientation = 6;
     */
    orientation?: number;
};
/**
 * Describes the message avn.connect.v1.GetImageMetadataResponse.
 * Use `create(GetImageMetadataResponseSchema)` to create a new message.
 */
declare const GetImageMetadataResponseSchema: GenMessage<GetImageMetadataResponse>;
/**
 * Rational ratio type used for media frame timing
 *
 * @generated from message avn.connect.v1.MediaRational
 */
type MediaRational = Message<"avn.connect.v1.MediaRational"> & {
    /**
     * Ratio numerator
     *
     * @generated from field: int32 num = 1;
     */
    num: number;
    /**
     * Ratio denominator
     *
     * @generated from field: int32 den = 2;
     */
    den: number;
};
/**
 * Describes the message avn.connect.v1.MediaRational.
 * Use `create(MediaRationalSchema)` to create a new message.
 */
declare const MediaRationalSchema: GenMessage<MediaRational>;
/**
 * @generated from message avn.connect.v1.MediaStreamMetadata
 */
type MediaStreamMetadata = Message<"avn.connect.v1.MediaStreamMetadata"> & {
    /**
     * Format-specific stream ID
     *
     * @generated from field: string id = 1;
     */
    id: string;
    /**
     * General type of the encoded data
     *
     * @generated from field: avn.connect.v1.MediaStreamType stream_type = 2;
     */
    streamType: MediaStreamType;
    /**
     * Is this the default stream of this type? (typically parsed from disposition)
     *
     * @generated from field: bool is_default = 3;
     */
    isDefault: boolean;
    /**
     * One of: hvc1, hev1, avc1, mp4a
     *
     * @generated from field: string codec_tag = 4;
     */
    codecTag: string;
    /**
     * One of: h264, hevc, mp3, aac
     *
     * @generated from field: string codec_name = 5;
     */
    codecName: string;
    /**
     * Codec display name
     *
     * @generated from field: string codec_display_name = 6;
     */
    codecDisplayName: string;
    /**
     * Stream duration
     *
     * @generated from field: float duration_seconds = 7;
     */
    durationSeconds: number;
    /**
     * The fundamental unit of time (in seconds) in terms of which frame timestamps are represented
     *
     * @generated from field: avn.connect.v1.MediaRational time_base = 8;
     */
    timeBase?: MediaRational;
    /**
     * Real base frame rate of the stream (in variable frame rate streams, this is the fastest rate to expect)
     *
     * @generated from field: avn.connect.v1.MediaRational real_base_framerate = 9;
     */
    realBaseFramerate?: MediaRational;
    /**
     * Average frame rate of the stream
     *
     * @generated from field: avn.connect.v1.MediaRational average_framerate = 10;
     */
    averageFramerate?: MediaRational;
    /**
     * The average bitrate of the encoded data (in bits per second)
     *
     * @generated from field: int64 bitrate_bits_per_second = 11;
     */
    bitrateBitsPerSecond: bigint;
    /**
     * Number of frames in this stream (if known)
     *
     * @generated from field: optional int64 frame_count = 12;
     */
    frameCount?: bigint;
    /**
     * Video width
     *
     * @generated from field: optional int32 width_pixels = 13;
     */
    widthPixels?: number;
    /**
     * Video height
     *
     * @generated from field: optional int32 height_pixels = 14;
     */
    heightPixels?: number;
    /**
     * Video sample aspect ratio
     *
     * @generated from field: optional avn.connect.v1.MediaRational sample_aspect_ratio = 15;
     */
    sampleAspectRatio?: MediaRational;
    /**
     * Video display aspect ratio
     *
     * @generated from field: optional avn.connect.v1.MediaRational display_aspect_ratio = 16;
     */
    displayAspectRatio?: MediaRational;
    /**
     * Video pixel format
     *
     * @generated from field: optional string pixel_format = 17;
     */
    pixelFormat?: string;
    /**
     * Audio sample rate
     *
     * @generated from field: optional int32 sample_rate_hertz = 18;
     */
    sampleRateHertz?: number;
    /**
     * Audio channel count
     *
     * @generated from field: optional int32 channel_count = 19;
     */
    channelCount?: number;
    /**
     * Audio channel layout
     *
     * @generated from field: optional string channel_layout = 20;
     */
    channelLayout?: string;
    /**
     * Display directives such as "default", "dub", "captions", etc...
     *
     * @generated from field: repeated string dispositions = 21;
     */
    dispositions: string[];
    /**
     * Additional metadata
     *
     * @generated from field: map<string, string> tags = 22;
     */
    tags: {
        [key: string]: string;
    };
};
/**
 * Describes the message avn.connect.v1.MediaStreamMetadata.
 * Use `create(MediaStreamMetadataSchema)` to create a new message.
 */
declare const MediaStreamMetadataSchema: GenMessage<MediaStreamMetadata>;
/**
 * @generated from message avn.connect.v1.MediaFormatMetadata
 */
type MediaFormatMetadata = Message<"avn.connect.v1.MediaFormatMetadata"> & {
    /**
     * Container information (may include synonyms such as mov, mp4, m4a, 3gp, 3g2, mj2)
     *
     * @generated from field: repeated string container_formats = 1;
     */
    containerFormats: string[];
    /**
     * @generated from field: string container_display_name = 2;
     */
    containerDisplayName: string;
    /**
     * Overall duration (not all files populate the duration field)
     *
     * @generated from field: optional float duration_seconds = 3;
     */
    durationSeconds?: number;
    /**
     * Total size
     *
     * @generated from field: int64 size_bytes = 4;
     */
    sizeBytes: bigint;
    /**
     * Estimated average bitrate (not all files populate the bitrate field)
     *
     * @generated from field: optional int64 bitrate_bits_per_second = 5;
     */
    bitrateBitsPerSecond?: bigint;
    /**
     * Additional metadata
     *
     * @generated from field: map<string, string> tags = 6;
     */
    tags: {
        [key: string]: string;
    };
};
/**
 * Describes the message avn.connect.v1.MediaFormatMetadata.
 * Use `create(MediaFormatMetadataSchema)` to create a new message.
 */
declare const MediaFormatMetadataSchema: GenMessage<MediaFormatMetadata>;
/**
 * @generated from message avn.connect.v1.GetVideoMetadataResponse
 */
type GetVideoMetadataResponse = Message<"avn.connect.v1.GetVideoMetadataResponse"> & {
    /**
     * Format of video
     *
     * @generated from field: avn.connect.v1.MediaFormatMetadata format = 1;
     */
    format?: MediaFormatMetadata;
    /**
     * Streams within the media container
     *
     * @generated from field: repeated avn.connect.v1.MediaStreamMetadata streams = 2;
     */
    streams: MediaStreamMetadata[];
};
/**
 * Describes the message avn.connect.v1.GetVideoMetadataResponse.
 * Use `create(GetVideoMetadataResponseSchema)` to create a new message.
 */
declare const GetVideoMetadataResponseSchema: GenMessage<GetVideoMetadataResponse>;
/**
 * @generated from message avn.connect.v1.TranscodeImageSpec
 */
type TranscodeImageSpec = Message<"avn.connect.v1.TranscodeImageSpec"> & {
    /**
     * Maximum height or width in pixels
     * Must be one of 8, 16, 32, 64, 128, 256, 512, 1024, or 2048
     * -1 indicates that the original image should be returned
     * image/svg+xml inputs are returned unchanged regardless of this value (no rasterization).
     *
     * @generated from field: int32 max_size_pixels = 1;
     */
    maxSizePixels: number;
};
/**
 * Describes the message avn.connect.v1.TranscodeImageSpec.
 * Use `create(TranscodeImageSpecSchema)` to create a new message.
 */
declare const TranscodeImageSpecSchema: GenMessage<TranscodeImageSpec>;
/**
 * @generated from message avn.connect.v1.TranscodeImageRequest
 */
type TranscodeImageRequest = Message<"avn.connect.v1.TranscodeImageRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * AVNFS input URL
     *
     * @generated from field: string media_url = 2;
     */
    mediaUrl: string;
    /**
     * Transcode instructions
     *
     * @generated from field: avn.connect.v1.TranscodeImageSpec transcode_spec = 3;
     */
    transcodeSpec?: TranscodeImageSpec;
};
/**
 * Describes the message avn.connect.v1.TranscodeImageRequest.
 * Use `create(TranscodeImageRequestSchema)` to create a new message.
 */
declare const TranscodeImageRequestSchema: GenMessage<TranscodeImageRequest>;
/**
 * @generated from message avn.connect.v1.TranscodeImageResponse
 */
type TranscodeImageResponse = Message<"avn.connect.v1.TranscodeImageResponse"> & {
    /**
     * AVNFS output URL
     *
     * @generated from field: string media_url = 1;
     */
    mediaUrl: string;
};
/**
 * Describes the message avn.connect.v1.TranscodeImageResponse.
 * Use `create(TranscodeImageResponseSchema)` to create a new message.
 */
declare const TranscodeImageResponseSchema: GenMessage<TranscodeImageResponse>;
/**
 * @generated from message avn.connect.v1.MediaFormatSpec
 */
type MediaFormatSpec = Message<"avn.connect.v1.MediaFormatSpec"> & {
    /**
     * @generated from field: string codec_name = 1;
     */
    codecName: string;
    /**
     * Supported tags such as hvc1 or hev1 (empty implies that all stream types supported)
     *
     * @generated from field: repeated string supported_codec_tags = 2;
     */
    supportedCodecTags: string[];
    /**
     * Stream type to use this codec with
     *
     * @generated from field: avn.connect.v1.MediaStreamType stream_type = 3;
     */
    streamType: MediaStreamType;
    /**
     * Priority of this codec as a transcode target
     *
     * @generated from field: int32 priority = 4;
     */
    priority: number;
    /**
     * Max width in pixels
     *
     * @generated from field: optional int32 max_width_pixels = 5;
     */
    maxWidthPixels?: number;
    /**
     * Target width when transcoding
     *
     * @generated from field: optional int32 target_width_pixels = 6;
     */
    targetWidthPixels?: number;
    /**
     * Max Height in pixels
     *
     * @generated from field: optional int32 max_height_pixels = 7;
     */
    maxHeightPixels?: number;
    /**
     * Target height when transcoding
     *
     * @generated from field: optional int32 target_height_pixels = 8;
     */
    targetHeightPixels?: number;
    /**
     * Supported pixel formats for video
     *
     * @generated from field: repeated string supported_pixel_formats = 9;
     */
    supportedPixelFormats: string[];
    /**
     * Max frame rate
     *
     * @generated from field: optional int32 max_framerate = 10;
     */
    maxFramerate?: number;
    /**
     * Max bitrate
     *
     * @generated from field: optional int64 max_bitrate_bits_per_second = 11;
     */
    maxBitrateBitsPerSecond?: bigint;
    /**
     * Target bitrate when transcoding
     *
     * @generated from field: optional int64 target_bitrate_bits_per_second = 12;
     */
    targetBitrateBitsPerSecond?: bigint;
    /**
     * Target quality when transcoding
     *
     * @generated from field: optional int32 target_quality_percent = 15;
     */
    targetQualityPercent?: number;
    /**
     * Max number of audio channels
     *
     * @generated from field: optional int32 max_audio_channels = 13;
     */
    maxAudioChannels?: number;
    /**
     * Max audio sample rate
     *
     * @generated from field: optional int32 max_sample_rate_hertz = 14;
     */
    maxSampleRateHertz?: number;
};
/**
 * Describes the message avn.connect.v1.MediaFormatSpec.
 * Use `create(MediaFormatSpecSchema)` to create a new message.
 */
declare const MediaFormatSpecSchema: GenMessage<MediaFormatSpec>;
/**
 * @generated from message avn.connect.v1.MediaDeviceSpec
 */
type MediaDeviceSpec = Message<"avn.connect.v1.MediaDeviceSpec"> & {
    /**
     * Media device ID
     *
     * @generated from field: string media_device_id = 1;
     */
    mediaDeviceId: string;
    /**
     * Media device display name
     *
     * @generated from field: string media_device_name = 2;
     */
    mediaDeviceName: string;
    /**
     * First container is the preferred option when transcoding
     *
     * @generated from field: repeated string supported_container_formats = 3;
     */
    supportedContainerFormats: string[];
    /**
     * Supported codecs by codec tag
     *
     * @generated from field: map<string, avn.connect.v1.MediaFormatSpec> supported_codecs = 4;
     */
    supportedCodecs: {
        [key: string]: MediaFormatSpec;
    };
};
/**
 * Describes the message avn.connect.v1.MediaDeviceSpec.
 * Use `create(MediaDeviceSpecSchema)` to create a new message.
 */
declare const MediaDeviceSpecSchema: GenMessage<MediaDeviceSpec>;
/**
 * The work itself: payload of a first (submitting) TranscodeVideo call.
 *
 * @generated from message avn.connect.v1.TranscodeVideoTask
 */
type TranscodeVideoTask = Message<"avn.connect.v1.TranscodeVideoTask"> & {
    /**
     * The media file to transcode
     *
     * @generated from field: string media_url = 1;
     */
    mediaUrl: string;
    /**
     * The target spec to transcode to
     *
     * @generated from field: avn.connect.v1.MediaDeviceSpec target_device_spec = 2;
     */
    targetDeviceSpec?: MediaDeviceSpec;
    /**
     * Force transcoding even if the media file is already on spec
     *
     * @generated from field: bool force_transcode = 3;
     */
    forceTranscode: boolean;
};
/**
 * Describes the message avn.connect.v1.TranscodeVideoTask.
 * Use `create(TranscodeVideoTaskSchema)` to create a new message.
 */
declare const TranscodeVideoTaskSchema: GenMessage<TranscodeVideoTask>;
/**
 * @generated from message avn.connect.v1.TranscodeVideoRequest
 */
type TranscodeVideoRequest = Message<"avn.connect.v1.TranscodeVideoRequest"> & {
    /**
     * Authorization for the request. Polls must come from the user that submitted
     * the task; other callers see NOT_FOUND.
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Seconds to wait inline for a terminal state before returning the current
     * state. Clamped server-side to a safe maximum; unset uses the server default
     * and 0 polls without blocking.
     *
     * @generated from field: optional float wait_seconds = 2;
     */
    waitSeconds?: number;
    /**
     * Exactly one of these must be set.
     *
     * @generated from oneof avn.connect.v1.TranscodeVideoRequest.phase
     */
    phase: {
        /**
         * First call: submit this work, creating the job returned in the response.
         *
         * @generated from field: avn.connect.v1.TranscodeVideoTask task = 3;
         */
        value: TranscodeVideoTask;
        case: "task";
    } | {
        /**
         * Subsequent calls: poll an earlier submission using its `job.id` from the
         * response envelope, until `job.state` is terminal.
         *
         * @generated from field: string job_id = 4;
         */
        value: string;
        case: "jobId";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message avn.connect.v1.TranscodeVideoRequest.
 * Use `create(TranscodeVideoRequestSchema)` to create a new message.
 */
declare const TranscodeVideoRequestSchema: GenMessage<TranscodeVideoRequest>;
/**
 * @generated from message avn.connect.v1.TranscodeVideoResponse
 */
type TranscodeVideoResponse = Message<"avn.connect.v1.TranscodeVideoResponse"> & {
    /**
     * Operation envelope. Poll `job.id` (via TranscodeVideoRequest.job_id) until
     * `job.state` is terminal (COMPLETE on success, ERROR on failure). Progress is
     * reported on `job.progress`.
     *
     * @generated from field: avn.connect.v1.Job job = 1;
     */
    job?: Job;
    /**
     * Only set when job.state == COMPLETE
     *
     * @generated from field: optional avn.connect.v1.TranscodeVideoResult result = 2;
     */
    result?: TranscodeVideoResult;
};
/**
 * Describes the message avn.connect.v1.TranscodeVideoResponse.
 * Use `create(TranscodeVideoResponseSchema)` to create a new message.
 */
declare const TranscodeVideoResponseSchema: GenMessage<TranscodeVideoResponse>;
/**
 * @generated from message avn.connect.v1.TranscodeVideoResult
 */
type TranscodeVideoResult = Message<"avn.connect.v1.TranscodeVideoResult"> & {
    /**
     * Set if the job succeeded
     *
     * @generated from field: optional string media_url = 1;
     */
    mediaUrl?: string;
    /**
     * Populated if there were transcode errors
     *
     * @generated from field: repeated string errors = 2;
     */
    errors: string[];
    /**
     * Populated if there were transcode warnings
     *
     * @generated from field: repeated string warnings = 3;
     */
    warnings: string[];
};
/**
 * Describes the message avn.connect.v1.TranscodeVideoResult.
 * Use `create(TranscodeVideoResultSchema)` to create a new message.
 */
declare const TranscodeVideoResultSchema: GenMessage<TranscodeVideoResult>;
/**
 * @generated from message avn.connect.v1.MediaTypeExtension
 */
type MediaTypeExtension = Message<"avn.connect.v1.MediaTypeExtension"> & {
    /**
     * Media file extension
     *
     * @generated from field: string extension = 1;
     */
    extension: string;
    /**
     * Media type
     *
     * @generated from field: string media_type = 2;
     */
    mediaType: string;
};
/**
 * Describes the message avn.connect.v1.MediaTypeExtension.
 * Use `create(MediaTypeExtensionSchema)` to create a new message.
 */
declare const MediaTypeExtensionSchema: GenMessage<MediaTypeExtension>;
/**
 * @generated from message avn.connect.v1.GetMediaTypeExtensionMapRequest
 */
type GetMediaTypeExtensionMapRequest = Message<"avn.connect.v1.GetMediaTypeExtensionMapRequest"> & {};
/**
 * Describes the message avn.connect.v1.GetMediaTypeExtensionMapRequest.
 * Use `create(GetMediaTypeExtensionMapRequestSchema)` to create a new message.
 */
declare const GetMediaTypeExtensionMapRequestSchema: GenMessage<GetMediaTypeExtensionMapRequest>;
/**
 * @generated from message avn.connect.v1.GetMediaTypeExtensionMapResponse
 */
type GetMediaTypeExtensionMapResponse = Message<"avn.connect.v1.GetMediaTypeExtensionMapResponse"> & {
    /**
     * Matching media types
     *
     * @generated from field: repeated avn.connect.v1.MediaTypeExtension media_types = 1;
     */
    mediaTypes: MediaTypeExtension[];
};
/**
 * Describes the message avn.connect.v1.GetMediaTypeExtensionMapResponse.
 * Use `create(GetMediaTypeExtensionMapResponseSchema)` to create a new message.
 */
declare const GetMediaTypeExtensionMapResponseSchema: GenMessage<GetMediaTypeExtensionMapResponse>;
/**
 * @generated from message avn.connect.v1.MediaCompatibilityIssue
 */
type MediaCompatibilityIssue = Message<"avn.connect.v1.MediaCompatibilityIssue"> & {
    /**
     * @generated from field: avn.connect.v1.MediaCompatibilityArea area = 1;
     */
    area: MediaCompatibilityArea;
    /**
     * @generated from field: avn.connect.v1.MediaCompatibilityReason reason = 2;
     */
    reason: MediaCompatibilityReason;
    /**
     * @generated from field: string detail = 3;
     */
    detail: string;
};
/**
 * Describes the message avn.connect.v1.MediaCompatibilityIssue.
 * Use `create(MediaCompatibilityIssueSchema)` to create a new message.
 */
declare const MediaCompatibilityIssueSchema: GenMessage<MediaCompatibilityIssue>;
/**
 * @generated from message avn.connect.v1.CheckMediaCompatibilityRequest
 */
type CheckMediaCompatibilityRequest = Message<"avn.connect.v1.CheckMediaCompatibilityRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: string media_url = 2;
     */
    mediaUrl: string;
    /**
     * @generated from field: avn.connect.v1.MediaDeviceSpec target_device_spec = 3;
     */
    targetDeviceSpec?: MediaDeviceSpec;
};
/**
 * Describes the message avn.connect.v1.CheckMediaCompatibilityRequest.
 * Use `create(CheckMediaCompatibilityRequestSchema)` to create a new message.
 */
declare const CheckMediaCompatibilityRequestSchema: GenMessage<CheckMediaCompatibilityRequest>;
/**
 * @generated from message avn.connect.v1.CheckMediaCompatibilityResponse
 */
type CheckMediaCompatibilityResponse = Message<"avn.connect.v1.CheckMediaCompatibilityResponse"> & {
    /**
     * @generated from field: bool container_is_supported = 1;
     */
    containerIsSupported: boolean;
    /**
     * @generated from field: bool video_stream_is_available = 2;
     */
    videoStreamIsAvailable: boolean;
    /**
     * @generated from field: bool video_stream_is_supported = 3;
     */
    videoStreamIsSupported: boolean;
    /**
     * @generated from field: bool audio_stream_is_available = 4;
     */
    audioStreamIsAvailable: boolean;
    /**
     * @generated from field: bool audio_stream_is_supported = 5;
     */
    audioStreamIsSupported: boolean;
    /**
     * @generated from field: repeated avn.connect.v1.MediaCompatibilityIssue errors = 6;
     */
    errors: MediaCompatibilityIssue[];
    /**
     * @generated from field: repeated avn.connect.v1.MediaCompatibilityIssue warnings = 7;
     */
    warnings: MediaCompatibilityIssue[];
};
/**
 * Describes the message avn.connect.v1.CheckMediaCompatibilityResponse.
 * Use `create(CheckMediaCompatibilityResponseSchema)` to create a new message.
 */
declare const CheckMediaCompatibilityResponseSchema: GenMessage<CheckMediaCompatibilityResponse>;
/**
 * @generated from message avn.connect.v1.GetMediaDeviceSpecsRequest
 */
type GetMediaDeviceSpecsRequest = Message<"avn.connect.v1.GetMediaDeviceSpecsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: repeated string media_device_ids = 2;
     */
    mediaDeviceIds: string[];
};
/**
 * Describes the message avn.connect.v1.GetMediaDeviceSpecsRequest.
 * Use `create(GetMediaDeviceSpecsRequestSchema)` to create a new message.
 */
declare const GetMediaDeviceSpecsRequestSchema: GenMessage<GetMediaDeviceSpecsRequest>;
/**
 * @generated from message avn.connect.v1.GetMediaDeviceSpecsResponse
 */
type GetMediaDeviceSpecsResponse = Message<"avn.connect.v1.GetMediaDeviceSpecsResponse"> & {
    /**
     * @generated from field: repeated avn.connect.v1.MediaDeviceSpec media_device_specs = 1;
     */
    mediaDeviceSpecs: MediaDeviceSpec[];
};
/**
 * Describes the message avn.connect.v1.GetMediaDeviceSpecsResponse.
 * Use `create(GetMediaDeviceSpecsResponseSchema)` to create a new message.
 */
declare const GetMediaDeviceSpecsResponseSchema: GenMessage<GetMediaDeviceSpecsResponse>;
/**
 * @generated from message avn.connect.v1.GetMediaSpectrumRequest
 */
type GetMediaSpectrumRequest = Message<"avn.connect.v1.GetMediaSpectrumRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: string media_url = 2;
     */
    mediaUrl: string;
    /**
     * Units Hz
     *
     * @generated from field: float sample_rate = 3;
     */
    sampleRate: number;
    /**
     * @generated from field: int32 frequency_bin_count = 4;
     */
    frequencyBinCount: number;
    /**
     * Units Hz
     *
     * @generated from field: float frequency_min = 5;
     */
    frequencyMin: number;
    /**
     * Units Hz
     *
     * @generated from field: float frequency_max = 6;
     */
    frequencyMax: number;
    /**
     * Units dBFS
     *
     * @generated from field: float volume_max = 7;
     */
    volumeMax: number;
};
/**
 * Describes the message avn.connect.v1.GetMediaSpectrumRequest.
 * Use `create(GetMediaSpectrumRequestSchema)` to create a new message.
 */
declare const GetMediaSpectrumRequestSchema: GenMessage<GetMediaSpectrumRequest>;
/**
 * @generated from message avn.connect.v1.GetMediaSpectrumResponse
 */
type GetMediaSpectrumResponse = Message<"avn.connect.v1.GetMediaSpectrumResponse"> & {
    /**
     * @generated from field: avn.connect.v1.MediaSpectrum media_spectrum = 1;
     */
    mediaSpectrum?: MediaSpectrum;
};
/**
 * Describes the message avn.connect.v1.GetMediaSpectrumResponse.
 * Use `create(GetMediaSpectrumResponseSchema)` to create a new message.
 */
declare const GetMediaSpectrumResponseSchema: GenMessage<GetMediaSpectrumResponse>;
/**
 * @generated from message avn.connect.v1.MediaSpectrum
 */
type MediaSpectrum = Message<"avn.connect.v1.MediaSpectrum"> & {
    /**
     * Units Hz
     *
     * @generated from field: float sample_rate = 1;
     */
    sampleRate: number;
    /**
     * @generated from field: int32 sample_count = 2;
     */
    sampleCount: number;
    /**
     * @generated from field: int32 frequency_bin_count = 3;
     */
    frequencyBinCount: number;
    /**
     * Units Hz
     *
     * @generated from field: float frequency_min = 4;
     */
    frequencyMin: number;
    /**
     * Units Hz
     *
     * @generated from field: float frequency_max = 5;
     */
    frequencyMax: number;
    /**
     * Units dBFS
     *
     * @generated from field: float volume_max = 6;
     */
    volumeMax: number;
    /**
     * File of frequency_bin_count x sample_count unsigned bytes representing the volume of the signal for each frequency and time
     *
     * @generated from field: string volume_data_url = 10;
     */
    volumeDataUrl: string;
};
/**
 * Describes the message avn.connect.v1.MediaSpectrum.
 * Use `create(MediaSpectrumSchema)` to create a new message.
 */
declare const MediaSpectrumSchema: GenMessage<MediaSpectrum>;
/**
 * Video stream types
 *
 * @generated from enum avn.connect.v1.MediaStreamType
 */
declare enum MediaStreamType {
    /**
     * @generated from enum value: MEDIA_STREAM_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: MEDIA_STREAM_TYPE_UNKNOWN = 1;
     */
    UNKNOWN = 1,
    /**
     * @generated from enum value: MEDIA_STREAM_TYPE_VIDEO = 2;
     */
    VIDEO = 2,
    /**
     * @generated from enum value: MEDIA_STREAM_TYPE_AUDIO = 3;
     */
    AUDIO = 3,
    /**
     * @generated from enum value: MEDIA_STREAM_TYPE_DATA = 4;
     */
    DATA = 4,
    /**
     * @generated from enum value: MEDIA_STREAM_TYPE_SUBTITLE = 5;
     */
    SUBTITLE = 5,
    /**
     * @generated from enum value: MEDIA_STREAM_TYPE_ATTACHMENT = 6;
     */
    ATTACHMENT = 6,
    /**
     * @generated from enum value: MEDIA_STREAM_TYPE_NB = 7;
     */
    NB = 7
}
/**
 * Describes the enum avn.connect.v1.MediaStreamType.
 */
declare const MediaStreamTypeSchema: GenEnum<MediaStreamType>;
/**
 * @generated from enum avn.connect.v1.MediaCompatibilityArea
 */
declare enum MediaCompatibilityArea {
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_AREA_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_AREA_CONTAINER = 1;
     */
    CONTAINER = 1,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_AREA_VIDEO_CODEC = 2;
     */
    VIDEO_CODEC = 2,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_AREA_AUDIO_CODEC = 3;
     */
    AUDIO_CODEC = 3,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_AREA_OTHER_CODEC = 4;
     */
    OTHER_CODEC = 4
}
/**
 * Describes the enum avn.connect.v1.MediaCompatibilityArea.
 */
declare const MediaCompatibilityAreaSchema: GenEnum<MediaCompatibilityArea>;
/**
 * @generated from enum avn.connect.v1.MediaCompatibilityReason
 */
declare enum MediaCompatibilityReason {
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Errors (incompatible)
     *
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_NOT_SUPPORTED = 1;
     */
    NOT_SUPPORTED = 1,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_MAX_PIXEL_WIDTH = 2;
     */
    MAX_PIXEL_WIDTH = 2,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_MAX_PIXEL_HEIGHT = 3;
     */
    MAX_PIXEL_HEIGHT = 3,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_PIXEL_FORMAT = 4;
     */
    PIXEL_FORMAT = 4,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_MAX_FRAMERATE = 5;
     */
    MAX_FRAMERATE = 5,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_MAX_BITRATE = 6;
     */
    MAX_BITRATE = 6,
    /**
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_CHANNEL_COUNT = 7;
     */
    CHANNEL_COUNT = 7,
    /**
     * Warnings (compatible, but exceeding target)
     *
     * @generated from enum value: MEDIA_COMPATIBILITY_REASON_TARGET_BITRATE = 8;
     */
    TARGET_BITRATE = 8
}
/**
 * Describes the enum avn.connect.v1.MediaCompatibilityReason.
 */
declare const MediaCompatibilityReasonSchema: GenEnum<MediaCompatibilityReason>;
/**
 * @generated from service avn.connect.v1.MediaService
 */
declare const MediaService: GenService<{
    /**
     * Create a summary image for the given media file
     *
     * @generated from rpc avn.connect.v1.MediaService.GetPreviewImage
     */
    getPreviewImage: {
        methodKind: "unary";
        input: typeof GetPreviewImageRequestSchema;
        output: typeof GetPreviewImageResponseSchema;
    };
    /**
     * Get image metadata
     *
     * @generated from rpc avn.connect.v1.MediaService.GetImageMetadata
     */
    getImageMetadata: {
        methodKind: "unary";
        input: typeof GetMetadataRequestSchema;
        output: typeof GetImageMetadataResponseSchema;
    };
    /**
     * Get video metadata
     *
     * @generated from rpc avn.connect.v1.MediaService.GetVideoMetadata
     */
    getVideoMetadata: {
        methodKind: "unary";
        input: typeof GetMetadataRequestSchema;
        output: typeof GetVideoMetadataResponseSchema;
    };
    /**
     * Check media compatibility with specific device profiles
     *
     * @generated from rpc avn.connect.v1.MediaService.CheckMediaCompatibility
     */
    checkMediaCompatibility: {
        methodKind: "unary";
        input: typeof CheckMediaCompatibilityRequestSchema;
        output: typeof CheckMediaCompatibilityResponseSchema;
    };
    /**
     * Transcode an image
     *
     * @generated from rpc avn.connect.v1.MediaService.TranscodeImage
     */
    transcodeImage: {
        methodKind: "unary";
        input: typeof TranscodeImageRequestSchema;
        output: typeof TranscodeImageResponseSchema;
    };
    /**
     * Transcode a video using the durable-job pattern (see Job in operations.proto)
     *
     * @generated from rpc avn.connect.v1.MediaService.TranscodeVideo
     */
    transcodeVideo: {
        methodKind: "unary";
        input: typeof TranscodeVideoRequestSchema;
        output: typeof TranscodeVideoResponseSchema;
    };
    /**
     * A mapping of well known file extensions to media types
     *
     * @generated from rpc avn.connect.v1.MediaService.GetMediaTypeExtensionMap
     */
    getMediaTypeExtensionMap: {
        methodKind: "unary";
        input: typeof GetMediaTypeExtensionMapRequestSchema;
        output: typeof GetMediaTypeExtensionMapResponseSchema;
    };
    /**
     * A mapping of recommended media specs for well known devices
     *
     * @generated from rpc avn.connect.v1.MediaService.GetMediaDeviceSpecs
     */
    getMediaDeviceSpecs: {
        methodKind: "unary";
        input: typeof GetMediaDeviceSpecsRequestSchema;
        output: typeof GetMediaDeviceSpecsResponseSchema;
    };
    /**
     * Audio analysis
     *
     * @generated from rpc avn.connect.v1.MediaService.GetMediaSpectrum
     */
    getMediaSpectrum: {
        methodKind: "unary";
        input: typeof GetMediaSpectrumRequestSchema;
        output: typeof GetMediaSpectrumResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/translations.proto.
 */
declare const file_avn_connect_v1_translations: GenFile;
/**
 * Source or translated text details
 *
 * @generated from message avn.connect.v1.TranslationSpec
 */
type TranslationSpec = Message<"avn.connect.v1.TranslationSpec"> & {
    /**
     * IETF BCP 47 language tag.
     * Blank means "unspecified": on a source spec the language is left undetermined; on
     * a target spec it disables translation, so the source text is returned unchanged.
     * Unlisted tags reduce to their nearest supported base (e.g. es-ES -> es).
     *
     * @generated from field: string language_id = 1;
     */
    languageId: string;
    /**
     * Format of the data
     *
     * @generated from field: avn.connect.v1.TranslationFormat format = 2;
     */
    format: TranslationFormat;
    /**
     * Additional flags
     *
     * @generated from field: repeated avn.connect.v1.TranslationFlag translation_flags = 3;
     */
    translationFlags: TranslationFlag[];
};
/**
 * Describes the message avn.connect.v1.TranslationSpec.
 * Use `create(TranslationSpecSchema)` to create a new message.
 */
declare const TranslationSpecSchema: GenMessage<TranslationSpec>;
/**
 * @generated from message avn.connect.v1.TranslationResponse
 */
type TranslationResponse = Message<"avn.connect.v1.TranslationResponse"> & {
    /**
     * Translated text
     *
     * @generated from field: string text = 1;
     */
    text: string;
};
/**
 * Describes the message avn.connect.v1.TranslationResponse.
 * Use `create(TranslationResponseSchema)` to create a new message.
 */
declare const TranslationResponseSchema: GenMessage<TranslationResponse>;
/**
 * Translation request
 *
 * @generated from message avn.connect.v1.TranslationRequest
 */
type TranslationRequest = Message<"avn.connect.v1.TranslationRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Source text
     *
     * @generated from field: string text = 2;
     */
    text: string;
    /**
     * Language and format of the source text. Required; format must not be UNDEFINED.
     *
     * @generated from field: avn.connect.v1.TranslationSpec source_spec = 3;
     */
    sourceSpec?: TranslationSpec;
    /**
     * Language and format to translate into:
     * - if unset, the original source is returned unmodified
     * - if its format is UNDEFINED, the source format is preserved
     *
     * @generated from field: optional avn.connect.v1.TranslationSpec target_spec = 4;
     */
    targetSpec?: TranslationSpec;
    /**
     * Optional disambiguation prefix for short or ambiguous text, applied as a single
     * whole-source translation (one translation_id derived from modifier + text).
     * Explicitly supplying one is allowed for PLAIN_TEXT sources only — any other source
     * format is rejected. XLIFF sources apply modifiers implicitly instead: each
     * <unit name="..."> is the modifier for its segments, so XLIFF-translated text is
     * stored under different ids than the same text translated as plain text.
     * (Implemented as a prefix for backward compatibility with CC1.)
     *
     * @generated from field: optional string modifier = 5;
     */
    modifier?: string;
};
/**
 * Describes the message avn.connect.v1.TranslationRequest.
 * Use `create(TranslationRequestSchema)` to create a new message.
 */
declare const TranslationRequestSchema: GenMessage<TranslationRequest>;
/**
 * @generated from message avn.connect.v1.TranslationUpdateRequest
 */
type TranslationUpdateRequest = Message<"avn.connect.v1.TranslationUpdateRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * ID of the source text being translated. Derived from the trimmed source fragment,
     * prefixed by the modifier when one applies (an explicit modifier on plain text, or
     * -- always -- the XLIFF <unit name>): the resulting string itself if under 16
     * characters, otherwise its Java String hashCode as a decimal string. Translation is
     * per fragment (paragraph / Markdown text node / XLIFF segment), so each fragment
     * has its own id. Rather than deriving ids by hand, run Translate with the
     * INCLUDE_METADATA target flag: XLIFF output carries each segment's exact id as an
     * avn:tid attribute, HTML as <avn-tx tid="...">.
     *
     * @generated from field: string translation_id = 2;
     */
    translationId: string;
    /**
     * Original language of source text
     *
     * @generated from field: string source_language_id = 3;
     */
    sourceLanguageId: string;
    /**
     * Target language of the translation
     *
     * @generated from field: string target_language_id = 4;
     */
    targetLanguageId: string;
    /**
     * New translated text
     *
     * @generated from field: string text = 5;
     */
    text: string;
};
/**
 * Describes the message avn.connect.v1.TranslationUpdateRequest.
 * Use `create(TranslationUpdateRequestSchema)` to create a new message.
 */
declare const TranslationUpdateRequestSchema: GenMessage<TranslationUpdateRequest>;
/**
 * @generated from message avn.connect.v1.TranslationLookupRequest
 */
type TranslationLookupRequest = Message<"avn.connect.v1.TranslationLookupRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * ID of the source text being translated. Derived from the trimmed source fragment,
     * prefixed by the modifier when one applies (an explicit modifier on plain text, or
     * -- always -- the XLIFF <unit name>): the resulting string itself if under 16
     * characters, otherwise its Java String hashCode as a decimal string. Translation is
     * per fragment (paragraph / Markdown text node / XLIFF segment), so each fragment
     * has its own id. Rather than deriving ids by hand, run Translate with the
     * INCLUDE_METADATA target flag: XLIFF output carries each segment's exact id as an
     * avn:tid attribute, HTML as <avn-tx tid="...">.
     *
     * @generated from field: string translation_id = 2;
     */
    translationId: string;
    /**
     * Original language of source text
     *
     * @generated from field: string source_language_id = 3;
     */
    sourceLanguageId: string;
    /**
     * Target language of the translation
     *
     * @generated from field: string target_language_id = 4;
     */
    targetLanguageId: string;
};
/**
 * Describes the message avn.connect.v1.TranslationLookupRequest.
 * Use `create(TranslationLookupRequestSchema)` to create a new message.
 */
declare const TranslationLookupRequestSchema: GenMessage<TranslationLookupRequest>;
/**
 * @generated from message avn.connect.v1.TranslationLookupResponse
 */
type TranslationLookupResponse = Message<"avn.connect.v1.TranslationLookupResponse"> & {
    /**
     * Original source text
     *
     * @generated from field: string source_text = 1;
     */
    sourceText: string;
    /**
     * Translated text
     *
     * @generated from field: string target_text = 2;
     */
    targetText: string;
    /**
     * Whether the stored translation is machine output or has been written/approved
     * by a human translator
     *
     * @generated from field: avn.connect.v1.TranslationOrigin origin = 3;
     */
    origin: TranslationOrigin;
    /**
     * When the stored translation was last written (machine caching or a translator's Update)
     *
     * @generated from field: google.protobuf.Timestamp updated = 4;
     */
    updated?: Timestamp;
    /**
     * When a translator last approved the translation via Update; unset for machine output
     *
     * @generated from field: optional google.protobuf.Timestamp approved = 5;
     */
    approved?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.TranslationLookupResponse.
 * Use `create(TranslationLookupResponseSchema)` to create a new message.
 */
declare const TranslationLookupResponseSchema: GenMessage<TranslationLookupResponse>;
/**
 * Provenance of a stored translation
 *
 * @generated from enum avn.connect.v1.TranslationOrigin
 */
declare enum TranslationOrigin {
    /**
     * @generated from enum value: TRANSLATION_ORIGIN_UNKNOWN = 0;
     */
    UNKNOWN = 0,
    /**
     * Generated by the automatic translation engine and never reviewed
     *
     * @generated from enum value: TRANSLATION_ORIGIN_MACHINE = 1;
     */
    MACHINE = 1,
    /**
     * Written or approved by a nominated human translator (via Update)
     *
     * @generated from enum value: TRANSLATION_ORIGIN_HUMAN = 2;
     */
    HUMAN = 2
}
/**
 * Describes the enum avn.connect.v1.TranslationOrigin.
 */
declare const TranslationOriginSchema: GenEnum<TranslationOrigin>;
/**
 * @generated from enum avn.connect.v1.TranslationFormat
 */
declare enum TranslationFormat {
    /**
     * @generated from enum value: TRANSLATION_FORMAT_UNDEFINED = 0;
     */
    UNDEFINED = 0,
    /**
     * Text is plain text
     *
     * @generated from enum value: TRANSLATION_FORMAT_PLAIN_TEXT = 1;
     */
    PLAIN_TEXT = 1,
    /**
     * Text is in Markdown format
     *
     * @generated from enum value: TRANSLATION_FORMAT_MARKDOWN = 2;
     */
    MARKDOWN = 2,
    /**
     * Text is in HTML format (valid as a translation target/output only, not as a source)
     *
     * @generated from enum value: TRANSLATION_FORMAT_HTML = 3;
     */
    HTML = 3,
    /**
     * Text is in XLIFF format
     *
     * @generated from enum value: TRANSLATION_FORMAT_XLIFF = 4;
     */
    XLIFF = 4,
    /**
     * Text is a transcript file URL
     *
     * @generated from enum value: TRANSLATION_FORMAT_TRANSCRIPT = 5;
     */
    TRANSCRIPT = 5
}
/**
 * Describes the enum avn.connect.v1.TranslationFormat.
 */
declare const TranslationFormatSchema: GenEnum<TranslationFormat>;
/**
 * @generated from enum avn.connect.v1.TranslationFlag
 */
declare enum TranslationFlag {
    /**
     * @generated from enum value: TRANSLATION_FLAG_UNKNOWN = 0;
     */
    UNKNOWN = 0,
    /**
     * The `text` field is an AVNFS URL, not inline text: the file is fetched, translated
     * and re-uploaded, and the response `text` is the new AVNFS URL.
     *
     * @generated from enum value: TRANSLATION_FLAG_IS_AVNFS = 1;
     */
    IS_AVNFS = 1,
    /**
     * Annotate each translated fragment with its translation_id metadata for translator
     * tooling: an <avn-tx tid s t> tag in HTML, a :tx[] directive in Markdown, or an
     * avn:tid attribute on each <segment> (namespace urn:avantis:xliff:metadata:1.0) in
     * XLIFF output.
     *
     * @generated from enum value: TRANSLATION_FLAG_INCLUDE_METADATA = 2;
     */
    INCLUDE_METADATA = 2,
    /**
     * Translation failed
     *
     * @generated from enum value: TRANSLATION_FLAG_ERROR = 40;
     */
    ERROR = 40,
    /**
     * Translation could not be found
     *
     * @generated from enum value: TRANSLATION_FLAG_NOT_FOUND = 41;
     */
    NOT_FOUND = 41
}
/**
 * Describes the enum avn.connect.v1.TranslationFlag.
 */
declare const TranslationFlagSchema: GenEnum<TranslationFlag>;
/**
 * @generated from service avn.connect.v1.TranslationService
 */
declare const TranslationService: GenService<{
    /**
     * Translate a source into a target language, cache-first: a stored translation
     * (including any human-approved Update) is returned if present, otherwise the text
     * is machine-translated and cached for next time. All three RPCs share one store,
     * keyed by (translation_id, source_language_id, target_language_id). Text is
     * translated per fragment (each paragraph / Markdown text node separately) and
     * `:notx[...]` / `:::notx` directives pass through untranslated. The source is
     * returned unchanged when target_spec is unset, the text is blank, or the source
     * and target resolve to the same language (e.g. en vs en-GB, handled as a spelling
     * dialect, not a translation). source_spec.format must be set; HTML is an output
     * format only (not a valid source). Callers must be users.
     *
     * @generated from rpc avn.connect.v1.TranslationService.Translate
     */
    translate: {
        methodKind: "unary";
        input: typeof TranslationRequestSchema;
        output: typeof TranslationResponseSchema;
    };
    /**
     * Look up an existing stored translation only (never generates one); NOT_FOUND if
     * absent. The response also reports the translation's provenance: whether it is
     * machine output or human-approved, and when it was last written/approved. Requires
     * the caller to be a nominated translator for the source and target languages, or a
     * parent variant of them (e.g. rights on `es` cover `es-ES`).
     *
     * @generated from rpc avn.connect.v1.TranslationService.Lookup
     */
    lookup: {
        methodKind: "unary";
        input: typeof TranslationLookupRequestSchema;
        output: typeof TranslationLookupResponseSchema;
    };
    /**
     * Overwrite an existing stored translation and mark it approved; the approved value
     * is what future Translate/Lookup calls return. The row must already exist (run
     * Translate or Lookup first) or the call is NOT_FOUND. Requires the caller to be a
     * nominated translator for the exact source and target languages (no variant
     * fallback, unlike Lookup). `text` must be whitespace-trimmed.
     *
     * @generated from rpc avn.connect.v1.TranslationService.Update
     */
    update: {
        methodKind: "unary";
        input: typeof TranslationUpdateRequestSchema;
        output: typeof EmptySchema;
    };
}>;
/**
 * Translatable fields can return different content depending on the TranslationRequest
 *
 * @generated from extension: optional bool translatable = 1000;
 */
declare const translatable: GenExtension<FieldOptions, boolean>;

/**
 * Describes the file avn/connect/v1/properties.proto.
 */
declare const file_avn_connect_v1_properties: GenFile;
/**
 * Generic message for entity property setting
 *
 * @generated from message avn.connect.v1.SetEntityPropertiesRequest
 */
type SetEntityPropertiesRequest = Message<"avn.connect.v1.SetEntityPropertiesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Entity properties to update. A single request may modify at most 128 entities;
     * larger requests are rejected. Batch bigger updates in groups of 128 or fewer.
     *
     * @generated from field: repeated avn.connect.v1.EntityProperties entity_properties = 4;
     */
    entityProperties: EntityProperties[];
    /**
     * Entity to modify
     *
     * @generated from field: int32 entity_id = 2 [deprecated = true];
     * @deprecated
     */
    entityId: number;
    /**
     * Properties to modify
     *
     * @generated from field: repeated avn.connect.v1.EntityPropertyState property_states = 3 [deprecated = true];
     * @deprecated
     */
    propertyStates: EntityPropertyState[];
};
/**
 * Describes the message avn.connect.v1.SetEntityPropertiesRequest.
 * Use `create(SetEntityPropertiesRequestSchema)` to create a new message.
 */
declare const SetEntityPropertiesRequestSchema: GenMessage<SetEntityPropertiesRequest>;
/**
 * Bulk property getter to return every requested property from every requested entity
 *
 * @generated from message avn.connect.v1.GetEntityPropertiesRequest
 */
type GetEntityPropertiesRequest = Message<"avn.connect.v1.GetEntityPropertiesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Entities to inspect. A single request may reference at most 128 entities; larger
     * requests are rejected. Page through bigger sets in batches of 128 or fewer.
     *
     * @generated from field: repeated int32 entity_ids = 2;
     */
    entityIds: number[];
    /**
     * Properties to inspect
     *
     * @generated from field: repeated avn.connect.v1.EntityProperty properties = 3;
     */
    properties: EntityProperty[];
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: optional avn.connect.v1.TranslationSpec translate = 4;
     */
    translate?: TranslationSpec;
    /**
     * Image transcode specs by `EntityProperty` ID. If no matching spec is found the original image is returned.
     *
     * @generated from field: map<int32, avn.connect.v1.TranscodeImageSpec> image_specs = 5;
     */
    imageSpecs: {
        [key: number]: TranscodeImageSpec;
    };
};
/**
 * Describes the message avn.connect.v1.GetEntityPropertiesRequest.
 * Use `create(GetEntityPropertiesRequestSchema)` to create a new message.
 */
declare const GetEntityPropertiesRequestSchema: GenMessage<GetEntityPropertiesRequest>;
/**
 * @generated from message avn.connect.v1.GetEntityPropertiesResponse
 */
type GetEntityPropertiesResponse = Message<"avn.connect.v1.GetEntityPropertiesResponse"> & {
    /**
     * Entity properties read
     *
     * @generated from field: repeated avn.connect.v1.EntityProperties results = 1;
     */
    results: EntityProperties[];
};
/**
 * Describes the message avn.connect.v1.GetEntityPropertiesResponse.
 * Use `create(GetEntityPropertiesResponseSchema)` to create a new message.
 */
declare const GetEntityPropertiesResponseSchema: GenMessage<GetEntityPropertiesResponse>;
/**
 * @generated from message avn.connect.v1.EntityProperties
 */
type EntityProperties = Message<"avn.connect.v1.EntityProperties"> & {
    /**
     * Entity ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Properties of entity
     *
     * @generated from field: repeated avn.connect.v1.EntityPropertyState property_states = 2;
     */
    propertyStates: EntityPropertyState[];
};
/**
 * Describes the message avn.connect.v1.EntityProperties.
 * Use `create(EntityPropertiesSchema)` to create a new message.
 */
declare const EntityPropertiesSchema: GenMessage<EntityProperties>;
/**
 * @generated from message avn.connect.v1.EntityPropertyState
 */
type EntityPropertyState = Message<"avn.connect.v1.EntityPropertyState"> & {
    /**
     * Entity property
     *
     * @generated from field: avn.connect.v1.EntityProperty property = 3;
     */
    property: EntityProperty;
    /**
     * Property state type varies by property
     *
     * @generated from oneof avn.connect.v1.EntityPropertyState.state
     */
    state: {
        /**
         * @generated from field: bool bool = 4;
         */
        value: boolean;
        case: "bool";
    } | {
        /**
         * @generated from field: int32 int32 = 5;
         */
        value: number;
        case: "int32";
    } | {
        /**
         * @generated from field: int64 int64 = 6;
         */
        value: bigint;
        case: "int64";
    } | {
        /**
         * @generated from field: float float = 7;
         */
        value: number;
        case: "float";
    } | {
        /**
         * @generated from field: double double = 8;
         */
        value: number;
        case: "double";
    } | {
        /**
         * @generated from field: string string = 9;
         */
        value: string;
        case: "string";
    } | {
        /**
         * @generated from field: bytes bytes = 10;
         */
        value: Uint8Array;
        case: "bytes";
    } | {
        /**
         * @generated from field: google.protobuf.Timestamp timestamp = 11;
         */
        value: Timestamp;
        case: "timestamp";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message avn.connect.v1.EntityPropertyState.
 * Use `create(EntityPropertyStateSchema)` to create a new message.
 */
declare const EntityPropertyStateSchema: GenMessage<EntityPropertyState>;
/**
 * Entity properties. Not all properties are valid for all entity types.
 *
 * @generated from enum avn.connect.v1.EntityProperty
 */
declare enum EntityProperty {
    /**
     * @generated from enum value: ENTITY_PROPERTY_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Entity ID
     *
     * @generated from enum value: ENTITY_PROPERTY_ID = 1;
     */
    ID = 1,
    /**
     * Entity name in plain text format
     *
     * @generated from enum value: ENTITY_PROPERTY_NAME = 2;
     */
    NAME = 2,
    /**
     * Entity description stored in markdown format
     *
     * @generated from enum value: ENTITY_PROPERTY_DESCRIPTION = 3;
     */
    DESCRIPTION = 3,
    /**
     * Date entity was created
     *
     * @generated from enum value: ENTITY_PROPERTY_CREATED = 4;
     */
    CREATED = 4,
    /**
     * Date entity last updated
     *
     * @generated from enum value: ENTITY_PROPERTY_UPDATED = 5;
     */
    UPDATED = 5,
    /**
     * Entity size in bytes
     *
     * @generated from enum value: ENTITY_PROPERTY_SIZE = 6;
     */
    SIZE = 6,
    /**
     * Entity priority order (position within its parent; persisted as the sortorder column)
     *
     * @generated from enum value: ENTITY_PROPERTY_PRIORITY_ORDER = 7;
     */
    PRIORITY_ORDER = 7,
    /**
     * Entity icon in PNG, JPEG, or SVG format
     *
     * @generated from enum value: ENTITY_PROPERTY_ICON_URL = 8;
     */
    ICON_URL = 8,
    /**
     * Entity instructions stored in markdown format
     *
     * @generated from enum value: ENTITY_PROPERTY_INSTRUCTIONS = 9;
     */
    INSTRUCTIONS = 9,
    /**
     * An indication of the origin of the entity
     *
     * @generated from enum value: ENTITY_PROPERTY_CONTEXT = 10;
     */
    CONTEXT = 10,
    /**
     * Entity asset ID
     *
     * @generated from enum value: ENTITY_PROPERTY_ASSET_ID = 11;
     */
    ASSET_ID = 11,
    /**
     * Content language
     *
     * @generated from enum value: ENTITY_PROPERTY_LANGUAGE_ID = 12;
     */
    LANGUAGE_ID = 12,
    /**
     * Date entity was published
     *
     * @generated from enum value: ENTITY_PROPERTY_PUBLISHED = 13;
     */
    PUBLISHED = 13,
    /**
     * Is entity available, e.g. permitted or licensed?
     *
     * @generated from enum value: ENTITY_PROPERTY_AVAILABLE = 14;
     */
    AVAILABLE = 14,
    /**
     * Date entity was featured
     *
     * @generated from enum value: ENTITY_PROPERTY_FEATURED = 15;
     */
    FEATURED = 15,
    /**
     * Entity MAC address
     *
     * @generated from enum value: ENTITY_PROPERTY_MAC_ADDRESS = 16;
     */
    MAC_ADDRESS = 16,
    /**
     * Entity software version code
     *
     * @generated from enum value: ENTITY_PROPERTY_SW_VERSION = 17;
     */
    SW_VERSION = 17,
    /**
     * Entity hostname
     *
     * @generated from enum value: ENTITY_PROPERTY_HOSTNAME = 18;
     */
    HOSTNAME = 18,
    /**
     * Entity platform
     *
     * @generated from enum value: ENTITY_PROPERTY_PLATFORM = 19;
     */
    PLATFORM = 19,
    /**
     * Date entity was approved
     *
     * @generated from enum value: ENTITY_PROPERTY_APPROVED = 20;
     */
    APPROVED = 20,
    /**
     * Entity filename
     *
     * @generated from enum value: ENTITY_PROPERTY_FILENAME = 21;
     */
    FILENAME = 21,
    /**
     * Entity child item cound
     *
     * @generated from enum value: ENTITY_PROPERTY_ITEM_COUNT = 22;
     */
    ITEM_COUNT = 22,
    /**
     * Entity child track count
     *
     * @generated from enum value: ENTITY_PROPERTY_TRACK_COUNT = 23;
     */
    TRACK_COUNT = 23,
    /**
     * Entity tags
     *
     * @generated from enum value: ENTITY_PROPERTY_TAGS = 24;
     */
    TAGS = 24,
    /**
     * Entity postal address
     *
     * @generated from enum value: ENTITY_PROPERTY_ADDRESS = 25;
     */
    ADDRESS = 25,
    /**
     * Entity city
     *
     * @generated from enum value: ENTITY_PROPERTY_CITY = 26;
     */
    CITY = 26,
    /**
     * Entity state
     *
     * @generated from enum value: ENTITY_PROPERTY_STATE = 27;
     */
    STATE = 27,
    /**
     * Entity postal code
     *
     * @generated from enum value: ENTITY_PROPERTY_POSTCODE = 28;
     */
    POSTCODE = 28,
    /**
     * Entity phone number
     *
     * @generated from enum value: ENTITY_PROPERTY_PHONE = 29;
     */
    PHONE = 29,
    /**
     * Entity contact email
     *
     * @generated from enum value: ENTITY_PROPERTY_EMAIL = 30;
     */
    EMAIL = 30,
    /**
     * Entity keywords
     *
     * @generated from enum value: ENTITY_PROPERTY_KEYWORDS = 31;
     */
    KEYWORDS = 31,
    /**
     * Entity summary stored in markdown format
     *
     * @generated from enum value: ENTITY_PROPERTY_SUMMARY = 32;
     */
    SUMMARY = 32,
    /**
     * Entity combined text
     *
     * @generated from enum value: ENTITY_PROPERTY_COMBINED_TEXT = 33;
     */
    COMBINED_TEXT = 33,
    /**
     * Entity phonemes (IPA)
     *
     * @generated from enum value: ENTITY_PROPERTY_PHONEMES = 34;
     */
    PHONEMES = 34,
    /**
     * Entity priority
     *
     * @generated from enum value: ENTITY_PROPERTY_PRIORITY = 35;
     */
    PRIORITY = 35,
    /**
     * Entity preview URL
     *
     * @generated from enum value: ENTITY_PROPERTY_PREVIEW_URL = 36;
     */
    PREVIEW_URL = 36,
    /**
     * Is entity permitted?
     *
     * @generated from enum value: ENTITY_PROPERTY_PERMITTED = 37;
     */
    PERMITTED = 37,
    /**
     * Is entity permitted?
     *
     * @generated from enum value: ENTITY_PROPERTY_LICENSED = 38;
     */
    LICENSED = 38,
    /**
     * Entity type
     *
     * @generated from enum value: ENTITY_PROPERTY_ENTITY_TYPE = 39;
     */
    ENTITY_TYPE = 39,
    /**
     * Owning organization ID for activities, categories, and profiles (0 means personally owned by the creator)
     *
     * @generated from enum value: ENTITY_PROPERTY_ORGANIZATION_ID = 40;
     */
    ORGANIZATION_ID = 40,
    /**
     * Device ID
     *
     * @generated from enum value: ENTITY_PROPERTY_DEVICE_ID = 41;
     */
    DEVICE_ID = 41,
    /**
     * Website URL for activities
     *
     * @generated from enum value: ENTITY_PROPERTY_WEBSITE_URL = 42;
     */
    WEBSITE_URL = 42,
    /**
     * Wallpaper image for categories and profiles
     *
     * @generated from enum value: ENTITY_PROPERTY_WALLPAPER_URL = 43;
     */
    WALLPAPER_URL = 43,
    /**
     * Software release channel a device is tracking for updates. Carried as a string
     * using the `ReleaseChannel` enum names (e.g. "PRODUCTION"); empty string means
     * the device is not tracking any channel
     *
     * @generated from enum value: ENTITY_PROPERTY_RELEASE_CHANNEL = 44;
     */
    RELEASE_CHANNEL = 44,
    /**
     * Firmware build identifier reported by a device (raw build string)
     *
     * @generated from enum value: ENTITY_PROPERTY_FIRMWARE = 45;
     */
    FIRMWARE = 45,
    /**
     * When a device last reported in (most recent check-in)
     *
     * @generated from enum value: ENTITY_PROPERTY_LAST_ACCESS = 46;
     */
    LAST_ACCESS = 46,
    /**
     * WiFi network SSID
     *
     * @generated from enum value: ENTITY_PROPERTY_SSID = 47;
     */
    SSID = 47,
    /**
     * WiFi encryption scheme. Carried as a string using the `WifiEncryption` enum names
     * (e.g. "WPA_EAP_PEAP")
     *
     * @generated from enum value: ENTITY_PROPERTY_ENCRYPTION = 48;
     */
    ENCRYPTION = 48,
    /**
     * Username / EAP identity
     *
     * @generated from enum value: ENTITY_PROPERTY_USERNAME = 49;
     */
    USERNAME = 49,
    /**
     * Password / pre-shared key
     *
     * @generated from enum value: ENTITY_PROPERTY_PASSWORD = 50;
     */
    PASSWORD = 50,
    /**
     * Is the entity hidden, e.g. a WiFi SSID that is not broadcast?
     *
     * @generated from enum value: ENTITY_PROPERTY_HIDDEN = 51;
     */
    HIDDEN = 51,
    /**
     * Should the entity be deployed to devices?
     *
     * @generated from enum value: ENTITY_PROPERTY_DEPLOY = 52;
     */
    DEPLOY = 52,
    /**
     * AVNFS URL of one or more concatenated PEM CA certificates (802.1X trust anchor)
     *
     * @generated from enum value: ENTITY_PROPERTY_CERTIFICATE_URL = 53;
     */
    CERTIFICATE_URL = 53,
    /**
     * Server certificate domain suffix match for 802.1X validation
     *
     * @generated from enum value: ENTITY_PROPERTY_DOMAIN = 54;
     */
    DOMAIN = 54,
    /**
     * EAP-TLS client-credential provisioning method. Carried as a string using the
     * `WifiClientCredential` enum names (e.g. "PKCS12"); empty string means none configured
     *
     * @generated from enum value: ENTITY_PROPERTY_CLIENT_CREDENTIAL = 55;
     */
    CLIENT_CREDENTIAL = 55,
    /**
     * AVNFS URL of a shared PKCS#12 client certificate bundle
     *
     * @generated from enum value: ENTITY_PROPERTY_CLIENT_CERTIFICATE_URL = 56;
     */
    CLIENT_CERTIFICATE_URL = 56,
    /**
     * Password protecting the PKCS#12 client certificate bundle
     *
     * @generated from enum value: ENTITY_PROPERTY_CLIENT_CERTIFICATE_PASSWORD = 57;
     */
    CLIENT_CERTIFICATE_PASSWORD = 57,
    /**
     * Certificate enrollment endpoint URL (e.g. a SCEP server)
     *
     * @generated from enum value: ENTITY_PROPERTY_ENROLL_URL = 58;
     */
    ENROLL_URL = 58,
    /**
     * Certificate enrollment challenge password
     *
     * @generated from enum value: ENTITY_PROPERTY_ENROLL_CHALLENGE = 59;
     */
    ENROLL_CHALLENGE = 59,
    /**
     * Certificate enrollment subject/CN template
     *
     * @generated from enum value: ENTITY_PROPERTY_ENROLL_SUBJECT = 60;
     */
    ENROLL_SUBJECT = 60,
    /**
     * TTLS inner (phase-2) authentication method. Carried as a string using the
     * `WifiPhase2` enum names (e.g. "PAP"); empty string means the device default (MSCHAPv2)
     *
     * @generated from enum value: ENTITY_PROPERTY_PHASE2 = 61;
     */
    PHASE2 = 61,
    /**
     * Parent organization ID in the organization hierarchy
     *
     * @generated from enum value: ENTITY_PROPERTY_PARENT_ID = 62;
     */
    PARENT_ID = 62,
    /**
     * Should devices join this WiFi network with their factory-fixed MAC address instead of
     * a per-network randomised one (Android's "Use device MAC")? For networks that admit
     * only registered MAC addresses. Carried as a bool
     *
     * @generated from enum value: ENTITY_PROPERTY_USE_DEVICE_MAC = 63;
     */
    USE_DEVICE_MAC = 63,
    /**
     * Android application ID that an APP activity launches, e.g. "com.example.app". Shared by
     * every Android package (APK variant) of the activity
     *
     * @generated from enum value: ENTITY_PROPERTY_PACKAGE_NAME = 64;
     */
    PACKAGE_NAME = 64,
    /**
     * Optional Android activity class launched within the package of an APP activity; empty
     * means the package's default launcher activity
     *
     * @generated from enum value: ENTITY_PROPERTY_PACKAGE_CLASS = 65;
     */
    PACKAGE_CLASS = 65,
    /**
     * AVNFS URL of an Android APK
     *
     * @generated from enum value: ENTITY_PROPERTY_APK_URL = 66;
     */
    APK_URL = 66,
    /**
     * AVNFS URL of an Android OBB main expansion file
     *
     * @generated from enum value: ENTITY_PROPERTY_OBB_MAIN_URL = 67;
     */
    OBB_MAIN_URL = 67,
    /**
     * AVNFS URL of an Android OBB patch expansion file
     *
     * @generated from enum value: ENTITY_PROPERTY_OBB_PATCH_URL = 68;
     */
    OBB_PATCH_URL = 68,
    /**
     * Minimum Android SDK (API level) supported; 0 means unspecified
     *
     * @generated from enum value: ENTITY_PROPERTY_MIN_SDK = 69;
     */
    MIN_SDK = 69,
    /**
     * Target CPU ABI when a package is architecture specific, e.g. "arm64-v8a"; empty means any
     *
     * @generated from enum value: ENTITY_PROPERTY_TARGET_ABI = 70;
     */
    TARGET_ABI = 70,
    /**
     * Device product a product stream steers, as devices report it (e.g. "CVR255")
     *
     * @generated from enum value: ENTITY_PROPERTY_PRODUCT = 71;
     */
    PRODUCT = 71,
    /**
     * Free-text notes on an entity, for the people managing it rather than its users
     *
     * @generated from enum value: ENTITY_PROPERTY_NOTES = 72;
     */
    NOTES = 72
}
/**
 * Describes the enum avn.connect.v1.EntityProperty.
 */
declare const EntityPropertySchema: GenEnum<EntityProperty>;

/**
 * Describes the file avn/connect/v1/search.proto.
 */
declare const file_avn_connect_v1_search: GenFile;
/**
 * Text-based search specification
 *
 * @generated from message avn.connect.v1.TextSearch
 */
type TextSearch = Message<"avn.connect.v1.TextSearch"> & {
    /**
     * Text to search for
     *
     * @generated from field: string text = 1;
     */
    text: string;
    /**
     * Properties to search
     * Not all properties are available for all content types
     * If empty a default set of properties will be searched
     *
     * @generated from field: repeated avn.connect.v1.EntityProperty properties = 2;
     */
    properties: EntityProperty[];
    /**
     * Search conditions. If unset all matching results will be returned.
     *
     * @generated from field: repeated avn.connect.v1.SearchFlags conditions = 3;
     */
    conditions: SearchFlags[];
};
/**
 * Describes the message avn.connect.v1.TextSearch.
 * Use `create(TextSearchSchema)` to create a new message.
 */
declare const TextSearchSchema: GenMessage<TextSearch>;
/**
 * Search results ordering clause
 *
 * @generated from message avn.connect.v1.OrderClause
 */
type OrderClause = Message<"avn.connect.v1.OrderClause"> & {
    /**
     * Property to order by
     *
     * @generated from field: avn.connect.v1.EntityProperty property = 7;
     */
    property: EntityProperty;
    /**
     * Order of search results
     *
     * @generated from field: optional avn.connect.v1.SortOrder sort_order = 8;
     */
    sortOrder?: SortOrder;
};
/**
 * Describes the message avn.connect.v1.OrderClause.
 * Use `create(OrderClauseSchema)` to create a new message.
 */
declare const OrderClauseSchema: GenMessage<OrderClause>;
/**
 * @generated from enum avn.connect.v1.SearchFlags
 */
declare enum SearchFlags {
    /**
     * @generated from enum value: SEARCH_FLAGS_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Exact text match
     *
     * @generated from enum value: SEARCH_FLAGS_EXACT_MATCH = 1;
     */
    EXACT_MATCH = 1,
    /**
     * Use vector embeddings
     *
     * @generated from enum value: SEARCH_FLAGS_VECTOR_MATCH = 2;
     */
    VECTOR_MATCH = 2
}
/**
 * Describes the enum avn.connect.v1.SearchFlags.
 */
declare const SearchFlagsSchema: GenEnum<SearchFlags>;
/**
 * Search results ordering
 *
 * @generated from enum avn.connect.v1.SortOrder
 */
declare enum SortOrder {
    /**
     * @generated from enum value: SORT_ORDER_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Sort results ascending
     *
     * @generated from enum value: SORT_ORDER_ASC = 1;
     */
    ASC = 1,
    /**
     * Sort results descending
     *
     * @generated from enum value: SORT_ORDER_DESC = 2;
     */
    DESC = 2
}
/**
 * Describes the enum avn.connect.v1.SortOrder.
 */
declare const SortOrderSchema: GenEnum<SortOrder>;

/**
 * Describes the file avn/connect/v1/tags.proto.
 */
declare const file_avn_connect_v1_tags: GenFile;
/**
 * @generated from message avn.connect.v1.Tag
 */
type Tag = Message<"avn.connect.v1.Tag"> & {
    /**
     * Tag ID
     *
     * @generated from field: int32 tag_id = 1;
     */
    tagId: number;
    /**
     * Tag name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Tag group ID
     *
     * @generated from field: int32 tag_group_id = 3;
     */
    tagGroupId: number;
    /**
     * Sort order within the tag group
     *
     * @generated from field: int32 sort_order = 4;
     */
    sortOrder: number;
    /**
     * Display color
     *
     * @generated from field: string hex_color = 5;
     */
    hexColor: string;
};
/**
 * Describes the message avn.connect.v1.Tag.
 * Use `create(TagSchema)` to create a new message.
 */
declare const TagSchema: GenMessage<Tag>;
/**
 * @generated from message avn.connect.v1.TagGroup
 */
type TagGroup = Message<"avn.connect.v1.TagGroup"> & {
    /**
     * Tag group ID
     *
     * @generated from field: int32 tag_group_id = 1;
     */
    tagGroupId: number;
    /**
     * Tag group display name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Language of the tag group name and the name of tags in the group
     *
     * @generated from field: string language_id = 3;
     */
    languageId: string;
    /**
     * Tags in this group
     *
     * @generated from field: repeated avn.connect.v1.Tag tags = 4;
     */
    tags: Tag[];
};
/**
 * Describes the message avn.connect.v1.TagGroup.
 * Use `create(TagGroupSchema)` to create a new message.
 */
declare const TagGroupSchema: GenMessage<TagGroup>;
/**
 * @generated from message avn.connect.v1.GetTagsRequest
 */
type GetTagsRequest = Message<"avn.connect.v1.GetTagsRequest"> & {
    /**
     * Tag IDs to fetch
     *
     * @generated from field: repeated int32 tag_ids = 1;
     */
    tagIds: number[];
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 2;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetTagsRequest.
 * Use `create(GetTagsRequestSchema)` to create a new message.
 */
declare const GetTagsRequestSchema: GenMessage<GetTagsRequest>;
/**
 * @generated from message avn.connect.v1.GetTagsResponse
 */
type GetTagsResponse = Message<"avn.connect.v1.GetTagsResponse"> & {
    /**
     * Search results
     *
     * @generated from field: repeated avn.connect.v1.Tag tags = 1;
     */
    tags: Tag[];
};
/**
 * Describes the message avn.connect.v1.GetTagsResponse.
 * Use `create(GetTagsResponseSchema)` to create a new message.
 */
declare const GetTagsResponseSchema: GenMessage<GetTagsResponse>;
/**
 * @generated from message avn.connect.v1.GetTagGroupRequest
 */
type GetTagGroupRequest = Message<"avn.connect.v1.GetTagGroupRequest"> & {
    /**
     * Tag group ID to fetch
     *
     * @generated from field: int32 tag_group_id = 1;
     */
    tagGroupId: number;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 2;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetTagGroupRequest.
 * Use `create(GetTagGroupRequestSchema)` to create a new message.
 */
declare const GetTagGroupRequestSchema: GenMessage<GetTagGroupRequest>;
/**
 * @generated from message avn.connect.v1.GetTagGroupResponse
 */
type GetTagGroupResponse = Message<"avn.connect.v1.GetTagGroupResponse"> & {
    /**
     * Search result
     *
     * @generated from field: avn.connect.v1.TagGroup tag_group = 1;
     */
    tagGroup?: TagGroup;
};
/**
 * Describes the message avn.connect.v1.GetTagGroupResponse.
 * Use `create(GetTagGroupResponseSchema)` to create a new message.
 */
declare const GetTagGroupResponseSchema: GenMessage<GetTagGroupResponse>;
/**
 * @generated from message avn.connect.v1.AddTagsRequest
 */
type AddTagsRequest = Message<"avn.connect.v1.AddTagsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Entity to add the tags to
     *
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
    /**
     * Tags to add to the entity
     *
     * @generated from field: repeated int32 tags = 3;
     */
    tags: number[];
    /**
     * CLOUD_FILE_LEGACY_ID
     *
     * @generated from field: optional string legacy_id = 10;
     */
    legacyId?: string;
};
/**
 * Describes the message avn.connect.v1.AddTagsRequest.
 * Use `create(AddTagsRequestSchema)` to create a new message.
 */
declare const AddTagsRequestSchema: GenMessage<AddTagsRequest>;
/**
 * @generated from message avn.connect.v1.RemoveTagsRequest
 */
type RemoveTagsRequest = Message<"avn.connect.v1.RemoveTagsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Entity to remove the tags from
     *
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
    /**
     * Tags to remove from the entity
     *
     * @generated from field: repeated int32 tags = 3;
     */
    tags: number[];
    /**
     * CLOUD_FILE_LEGACY_ID
     *
     * @generated from field: optional string legacy_id = 10;
     */
    legacyId?: string;
};
/**
 * Describes the message avn.connect.v1.RemoveTagsRequest.
 * Use `create(RemoveTagsRequestSchema)` to create a new message.
 */
declare const RemoveTagsRequestSchema: GenMessage<RemoveTagsRequest>;
/**
 * @generated from message avn.connect.v1.TagFilter
 */
type TagFilter = Message<"avn.connect.v1.TagFilter"> & {
    /**
     * Condition to use when filtering
     *
     * @generated from field: avn.connect.v1.TagFilterCondition condition = 1;
     */
    condition: TagFilterCondition;
    /**
     * Tag IDs to filter against
     *
     * @generated from field: repeated int32 tags = 2;
     */
    tags: number[];
};
/**
 * Describes the message avn.connect.v1.TagFilter.
 * Use `create(TagFilterSchema)` to create a new message.
 */
declare const TagFilterSchema: GenMessage<TagFilter>;
/**
 * @generated from enum avn.connect.v1.TagFilterCondition
 */
declare enum TagFilterCondition {
    /**
     * @generated from enum value: TAG_FILTER_CONDITION_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Entity has any of the tags
     *
     * @generated from enum value: TAG_FILTER_CONDITION_HAS_ANY_OF = 1;
     */
    HAS_ANY_OF = 1,
    /**
     * Entity has all of the tags
     *
     * @generated from enum value: TAG_FILTER_CONDITION_HAS_ALL_OF = 2;
     */
    HAS_ALL_OF = 2,
    /**
     * Entity has none of the tags
     *
     * @generated from enum value: TAG_FILTER_CONDITION_HAS_NONE_OF = 3;
     */
    HAS_NONE_OF = 3
}
/**
 * Describes the enum avn.connect.v1.TagFilterCondition.
 */
declare const TagFilterConditionSchema: GenEnum<TagFilterCondition>;
/**
 * @generated from enum avn.connect.v1.TagGroupId
 */
declare enum TagGroupId {
    /**
     * @generated from enum value: TAG_GROUP_ID_UNKNOWN = 0;
     */
    UNKNOWN = 0,
    /**
     * Curriculum subject
     *
     * @generated from enum value: TAG_GROUP_ID_SUBJECT = 1;
     */
    SUBJECT = 1,
    /**
     * Target age range
     *
     * @generated from enum value: TAG_GROUP_ID_AGE_RANGE = 2;
     */
    AGE_RANGE = 2,
    /**
     * Supported platform
     *
     * @generated from enum value: TAG_GROUP_ID_PLATFORM = 10;
     */
    PLATFORM = 10,
    /**
     * Resource media type
     *
     * @generated from enum value: TAG_GROUP_ID_MEDIA = 28;
     */
    MEDIA = 28,
    /**
     * Deprecated tags
     *
     * @generated from enum value: TAG_GROUP_ID_DEPRECATED = 78;
     */
    DEPRECATED = 78
}
/**
 * Describes the enum avn.connect.v1.TagGroupId.
 */
declare const TagGroupIdSchema: GenEnum<TagGroupId>;
/**
 * @generated from enum avn.connect.v1.TagId
 */
declare enum TagId {
    /**
     * @generated from enum value: TAG_ID_UNKNOWN = 0;
     */
    UNKNOWN = 0,
    /**
     * Resource generated by Eduverse AI
     *
     * @generated from enum value: TAG_ID_EDUVERSE_AI = 2745;
     */
    EDUVERSE_AI = 2745,
    /**
     * Resource is AI generated
     *
     * @generated from enum value: TAG_ID_AI_GENERATED = 2747;
     */
    AI_GENERATED = 2747,
    /**
     * Resource generated by Skybox AI
     *
     * @generated from enum value: TAG_ID_SKYBOX_AI = 2746;
     */
    SKYBOX_AI = 2746,
    /**
     * Resource created in ClassCanvas
     *
     * @generated from enum value: TAG_ID_CLASS_CANVAS = 2778;
     */
    CLASS_CANVAS = 2778,
    /**
     * Resource should not be browseable
     *
     * @generated from enum value: TAG_ID_NOT_BROWSABLE = 2427;
     */
    NOT_BROWSABLE = 2427,
    /**
     * Resource is for navigation to other resources
     *
     * @generated from enum value: TAG_ID_NAVIGABLE = 2683;
     */
    NAVIGABLE = 2683,
    /**
     * CoSpaces resource
     *
     * @generated from enum value: TAG_ID_COSPACES = 2743;
     */
    COSPACES = 2743,
    /**
     * ThingLink resource
     *
     * @generated from enum value: TAG_ID_THINGLINK = 2742;
     */
    THINGLINK = 2742,
    /**
     * A collection the only exists to contain the child entities
     *
     * @generated from enum value: TAG_ID_SHIM_CONTAINER = 2795;
     */
    SHIM_CONTAINER = 2795,
    /**
     * 2D resource
     *
     * @generated from enum value: TAG_ID_FLAT = 2715;
     */
    FLAT = 2715,
    /**
     * 360 equirectangular resource
     *
     * @generated from enum value: TAG_ID_EQUIRECTANGULAR_360 = 2363;
     */
    EQUIRECTANGULAR_360 = 2363,
    /**
     * 180 equirectangular resource
     *
     * @generated from enum value: TAG_ID_EQUIRECTANGULAR_180 = 2550;
     */
    EQUIRECTANGULAR_180 = 2550,
    /**
     * 360 resource arranged in a cubmap format
     *
     * @generated from enum value: TAG_ID_CUBEMAP = 2373;
     */
    CUBEMAP = 2373,
    /**
     * Stereo resource top-bottom maps to left-right
     *
     * @generated from enum value: TAG_ID_STEREO_TB_LR = 2362;
     */
    STEREO_TB_LR = 2362,
    /**
     * Stereo resource left and right images are side-by-side
     *
     * @generated from enum value: TAG_ID_STEREO_SBS = 2364;
     */
    STEREO_SBS = 2364,
    /**
     * Augmented reality
     *
     * @generated from enum value: TAG_ID_AR = 2367;
     */
    AR = 2367,
    /**
     * Virtual reality
     *
     * @generated from enum value: TAG_ID_VR = 2366;
     */
    VR = 2366,
    /**
     * @generated from enum value: TAG_ID_SCENE_GUIDE = 2656;
     */
    SCENE_GUIDE = 2656,
    /**
     * @generated from enum value: TAG_ID_LESSON_PLAN = 2372;
     */
    LESSON_PLAN = 2372,
    /**
     * @generated from enum value: TAG_ID_WORKSHEET = 2371;
     */
    WORKSHEET = 2371,
    /**
     * @generated from enum value: TAG_ID_ANIMATED = 2613;
     */
    ANIMATED = 2613,
    /**
     * @generated from enum value: TAG_ID_INTERACTIVE = 2697;
     */
    INTERACTIVE = 2697,
    /**
     * Explorable 3D scene
     *
     * @generated from enum value: TAG_ID_SCENE = 2375;
     */
    SCENE = 2375,
    /**
     * 3D avatar
     *
     * @generated from enum value: TAG_ID_AVATAR = 2666;
     */
    AVATAR = 2666,
    /**
     * 3D model
     *
     * @generated from enum value: TAG_ID_MODEL = 2374;
     */
    MODEL = 2374,
    /**
     * @generated from enum value: TAG_ID_AUDIO = 2655;
     */
    AUDIO = 2655,
    /**
     * @generated from enum value: TAG_ID_IMAGE = 2376;
     */
    IMAGE = 2376,
    /**
     * @generated from enum value: TAG_ID_VIDEO = 2377;
     */
    VIDEO = 2377,
    /**
     * @generated from enum value: TAG_ID_TOPIC = 2741;
     */
    TOPIC = 2741,
    /**
     * Only supported on 3DoF devices
     *
     * @generated from enum value: TAG_ID_THREE_DOF = 2776;
     */
    THREE_DOF = 2776,
    /**
     * Only supported on 6DoF devices
     *
     * @generated from enum value: TAG_ID_SIX_DOF = 2777;
     */
    SIX_DOF = 2777,
    /**
     * @generated from enum value: TAG_ID_EXPLODABLE = 2796;
     */
    EXPLODABLE = 2796,
    /**
     * client install: install silently/internally
     *
     * @generated from enum value: TAG_ID_INTERNAL_INSTALL = 2251;
     */
    INTERNAL_INSTALL = 2251,
    /**
     * client install: force 2D install mode
     *
     * @generated from enum value: TAG_ID_FORCE_2D_INSTALL = 2426;
     */
    FORCE_2D_INSTALL = 2426,
    /**
     * (currently unused in the client)
     *
     * @generated from enum value: TAG_ID_BETA = 2665;
     */
    BETA = 2665,
    /**
     * @generated from enum value: TAG_ID_AGE_RANGE_UNDER_5 = 17;
     */
    AGE_RANGE_UNDER_5 = 17,
    /**
     * @generated from enum value: TAG_ID_AGE_RANGE_5_TO_7 = 18;
     */
    AGE_RANGE_5_TO_7 = 18,
    /**
     * @generated from enum value: TAG_ID_AGE_RANGE_7_TO_11 = 19;
     */
    AGE_RANGE_7_TO_11 = 19,
    /**
     * @generated from enum value: TAG_ID_AGE_RANGE_11_TO_14 = 20;
     */
    AGE_RANGE_11_TO_14 = 20,
    /**
     * @generated from enum value: TAG_ID_AGE_RANGE_14_TO_16 = 21;
     */
    AGE_RANGE_14_TO_16 = 21,
    /**
     * @generated from enum value: TAG_ID_AGE_RANGE_OVER_16 = 22;
     */
    AGE_RANGE_OVER_16 = 22
}
/**
 * Describes the enum avn.connect.v1.TagId.
 */
declare const TagIdSchema: GenEnum<TagId>;
/**
 * @generated from service avn.connect.v1.TagService
 */
declare const TagService: GenService<{
    /**
     * Resolve tag IDs
     *
     * @generated from rpc avn.connect.v1.TagService.GetTags
     */
    getTags: {
        methodKind: "unary";
        input: typeof GetTagsRequestSchema;
        output: typeof GetTagsResponseSchema;
    };
    /**
     * Get all the details of a tag groups from an ID
     *
     * @generated from rpc avn.connect.v1.TagService.GetTagGroup
     */
    getTagGroup: {
        methodKind: "unary";
        input: typeof GetTagGroupRequestSchema;
        output: typeof GetTagGroupResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/entities.proto.
 */
declare const file_avn_connect_v1_entities: GenFile;
/**
 * Common summary info for channels, profiles, categories, activities, cloud files, and devices
 *
 * @generated from message avn.connect.v1.EntityInfo
 */
type EntityInfo = Message<"avn.connect.v1.EntityInfo"> & {
    /**
     * Entity ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Entity name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * When entity last updated
     *
     * @generated from field: google.protobuf.Timestamp updated = 3;
     */
    updated?: Timestamp;
    /**
     * Icon URL for the entity. Accepted media types: image/png, image/jpeg, image/svg+xml
     *
     * @generated from field: string icon_url = 4;
     */
    iconUrl: string;
    /**
     * Preview image URL for the entity. Accepted media types: image/png, image/jpeg, image/svg+xml
     *
     * @generated from field: string preview_url = 5;
     */
    previewUrl: string;
    /**
     * An indication of the origin of the entity
     *
     * @generated from field: optional string context = 6;
     */
    context?: string;
    /**
     * Tags assigned to this entity, see tags.proto for examples
     *
     * @generated from field: repeated int32 tags = 7;
     */
    tags: number[];
    /**
     * When entity was published or unset if not published
     *
     * @generated from field: optional google.protobuf.Timestamp published = 8;
     */
    published?: Timestamp;
    /**
     * When entity was featured or unset if not featured
     *
     * @generated from field: optional google.protobuf.Timestamp featured = 9;
     */
    featured?: Timestamp;
    /**
     * Entity owner
     *
     * @generated from oneof avn.connect.v1.EntityInfo.owner
     */
    owner: {
        /**
         * Organization owner (if not zero)
         *
         * @generated from field: int32 organization_id = 10;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * User owner (if not zero)
         *
         * @generated from field: int32 user_id = 11;
         */
        value: number;
        case: "userId";
    } | {
        case: undefined;
        value?: undefined;
    };
    /**
     * Search relevance (natural language search only)
     *
     * @generated from field: optional float search_distance = 12;
     */
    searchDistance?: number;
    /**
     * Is the entity licensed?
     *
     * @generated from field: bool licensed = 23;
     */
    licensed: boolean;
    /**
     * Is the entity permitted?
     *
     * @generated from field: bool permitted = 24;
     */
    permitted: boolean;
    /**
     * Is the entity available to use through licensing or content permissions?
     *
     * @generated from field: bool available = 20;
     */
    available: boolean;
    /**
     * Activity asset ID
     *
     * @generated from field: optional string asset_id = 21;
     */
    assetId?: string;
    /**
     * Activity size in bytes
     *
     * @generated from field: optional int64 size_bytes = 22;
     */
    sizeBytes?: bigint;
    /**
     * Number of child entities
     *
     * @generated from field: optional int32 item_count = 30;
     */
    itemCount?: number;
    /**
     * Number of child tracks (a subset of entities) for display purposes
     *
     * @generated from field: optional int32 track_count = 31;
     */
    trackCount?: number;
};
/**
 * Describes the message avn.connect.v1.EntityInfo.
 * Use `create(EntityInfoSchema)` to create a new message.
 */
declare const EntityInfoSchema: GenMessage<EntityInfo>;
/**
 * Common request signatures for entity types
 *
 * @generated from message avn.connect.v1.GetEntityRequest
 */
type GetEntityRequest = Message<"avn.connect.v1.GetEntityRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Requested entity ID
     *
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 3;
     */
    translate?: TranslationSpec;
    /**
     * Icon transcoding instructions. No icon is returned if this is unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec icon_spec = 4;
     */
    iconSpec?: TranscodeImageSpec;
    /**
     * Preview transcoding instructions. No preview is returned if this is unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec preview_spec = 5;
     */
    previewSpec?: TranscodeImageSpec;
};
/**
 * Describes the message avn.connect.v1.GetEntityRequest.
 * Use `create(GetEntityRequestSchema)` to create a new message.
 */
declare const GetEntityRequestSchema: GenMessage<GetEntityRequest>;
/**
 * Common request for entity creation
 *
 * @generated from message avn.connect.v1.CreateEntityRequest
 */
type CreateEntityRequest = Message<"avn.connect.v1.CreateEntityRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Entities with no organization belong to the creating user by default
     *
     * @generated from field: optional int32 organization_id = 2;
     */
    organizationId?: number;
    /**
     * Override to the user agent language
     *
     * @generated from field: optional string language_id = 3;
     */
    languageId?: string;
};
/**
 * Describes the message avn.connect.v1.CreateEntityRequest.
 * Use `create(CreateEntityRequestSchema)` to create a new message.
 */
declare const CreateEntityRequestSchema: GenMessage<CreateEntityRequest>;
/**
 * Common response for entity creation
 *
 * @generated from message avn.connect.v1.CreateEntityResponse
 */
type CreateEntityResponse = Message<"avn.connect.v1.CreateEntityResponse"> & {
    /**
     * ID of the new entity
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
};
/**
 * Describes the message avn.connect.v1.CreateEntityResponse.
 * Use `create(CreateEntityResponseSchema)` to create a new message.
 */
declare const CreateEntityResponseSchema: GenMessage<CreateEntityResponse>;
/**
 * Common request for entity deletion
 *
 * @generated from message avn.connect.v1.DeleteEntityRequest
 */
type DeleteEntityRequest = Message<"avn.connect.v1.DeleteEntityRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * ID of entity to delete
     *
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
};
/**
 * Describes the message avn.connect.v1.DeleteEntityRequest.
 * Use `create(DeleteEntityRequestSchema)` to create a new message.
 */
declare const DeleteEntityRequestSchema: GenMessage<DeleteEntityRequest>;
/**
 * Common request for entity copying
 *
 * @generated from message avn.connect.v1.CopyEntityRequest
 */
type CopyEntityRequest = Message<"avn.connect.v1.CopyEntityRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Organization to copy entity into
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
    /**
     * Target entity to copy
     *
     * @generated from field: int32 target_id = 3;
     */
    targetId: number;
};
/**
 * Describes the message avn.connect.v1.CopyEntityRequest.
 * Use `create(CopyEntityRequestSchema)` to create a new message.
 */
declare const CopyEntityRequestSchema: GenMessage<CopyEntityRequest>;
/**
 * Common request for entity listing
 *
 * @generated from message avn.connect.v1.EntityInfoListRequest
 */
type EntityInfoListRequest = Message<"avn.connect.v1.EntityInfoListRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * IDs of container elements (e.g. categories) or owner organizations to search
     *
     * @generated from field: repeated int32 entity_ids = 2;
     */
    entityIds: number[];
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 3;
     */
    translate?: TranslationSpec;
    /**
     * Search text fields
     *
     * @generated from field: optional avn.connect.v1.TextSearch text_search = 4;
     */
    textSearch?: TextSearch;
    /**
     * Return entities for which all the TagFilters are true
     *
     * @generated from field: repeated avn.connect.v1.TagFilter tag_filters = 5;
     */
    tagFilters: TagFilter[];
    /**
     * Clauses to order the results by
     *
     * @generated from field: repeated avn.connect.v1.OrderClause order_by = 7;
     */
    orderBy: OrderClause[];
    /**
     * Maximum number of results to return. Defaults to 30 when unset or 0, and is clamped to a
     * maximum of 256. Negative values are rejected. A page may contain fewer results than
     * page_size even when further pages exist: the presence of next_page_token, not page fill,
     * signals whether to keep asking.
     *
     * @generated from field: optional int32 page_size = 8;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search. Must be a token returned as next_page_token by an
     * earlier call; malformed tokens are rejected rather than returning an empty page.
     *
     * @generated from field: optional string page_token = 9;
     */
    pageToken?: string;
    /**
     * Icon transcoding instructions. No icon is returned if this in unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec icon_spec = 10;
     */
    iconSpec?: TranscodeImageSpec;
    /**
     * Preview transcoding instructions. No preview is returned if this is unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec preview_spec = 11;
     */
    previewSpec?: TranscodeImageSpec;
    /**
     * Cutoff for vector search results. Vector searches return the closest match per entity and
     * serve a bounded depth (currently the top 500 distinct entities); past that the search
     * reports end-of-results rather than paging indefinitely.
     *
     * @generated from field: optional float search_distance_threshold = 12;
     */
    searchDistanceThreshold?: number;
};
/**
 * Describes the message avn.connect.v1.EntityInfoListRequest.
 * Use `create(EntityInfoListRequestSchema)` to create a new message.
 */
declare const EntityInfoListRequestSchema: GenMessage<EntityInfoListRequest>;
/**
 * Common response for entity lists
 *
 * @generated from message avn.connect.v1.EntityInfoListResponse
 */
type EntityInfoListResponse = Message<"avn.connect.v1.EntityInfoListResponse"> & {
    /**
     * Search results
     *
     * @generated from field: repeated avn.connect.v1.EntityInfo results = 1;
     */
    results: EntityInfo[];
    /**
     * Token to use to get more pages of results or unset if no more results are available
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.EntityInfoListResponse.
 * Use `create(EntityInfoListResponseSchema)` to create a new message.
 */
declare const EntityInfoListResponseSchema: GenMessage<EntityInfoListResponse>;
/**
 * Common request for adding child entities to collections
 *
 * @generated from message avn.connect.v1.AddChildrenRequest
 */
type AddChildrenRequest = Message<"avn.connect.v1.AddChildrenRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * ID of the parent
     *
     * @generated from field: int32 parent_id = 2;
     */
    parentId: number;
    /**
     * IDs of the children to add.
     * Order is significant: it sets the display/sort order of the children.
     *
     * @generated from field: repeated int32 child_ids = 3;
     */
    childIds: number[];
    /**
     * If true, the parent's existing children are all removed first and the result becomes exactly child_ids, in the given order (any children not listed are removed).
     * If false (the default), child_ids are appended after the existing children.
     *
     * @generated from field: optional bool replace_all = 4;
     */
    replaceAll?: boolean;
};
/**
 * Describes the message avn.connect.v1.AddChildrenRequest.
 * Use `create(AddChildrenRequestSchema)` to create a new message.
 */
declare const AddChildrenRequestSchema: GenMessage<AddChildrenRequest>;
/**
 * Common request for removing child entities from collections
 *
 * @generated from message avn.connect.v1.RemoveChildrenRequest
 */
type RemoveChildrenRequest = Message<"avn.connect.v1.RemoveChildrenRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * ID of the parent
     *
     * @generated from field: int32 parent_id = 2;
     */
    parentId: number;
    /**
     * IDS of the children to remove
     *
     * @generated from field: repeated int32 child_ids = 3;
     */
    childIds: number[];
};
/**
 * Describes the message avn.connect.v1.RemoveChildrenRequest.
 * Use `create(RemoveChildrenRequestSchema)` to create a new message.
 */
declare const RemoveChildrenRequestSchema: GenMessage<RemoveChildrenRequest>;
/**
 * Content entity types
 *
 * @generated from enum avn.connect.v1.EntityType
 */
declare enum EntityType {
    /**
     * @generated from enum value: ENTITY_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Activity
     *
     * @generated from enum value: ENTITY_TYPE_ACTIVITY = 1;
     */
    ACTIVITY = 1,
    /**
     * Category
     *
     * @generated from enum value: ENTITY_TYPE_CATEGORY = 2;
     */
    CATEGORY = 2,
    /**
     * Profile
     *
     * @generated from enum value: ENTITY_TYPE_PROFILE = 3;
     */
    PROFILE = 3
}
/**
 * Describes the enum avn.connect.v1.EntityType.
 */
declare const EntityTypeSchema: GenEnum<EntityType>;

/**
 * Describes the file avn/connect/v1/metadata.proto.
 */
declare const file_avn_connect_v1_metadata: GenFile;
/**
 * Entity metadata entry
 *
 * @generated from message avn.connect.v1.EntityMetadata
 */
type EntityMetadata = Message<"avn.connect.v1.EntityMetadata"> & {
    /**
     * Entity ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Metadata key
     * - For GET operations this should be set to return a specific entry or blank to return all entries
     * - For SET operations this must always be set
     *
     * @generated from field: optional string key = 2;
     */
    key?: string;
    /**
     * Metadate value
     * - For GET operations this will contain the metadata value or be unset if no matching key entry was found
     * - For SET operations this must be set to add the metadata pair or unset to delete any existing matching key
     *
     * @generated from field: optional string value = 3;
     */
    value?: string;
};
/**
 * Describes the message avn.connect.v1.EntityMetadata.
 * Use `create(EntityMetadataSchema)` to create a new message.
 */
declare const EntityMetadataSchema: GenMessage<EntityMetadata>;
/**
 * Request for getting and setting metadata
 *
 * @generated from message avn.connect.v1.MetadataRequest
 */
type MetadataRequest = Message<"avn.connect.v1.MetadataRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Requested metadata
     *
     * @generated from field: avn.connect.v1.EntityMetadata metadata = 2;
     */
    metadata?: EntityMetadata;
};
/**
 * Describes the message avn.connect.v1.MetadataRequest.
 * Use `create(MetadataRequestSchema)` to create a new message.
 */
declare const MetadataRequestSchema: GenMessage<MetadataRequest>;
/**
 * Metadata request response
 *
 * @generated from message avn.connect.v1.GetMetadataResponse
 */
type GetMetadataResponse = Message<"avn.connect.v1.GetMetadataResponse"> & {
    /**
     * Metadata results
     *
     * @generated from field: repeated avn.connect.v1.EntityMetadata results = 1;
     */
    results: EntityMetadata[];
};
/**
 * Describes the message avn.connect.v1.GetMetadataResponse.
 * Use `create(GetMetadataResponseSchema)` to create a new message.
 */
declare const GetMetadataResponseSchema: GenMessage<GetMetadataResponse>;
/**
 * Filter entities by a metadata key and how its value matches.
 * Multiple filters combine with AND, matching TagFilter semantics.
 *
 * @generated from message avn.connect.v1.MetadataFilter
 */
type MetadataFilter = Message<"avn.connect.v1.MetadataFilter"> & {
    /**
     * Metadata key to filter on (exact, case-sensitive - matches SetMetadata keys)
     *
     * @generated from field: string key = 1;
     */
    key: string;
    /**
     * Condition to use when filtering
     *
     * @generated from field: avn.connect.v1.MetadataFilterCondition condition = 2;
     */
    condition: MetadataFilterCondition;
    /**
     * Text to match values against (ignored for the presence conditions)
     *
     * @generated from field: optional string match = 3;
     */
    match?: string;
};
/**
 * Describes the message avn.connect.v1.MetadataFilter.
 * Use `create(MetadataFilterSchema)` to create a new message.
 */
declare const MetadataFilterSchema: GenMessage<MetadataFilter>;
/**
 * @generated from enum avn.connect.v1.MetadataFilterCondition
 */
declare enum MetadataFilterCondition {
    /**
     * @generated from enum value: METADATA_FILTER_CONDITION_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Entity has the key, with any value
     *
     * @generated from enum value: METADATA_FILTER_CONDITION_HAS_KEY = 1;
     */
    HAS_KEY = 1,
    /**
     * Entity does not have the key
     *
     * @generated from enum value: METADATA_FILTER_CONDITION_HAS_NOT_KEY = 2;
     */
    HAS_NOT_KEY = 2,
    /**
     * Value equals match text (case-insensitive)
     *
     * @generated from enum value: METADATA_FILTER_CONDITION_EQUALS = 3;
     */
    EQUALS = 3,
    /**
     * Value starts with match text (case-insensitive)
     *
     * @generated from enum value: METADATA_FILTER_CONDITION_STARTS_WITH = 4;
     */
    STARTS_WITH = 4,
    /**
     * Value contains match text (case-insensitive)
     *
     * @generated from enum value: METADATA_FILTER_CONDITION_CONTAINS = 5;
     */
    CONTAINS = 5
}
/**
 * Describes the enum avn.connect.v1.MetadataFilterCondition.
 */
declare const MetadataFilterConditionSchema: GenEnum<MetadataFilterCondition>;

/**
 * Describes the file avn/connect/v1/packages.proto.
 */
declare const file_avn_connect_v1_packages: GenFile;
/**
 * An installable APK variant of an APP activity. An activity carries one package per release
 * channel (and, where builds are architecture specific, per ABI); a headset installs the most
 * specific variant it is entitled to: highest channel access level first, then ABI, then min SDK
 *
 * @generated from message avn.connect.v1.AndroidPackage
 */
type AndroidPackage = Message<"avn.connect.v1.AndroidPackage"> & {
    /**
     * Android package ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Associated activity
     *
     * @generated from field: int32 activity_id = 2;
     */
    activityId: number;
    /**
     * Software release channel targeted
     *
     * @generated from field: avn.connect.v1.ReleaseChannel channel = 3;
     */
    channel: ReleaseChannel;
    /**
     * Package name (Android application ID). Shared by every package of the activity and set on the
     * activity itself via ActivityService.SetProperties PACKAGE_NAME
     *
     * @generated from field: string package_name = 4;
     */
    packageName: string;
    /**
     * Package class. Shared by every package of the activity and set on the activity itself via
     * ActivityService.SetProperties PACKAGE_CLASS
     *
     * @generated from field: optional string package_class = 5;
     */
    packageClass?: string;
    /**
     * APK file
     *
     * @generated from field: string apk_url = 6;
     */
    apkUrl: string;
    /**
     * OBB main file
     *
     * @generated from field: optional string obb_main_url = 7;
     */
    obbMainUrl?: string;
    /**
     * OBB patch file
     *
     * @generated from field: optional string obb_patch_url = 8;
     */
    obbPatchUrl?: string;
    /**
     * Minimum Android SDK supported
     *
     * @generated from field: int32 min_sdk = 9;
     */
    minSdk: number;
    /**
     * Target ABI if architecture specific
     *
     * @generated from field: optional string target_abi = 10;
     */
    targetAbi?: string;
    /**
     * When the package was created
     *
     * @generated from field: google.protobuf.Timestamp created = 11;
     */
    created?: Timestamp;
    /**
     * When the package was last updated
     *
     * @generated from field: google.protobuf.Timestamp updated = 12;
     */
    updated?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.AndroidPackage.
 * Use `create(AndroidPackageSchema)` to create a new message.
 */
declare const AndroidPackageSchema: GenMessage<AndroidPackage>;
/**
 * @generated from message avn.connect.v1.GetAndroidPackageRequest
 */
type GetAndroidPackageRequest = Message<"avn.connect.v1.GetAndroidPackageRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Android package to fetch
     *
     * @generated from field: int32 package_id = 2;
     */
    packageId: number;
};
/**
 * Describes the message avn.connect.v1.GetAndroidPackageRequest.
 * Use `create(GetAndroidPackageRequestSchema)` to create a new message.
 */
declare const GetAndroidPackageRequestSchema: GenMessage<GetAndroidPackageRequest>;
/**
 * @generated from message avn.connect.v1.CreateAndroidPackageRequest
 */
type CreateAndroidPackageRequest = Message<"avn.connect.v1.CreateAndroidPackageRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * APP activity the package belongs to
     *
     * @generated from field: int32 activity_id = 2;
     */
    activityId: number;
    /**
     * Software release channel targeted (required)
     *
     * @generated from field: avn.connect.v1.ReleaseChannel channel = 3;
     */
    channel: ReleaseChannel;
    /**
     * AVNFS URL of the APK file
     *
     * @generated from field: optional string apk_url = 4;
     */
    apkUrl?: string;
    /**
     * AVNFS URL of the OBB main expansion file
     *
     * @generated from field: optional string obb_main_url = 5;
     */
    obbMainUrl?: string;
    /**
     * AVNFS URL of the OBB patch expansion file
     *
     * @generated from field: optional string obb_patch_url = 6;
     */
    obbPatchUrl?: string;
    /**
     * Minimum Android SDK (API level) supported; unset or 0 means unspecified
     *
     * @generated from field: optional int32 min_sdk = 7;
     */
    minSdk?: number;
    /**
     * Target CPU ABI when the build is architecture specific (arm64-v8a, armeabi-v7a, x86_64, x86); unset means any
     *
     * @generated from field: optional string target_abi = 8;
     */
    targetAbi?: string;
};
/**
 * Describes the message avn.connect.v1.CreateAndroidPackageRequest.
 * Use `create(CreateAndroidPackageRequestSchema)` to create a new message.
 */
declare const CreateAndroidPackageRequestSchema: GenMessage<CreateAndroidPackageRequest>;
/**
 * @generated from message avn.connect.v1.CreateAndroidPackageResponse
 */
type CreateAndroidPackageResponse = Message<"avn.connect.v1.CreateAndroidPackageResponse"> & {
    /**
     * ID of the created Android package
     *
     * @generated from field: int32 package_id = 1;
     */
    packageId: number;
};
/**
 * Describes the message avn.connect.v1.CreateAndroidPackageResponse.
 * Use `create(CreateAndroidPackageResponseSchema)` to create a new message.
 */
declare const CreateAndroidPackageResponseSchema: GenMessage<CreateAndroidPackageResponse>;
/**
 * @generated from message avn.connect.v1.DeleteAndroidPackageRequest
 */
type DeleteAndroidPackageRequest = Message<"avn.connect.v1.DeleteAndroidPackageRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Android package to delete
     *
     * @generated from field: int32 package_id = 2;
     */
    packageId: number;
};
/**
 * Describes the message avn.connect.v1.DeleteAndroidPackageRequest.
 * Use `create(DeleteAndroidPackageRequestSchema)` to create a new message.
 */
declare const DeleteAndroidPackageRequestSchema: GenMessage<DeleteAndroidPackageRequest>;
/**
 * @generated from enum avn.connect.v1.ReleaseChannel
 */
declare enum ReleaseChannel {
    /**
     * @generated from enum value: RELEASE_CHANNEL_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: RELEASE_CHANNEL_ALPHA = 1;
     */
    ALPHA = 1,
    /**
     * @generated from enum value: RELEASE_CHANNEL_BETA = 2;
     */
    BETA = 2,
    /**
     * @generated from enum value: RELEASE_CHANNEL_PRODUCTION = 3;
     */
    PRODUCTION = 3
}
/**
 * Describes the enum avn.connect.v1.ReleaseChannel.
 */
declare const ReleaseChannelSchema: GenEnum<ReleaseChannel>;
/**
 * Management of the Android packages (APK variants) of APP activities. Every operation is
 * authorised against the owning activity: reads need viewContent (or a published activity),
 * writes need editContent or personal ownership
 *
 * @generated from service avn.connect.v1.AndroidPackageService
 */
declare const AndroidPackageService: GenService<{
    /**
     * Get an Android package from its ID
     *
     * @generated from rpc avn.connect.v1.AndroidPackageService.GetAndroidPackage
     */
    getAndroidPackage: {
        methodKind: "unary";
        input: typeof GetAndroidPackageRequestSchema;
        output: typeof AndroidPackageSchema;
    };
    /**
     * Create an Android package for an APP activity
     *
     * @generated from rpc avn.connect.v1.AndroidPackageService.CreateAndroidPackage
     */
    createAndroidPackage: {
        methodKind: "unary";
        input: typeof CreateAndroidPackageRequestSchema;
        output: typeof CreateAndroidPackageResponseSchema;
    };
    /**
     * Delete an Android package
     *
     * @generated from rpc avn.connect.v1.AndroidPackageService.DeleteAndroidPackage
     */
    deleteAndroidPackage: {
        methodKind: "unary";
        input: typeof DeleteAndroidPackageRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get specific properties of one or more Android packages. Supports RELEASE_CHANNEL, APK_URL, OBB_MAIN_URL, OBB_PATCH_URL, MIN_SDK, TARGET_ABI, PARENT_ID, CREATED, UPDATED
     *
     * @generated from rpc avn.connect.v1.AndroidPackageService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetEntityPropertiesRequestSchema;
        output: typeof GetEntityPropertiesResponseSchema;
    };
    /**
     * Set the properties of one or more Android packages. Supports RELEASE_CHANNEL, APK_URL, OBB_MAIN_URL, OBB_PATCH_URL, MIN_SDK, TARGET_ABI
     *
     * @generated from rpc avn.connect.v1.AndroidPackageService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetEntityPropertiesRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/activities.proto.
 */
declare const file_avn_connect_v1_activities: GenFile;
/**
 * @generated from message avn.connect.v1.Activity
 */
type Activity = Message<"avn.connect.v1.Activity"> & {
    /**
     * Unique activity ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Activity name stored in plain text format
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Icon URL for the activity. Accepted media types: image/png, image/jpeg, image/svg+xml
     *
     * @generated from field: string icon_url = 3;
     */
    iconUrl: string;
    /**
     * Preview image URL for the activity. Accepted media types: image/png, image/jpeg, image/svg+xml.
     *
     * @generated from field: string preview_url = 4;
     */
    previewUrl: string;
    /**
     * When activity last updated
     *
     * @generated from field: google.protobuf.Timestamp updated = 5;
     */
    updated?: Timestamp;
    /**
     * Activity summary stored in markdown format
     *
     * @generated from field: string summary = 22;
     */
    summary: string;
    /**
     * Activity description stored in markdown format
     *
     * @generated from field: string description = 6;
     */
    description: string;
    /**
     * Activity instructions stored in markdown format
     *
     * @generated from field: string instructions = 7;
     */
    instructions: string;
    /**
     * Activity keywords
     *
     * @generated from field: string keywords = 21;
     */
    keywords: string;
    /**
     * Content language
     *
     * @generated from field: string language_id = 8;
     */
    languageId: string;
    /**
     * Content tags
     *
     * @generated from field: repeated int32 tags = 9;
     */
    tags: number[];
    /**
     * When activity was published or unset if not published
     *
     * @generated from field: optional google.protobuf.Timestamp published = 10;
     */
    published?: Timestamp;
    /**
     * When activity was featured or unset if not featured
     *
     * @generated from field: optional google.protobuf.Timestamp featured = 11;
     */
    featured?: Timestamp;
    /**
     * Activity owner
     *
     * @generated from oneof avn.connect.v1.Activity.owner
     */
    owner: {
        /**
         * Organization owner (if not zero)
         *
         * @generated from field: int32 organization_id = 12;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * User owner (if not zero)
         *
         * @generated from field: int32 user_id = 13;
         */
        value: number;
        case: "userId";
    } | {
        case: undefined;
        value?: undefined;
    };
    /**
     * Has this activity been deleted?
     *
     * @generated from field: bool deleted = 14;
     */
    deleted: boolean;
    /**
     * Is the activity licensed?
     *
     * @generated from field: bool licensed = 23;
     */
    licensed: boolean;
    /**
     * Is the activity permitted?
     *
     * @generated from field: bool permitted = 24;
     */
    permitted: boolean;
    /**
     * Is the activity available to use?
     *
     * @generated from field: bool available = 15;
     */
    available: boolean;
    /**
     * Asset ID for the activity
     *
     * @generated from field: string asset_id = 16;
     */
    assetId: string;
    /**
     * An indication of the origin of the activity
     *
     * @generated from field: optional string context = 17;
     */
    context?: string;
    /**
     * Screenshot image URLs. Accepted media types: image/png, image/jpeg, image/svg+xml.
     *
     * @generated from field: repeated string screenshot_urls = 18;
     */
    screenshotUrls: string[];
    /**
     * Size of activity in bytes (estimated)
     *
     * @generated from field: optional int64 size_bytes = 19;
     */
    sizeBytes?: bigint;
    /**
     * Type of the activity
     *
     * @generated from field: avn.connect.v1.ActivityType type = 20;
     */
    type: ActivityType;
    /**
     * Content URL (ACTIVITY_TYPE_URL only)
     *
     * @generated from field: optional string url = 31;
     */
    url?: string;
    /**
     * Array of data files. Primary content for ACTIVITY_TYPE_FILE; for other types (e.g. ACTIVITY_TYPE_APP) these are
     * supplementary assets that clients should pre-download so the activity is ready to launch
     *
     * @generated from field: repeated string file_urls = 32;
     */
    fileUrls: string[];
    /**
     * Array of android package definitions (ACTIVITY_TYPE_APP only)
     *
     * @generated from field: repeated avn.connect.v1.AndroidPackage android_packages = 33;
     */
    androidPackages: AndroidPackage[];
    /**
     * Structured metadata key/value pairs (see GetMetadata / SetMetadata)
     *
     * @generated from field: map<string, string> metadata = 34;
     */
    metadata: {
        [key: string]: string;
    };
};
/**
 * Describes the message avn.connect.v1.Activity.
 * Use `create(ActivitySchema)` to create a new message.
 */
declare const ActivitySchema: GenMessage<Activity>;
/**
 * Activities must have a type, so this interface is an extension of CreateEntityRequest
 *
 * @generated from message avn.connect.v1.CreateActivityRequest
 */
type CreateActivityRequest = Message<"avn.connect.v1.CreateActivityRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Entities with no organization belong to the creating user by default
     *
     * @generated from field: optional int32 organization_id = 2;
     */
    organizationId?: number;
    /**
     * Language for activity
     *
     * @generated from field: optional string language_id = 3;
     */
    languageId?: string;
    /**
     * Activity type
     *
     * @generated from field: avn.connect.v1.ActivityType type = 4;
     */
    type: ActivityType;
};
/**
 * Describes the message avn.connect.v1.CreateActivityRequest.
 * Use `create(CreateActivityRequestSchema)` to create a new message.
 */
declare const CreateActivityRequestSchema: GenMessage<CreateActivityRequest>;
/**
 * @generated from message avn.connect.v1.AddActivityFilesRequest
 */
type AddActivityFilesRequest = Message<"avn.connect.v1.AddActivityFilesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Activity to modify
     *
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
    /**
     * Files to add to activity
     *
     * @generated from field: repeated string file_urls = 3;
     */
    fileUrls: string[];
    /**
     * File types to add to
     *
     * @generated from field: avn.connect.v1.ActivityFileType file_type = 4;
     */
    fileType: ActivityFileType;
    /**
     * Replace all existing files of target type? The default is false
     *
     * @generated from field: optional bool replace_all = 5;
     */
    replaceAll?: boolean;
};
/**
 * Describes the message avn.connect.v1.AddActivityFilesRequest.
 * Use `create(AddActivityFilesRequestSchema)` to create a new message.
 */
declare const AddActivityFilesRequestSchema: GenMessage<AddActivityFilesRequest>;
/**
 * @generated from message avn.connect.v1.RemoveActivityFilesRequest
 */
type RemoveActivityFilesRequest = Message<"avn.connect.v1.RemoveActivityFilesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Activity to modify
     *
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
    /**
     * Files to remove from activity
     *
     * @generated from field: repeated string file_urls = 3;
     */
    fileUrls: string[];
    /**
     * File types to remove from
     *
     * @generated from field: avn.connect.v1.ActivityFileType file_type = 4;
     */
    fileType: ActivityFileType;
};
/**
 * Describes the message avn.connect.v1.RemoveActivityFilesRequest.
 * Use `create(RemoveActivityFilesRequestSchema)` to create a new message.
 */
declare const RemoveActivityFilesRequestSchema: GenMessage<RemoveActivityFilesRequest>;
/**
 * Activity types
 *
 * @generated from enum avn.connect.v1.ActivityType
 */
declare enum ActivityType {
    /**
     * @generated from enum value: ACTIVITY_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * A file type activity
     *
     * @generated from enum value: ACTIVITY_TYPE_FILE = 1;
     */
    FILE = 1,
    /**
     * A URL type activity
     *
     * @generated from enum value: ACTIVITY_TYPE_URL = 2;
     */
    URL = 2,
    /**
     * An app type activity
     *
     * @generated from enum value: ACTIVITY_TYPE_APP = 3;
     */
    APP = 3,
    /**
     * A folder type activity
     *
     * @generated from enum value: ACTIVITY_TYPE_FOLDER = 4 [deprecated = true];
     * @deprecated
     */
    FOLDER = 4
}
/**
 * Describes the enum avn.connect.v1.ActivityType.
 */
declare const ActivityTypeSchema: GenEnum<ActivityType>;
/**
 * Activity file types
 *
 * @generated from enum avn.connect.v1.ActivityFileType
 */
declare enum ActivityFileType {
    /**
     * @generated from enum value: ACTIVITY_FILE_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Content data file
     *
     * @generated from enum value: ACTIVITY_FILE_TYPE_CONTENT = 1;
     */
    CONTENT = 1,
    /**
     * Screenshot date file
     *
     * @generated from enum value: ACTIVITY_FILE_TYPE_SCREENSHOT = 2;
     */
    SCREENSHOT = 2,
    /**
     * Activity package data file
     *
     * @generated from enum value: ACTIVITY_FILE_TYPE_PACKAGE = 3;
     */
    PACKAGE = 3
}
/**
 * Describes the enum avn.connect.v1.ActivityFileType.
 */
declare const ActivityFileTypeSchema: GenEnum<ActivityFileType>;
/**
 * @generated from service avn.connect.v1.ActivityService
 */
declare const ActivityService: GenService<{
    /**
     * Get an activity from an ID
     *
     * @generated from rpc avn.connect.v1.ActivityService.GetActivity
     */
    getActivity: {
        methodKind: "unary";
        input: typeof GetEntityRequestSchema;
        output: typeof ActivitySchema;
    };
    /**
     * Create an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.CreateActivity
     */
    createActivity: {
        methodKind: "unary";
        input: typeof CreateActivityRequestSchema;
        output: typeof CreateEntityResponseSchema;
    };
    /**
     * Delete an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.DeleteActivity
     */
    deleteActivity: {
        methodKind: "unary";
        input: typeof DeleteEntityRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Copy an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.CopyActivity
     */
    copyActivity: {
        methodKind: "unary";
        input: typeof CopyEntityRequestSchema;
        output: typeof CreateEntityResponseSchema;
    };
    /**
     * Get organization activities
     *
     * @generated from rpc avn.connect.v1.ActivityService.GetOrganizationActivities
     */
    getOrganizationActivities: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Get user activities
     *
     * @generated from rpc avn.connect.v1.ActivityService.GetUserActivities
     */
    getUserActivities: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Add files to an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.AddFiles
     */
    addFiles: {
        methodKind: "unary";
        input: typeof AddActivityFilesRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Remove files from an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.RemoveFiles
     */
    removeFiles: {
        methodKind: "unary";
        input: typeof RemoveActivityFilesRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Add tags to an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.AddTags
     */
    addTags: {
        methodKind: "unary";
        input: typeof AddTagsRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Remove tags from an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.RemoveTags
     */
    removeTags: {
        methodKind: "unary";
        input: typeof RemoveTagsRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get metadata from an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.GetMetadata
     */
    getMetadata: {
        methodKind: "unary";
        input: typeof MetadataRequestSchema;
        output: typeof GetMetadataResponseSchema;
    };
    /**
     * Set metadata for an activity
     *
     * @generated from rpc avn.connect.v1.ActivityService.SetMetadata
     */
    setMetadata: {
        methodKind: "unary";
        input: typeof MetadataRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get specific properties of one or more activities. Supports NAME, SUMMARY, DESCRIPTION, INSTRUCTIONS, KEYWORDS, ICON_URL, PREVIEW_URL, PUBLISHED, ASSET_ID, WEBSITE_URL, CONTEXT, LANGUAGE_ID, LICENSED, PERMITTED, SIZE, UPDATED, FEATURED, ENTITY_TYPE, ORGANIZATION_ID, PACKAGE_NAME, PACKAGE_CLASS
     *
     * @generated from rpc avn.connect.v1.ActivityService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetEntityPropertiesRequestSchema;
        output: typeof GetEntityPropertiesResponseSchema;
    };
    /**
     * Set the properties of one or more activities. Supports NAME, SUMMARY, DESCRIPTION, INSTRUCTIONS, KEYWORDS, ICON_URL, PUBLISHED, FEATURED, ASSET_ID, WEBSITE_URL, CONTEXT, LANGUAGE_ID, ORGANIZATION_ID, PACKAGE_NAME, PACKAGE_CLASS
     *
     * @generated from rpc avn.connect.v1.ActivityService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetEntityPropertiesRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/http.proto.
 */
declare const file_avn_connect_v1_http: GenFile;
/**
 * @generated from message avn.connect.v1.HeaderField
 */
type HeaderField = Message<"avn.connect.v1.HeaderField"> & {
    /**
     * @generated from field: string name = 1;
     */
    name: string;
    /**
     * @generated from field: string value = 2;
     */
    value: string;
};
/**
 * Describes the message avn.connect.v1.HeaderField.
 * Use `create(HeaderFieldSchema)` to create a new message.
 */
declare const HeaderFieldSchema: GenMessage<HeaderField>;

/**
 * Describes the file avn/connect/v1/avnfs.proto.
 */
declare const file_avn_connect_v1_avnfs: GenFile;
/**
 * @generated from message avn.connect.v1.GetFileUrlRequest
 */
type GetFileUrlRequest = Message<"avn.connect.v1.GetFileUrlRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 5;
     */
    auth?: Authorization;
    /**
     * base64url encoded SHA256 hash of the file contents
     *
     * @generated from field: string hash = 1;
     */
    hash: string;
    /**
     * size in bytes
     *
     * @generated from field: int64 size_bytes = 2;
     */
    sizeBytes: bigint;
    /**
     * media type
     *
     * @generated from field: string media_type = 3;
     */
    mediaType: string;
    /**
     * filename (optional and only modifies the returned URL)
     *
     * @generated from field: optional string file_name = 4;
     */
    fileName?: string;
};
/**
 * Describes the message avn.connect.v1.GetFileUrlRequest.
 * Use `create(GetFileUrlRequestSchema)` to create a new message.
 */
declare const GetFileUrlRequestSchema: GenMessage<GetFileUrlRequest>;
/**
 * @generated from message avn.connect.v1.GetFileUrlResponse
 */
type GetFileUrlResponse = Message<"avn.connect.v1.GetFileUrlResponse"> & {
    /**
     * Only set if the file already exists
     *
     * @generated from field: optional string url = 1;
     */
    url?: string;
};
/**
 * Describes the message avn.connect.v1.GetFileUrlResponse.
 * Use `create(GetFileUrlResponseSchema)` to create a new message.
 */
declare const GetFileUrlResponseSchema: GenMessage<GetFileUrlResponse>;
/**
 * @generated from message avn.connect.v1.ImportUrlRequest
 */
type ImportUrlRequest = Message<"avn.connect.v1.ImportUrlRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The remote server URL to import
     *
     * @generated from field: string url = 2;
     */
    url: string;
    /**
     * Override for the media type the remote server returns
     *
     * @generated from field: optional string media_type = 3;
     */
    mediaType?: string;
    /**
     * Additional headers to pass through to the remote server
     *
     * @generated from field: map<string, string> headers = 4;
     */
    headers: {
        [key: string]: string;
    };
};
/**
 * Describes the message avn.connect.v1.ImportUrlRequest.
 * Use `create(ImportUrlRequestSchema)` to create a new message.
 */
declare const ImportUrlRequestSchema: GenMessage<ImportUrlRequest>;
/**
 * @generated from message avn.connect.v1.ImportUrlResponse
 */
type ImportUrlResponse = Message<"avn.connect.v1.ImportUrlResponse"> & {
    /**
     * The AVNFS URL of the imported file
     *
     * @generated from field: string url = 1;
     */
    url: string;
};
/**
 * Describes the message avn.connect.v1.ImportUrlResponse.
 * Use `create(ImportUrlResponseSchema)` to create a new message.
 */
declare const ImportUrlResponseSchema: GenMessage<ImportUrlResponse>;
/**
 * @generated from message avn.connect.v1.GetManifestRequest
 */
type GetManifestRequest = Message<"avn.connect.v1.GetManifestRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * base64url encoded SHA256 hash of the file contents
     *
     * @generated from field: string hash = 2;
     */
    hash: string;
    /**
     * size in bytes for checking against allowances
     *
     * @generated from field: int64 size_bytes = 3;
     */
    sizeBytes: bigint;
    /**
     * media types are expected to be overriden in the reference URL, but this might be useful for post-processing actions
     *
     * @generated from field: string media_type = 4;
     */
    mediaType: string;
    /**
     * filename (optional and only modifies the returned URL)
     *
     * @generated from field: optional string file_name = 5;
     */
    fileName?: string;
};
/**
 * Describes the message avn.connect.v1.GetManifestRequest.
 * Use `create(GetManifestRequestSchema)` to create a new message.
 */
declare const GetManifestRequestSchema: GenMessage<GetManifestRequest>;
/**
 * @generated from message avn.connect.v1.UploadManifest
 */
type UploadManifest = Message<"avn.connect.v1.UploadManifest"> & {
    /**
     * URL to upload to
     *
     * @generated from field: string upload_url = 1;
     */
    uploadUrl: string;
    /**
     * Eventual download URL
     *
     * @generated from field: string download_url = 2;
     */
    downloadUrl: string;
    /**
     * Additional fields to add to a POST
     *
     * @generated from field: repeated avn.connect.v1.HeaderField header_fields = 3;
     */
    headerFields: HeaderField[];
};
/**
 * Describes the message avn.connect.v1.UploadManifest.
 * Use `create(UploadManifestSchema)` to create a new message.
 */
declare const UploadManifestSchema: GenMessage<UploadManifest>;
/**
 * @generated from message avn.connect.v1.AltServer
 */
type AltServer = Message<"avn.connect.v1.AltServer"> & {
    /**
     * @generated from field: avn.connect.v1.AltServerType type = 1;
     */
    type: AltServerType;
    /**
     * @generated from field: string client_name = 2;
     */
    clientName: string;
    /**
     * @generated from field: string client_id = 3;
     */
    clientId: string;
    /**
     * @generated from field: repeated string hosts = 4;
     */
    hosts: string[];
};
/**
 * Describes the message avn.connect.v1.AltServer.
 * Use `create(AltServerSchema)` to create a new message.
 */
declare const AltServerSchema: GenMessage<AltServer>;
/**
 * @generated from message avn.connect.v1.GetAltServersRequest
 */
type GetAltServersRequest = Message<"avn.connect.v1.GetAltServersRequest"> & {};
/**
 * Describes the message avn.connect.v1.GetAltServersRequest.
 * Use `create(GetAltServersRequestSchema)` to create a new message.
 */
declare const GetAltServersRequestSchema: GenMessage<GetAltServersRequest>;
/**
 * @generated from message avn.connect.v1.GetAltServersResponse
 */
type GetAltServersResponse = Message<"avn.connect.v1.GetAltServersResponse"> & {
    /**
     * @generated from field: repeated avn.connect.v1.AltServer servers = 1;
     */
    servers: AltServer[];
};
/**
 * Describes the message avn.connect.v1.GetAltServersResponse.
 * Use `create(GetAltServersResponseSchema)` to create a new message.
 */
declare const GetAltServersResponseSchema: GenMessage<GetAltServersResponse>;
/**
 * @generated from enum avn.connect.v1.AltServerType
 */
declare enum AltServerType {
    /**
     * @generated from enum value: ALT_SERVER_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: ALT_SERVER_TYPE_LAN = 1;
     */
    LAN = 1,
    /**
     * @generated from enum value: ALT_SERVER_TYPE_WAN = 2;
     */
    WAN = 2,
    /**
     * @generated from enum value: ALT_SERVER_TYPE_REGIONAL = 3;
     */
    REGIONAL = 3
}
/**
 * Describes the enum avn.connect.v1.AltServerType.
 */
declare const AltServerTypeSchema: GenEnum<AltServerType>;
/**
 * @generated from service avn.connect.v1.AvnfsService
 */
declare const AvnfsService: GenService<{
    /**
     * Verify file exists in AVNFS and return URL if it does
     *
     * @generated from rpc avn.connect.v1.AvnfsService.GetFileUrl
     */
    getFileUrl: {
        methodKind: "unary";
        input: typeof GetFileUrlRequestSchema;
        output: typeof GetFileUrlResponseSchema;
    };
    /**
     * Get all the information required to HTTP POST a file to AVNFS
     *
     * @generated from rpc avn.connect.v1.AvnfsService.GetPostManifest
     */
    getPostManifest: {
        methodKind: "unary";
        input: typeof GetManifestRequestSchema;
        output: typeof UploadManifestSchema;
    };
    /**
     * Bring a remote file into AVNFS
     *
     * @generated from rpc avn.connect.v1.AvnfsService.ImportUrl
     */
    importUrl: {
        methodKind: "unary";
        input: typeof ImportUrlRequestSchema;
        output: typeof ImportUrlResponseSchema;
    };
    /**
     * Get alternative servers for downloading AVNFS files
     * These should be used in preference to avnfs.com when available
     *
     * @generated from rpc avn.connect.v1.AvnfsService.GetAltServers
     */
    getAltServers: {
        methodKind: "unary";
        input: typeof GetAltServersRequestSchema;
        output: typeof GetAltServersResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/blockade.proto.
 */
declare const file_avn_connect_v1_blockade: GenFile;
/**
 * @generated from message avn.connect.v1.BlockadeSkyboxStyleFamily
 */
type BlockadeSkyboxStyleFamily = Message<"avn.connect.v1.BlockadeSkyboxStyleFamily"> & {
    /**
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * @generated from field: repeated avn.connect.v1.BlockadeSkyboxStyle styles = 3;
     */
    styles: BlockadeSkyboxStyle[];
};
/**
 * Describes the message avn.connect.v1.BlockadeSkyboxStyleFamily.
 * Use `create(BlockadeSkyboxStyleFamilySchema)` to create a new message.
 */
declare const BlockadeSkyboxStyleFamilySchema: GenMessage<BlockadeSkyboxStyleFamily>;
/**
 * @generated from message avn.connect.v1.BlockadeSkyboxStyle
 */
type BlockadeSkyboxStyle = Message<"avn.connect.v1.BlockadeSkyboxStyle"> & {
    /**
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * @generated from field: optional string description = 3;
     */
    description?: string;
    /**
     * @generated from field: int32 max_prompt_size = 4;
     */
    maxPromptSize: number;
    /**
     * @generated from field: int32 max_negative_prompt_size = 5;
     */
    maxNegativePromptSize: number;
    /**
     * @generated from field: optional string preview_url = 6;
     */
    previewUrl?: string;
};
/**
 * Describes the message avn.connect.v1.BlockadeSkyboxStyle.
 * Use `create(BlockadeSkyboxStyleSchema)` to create a new message.
 */
declare const BlockadeSkyboxStyleSchema: GenMessage<BlockadeSkyboxStyle>;
/**
 * @generated from message avn.connect.v1.GetSkyboxStyleFamiliesRequest
 */
type GetSkyboxStyleFamiliesRequest = Message<"avn.connect.v1.GetSkyboxStyleFamiliesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 2;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetSkyboxStyleFamiliesRequest.
 * Use `create(GetSkyboxStyleFamiliesRequestSchema)` to create a new message.
 */
declare const GetSkyboxStyleFamiliesRequestSchema: GenMessage<GetSkyboxStyleFamiliesRequest>;
/**
 * @generated from message avn.connect.v1.GetSkyboxStyleFamiliesResponse
 */
type GetSkyboxStyleFamiliesResponse = Message<"avn.connect.v1.GetSkyboxStyleFamiliesResponse"> & {
    /**
     * @generated from field: repeated avn.connect.v1.BlockadeSkyboxStyleFamily families = 1;
     */
    families: BlockadeSkyboxStyleFamily[];
};
/**
 * Describes the message avn.connect.v1.GetSkyboxStyleFamiliesResponse.
 * Use `create(GetSkyboxStyleFamiliesResponseSchema)` to create a new message.
 */
declare const GetSkyboxStyleFamiliesResponseSchema: GenMessage<GetSkyboxStyleFamiliesResponse>;
/**
 * The work itself: payload of a first (submitting) GenerateSkybox call.
 *
 * @generated from message avn.connect.v1.GenerateSkyboxTask
 */
type GenerateSkyboxTask = Message<"avn.connect.v1.GenerateSkyboxTask"> & {
    /**
     * @generated from field: int32 skybox_style_id = 1;
     */
    skyboxStyleId: number;
    /**
     * @generated from field: string prompt = 2;
     */
    prompt: string;
    /**
     * @generated from field: optional string negative_prompt = 3;
     */
    negativePrompt?: string;
    /**
     * @generated from field: optional string control_image_url = 4;
     */
    controlImageUrl?: string;
    /**
     * @generated from field: bool enhance_prompt = 5;
     */
    enhancePrompt: boolean;
    /**
     * Override to the user agent language
     *
     * @generated from field: optional string language_id = 6;
     */
    languageId?: string;
    /**
     * The seed used to generate the image; may be set by the returned image when cached
     *
     * @generated from field: optional int32 seed = 7;
     */
    seed?: number;
    /**
     * License context to use independent of authorization
     *
     * @generated from field: int32 context_organization_id = 8;
     */
    contextOrganizationId: number;
};
/**
 * Describes the message avn.connect.v1.GenerateSkyboxTask.
 * Use `create(GenerateSkyboxTaskSchema)` to create a new message.
 */
declare const GenerateSkyboxTaskSchema: GenMessage<GenerateSkyboxTask>;
/**
 * @generated from message avn.connect.v1.GenerateSkyboxRequest
 */
type GenerateSkyboxRequest = Message<"avn.connect.v1.GenerateSkyboxRequest"> & {
    /**
     * Authorization for the request. Polls must come from the user that submitted
     * the task; other callers see NOT_FOUND.
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Seconds to wait inline for a terminal state before returning the current
     * state. Clamped server-side to a safe maximum; unset uses the server default
     * and 0 polls without blocking.
     *
     * @generated from field: optional float wait_seconds = 2;
     */
    waitSeconds?: number;
    /**
     * Exactly one of these must be set.
     *
     * @generated from oneof avn.connect.v1.GenerateSkyboxRequest.phase
     */
    phase: {
        /**
         * First call: submit this work, creating the job returned in the response.
         *
         * @generated from field: avn.connect.v1.GenerateSkyboxTask task = 3;
         */
        value: GenerateSkyboxTask;
        case: "task";
    } | {
        /**
         * Subsequent calls: poll an earlier submission using its `job.id` from the
         * response envelope, until `job.state` is terminal.
         *
         * @generated from field: string job_id = 4;
         */
        value: string;
        case: "jobId";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message avn.connect.v1.GenerateSkyboxRequest.
 * Use `create(GenerateSkyboxRequestSchema)` to create a new message.
 */
declare const GenerateSkyboxRequestSchema: GenMessage<GenerateSkyboxRequest>;
/**
 * @generated from message avn.connect.v1.GenerateSkyboxResponse
 */
type GenerateSkyboxResponse = Message<"avn.connect.v1.GenerateSkyboxResponse"> & {
    /**
     * Operation envelope. Poll `job.id` (via GenerateSkyboxRequest.job_id) until
     * `job.state` is terminal (COMPLETE on success, ERROR on failure). Progress is
     * reported on `job.progress`.
     *
     * @generated from field: avn.connect.v1.Job job = 1;
     */
    job?: Job;
    /**
     * Only set when job.state == COMPLETE
     *
     * @generated from field: optional avn.connect.v1.EntityInfo activity_info = 2;
     */
    activityInfo?: EntityInfo;
};
/**
 * Describes the message avn.connect.v1.GenerateSkyboxResponse.
 * Use `create(GenerateSkyboxResponseSchema)` to create a new message.
 */
declare const GenerateSkyboxResponseSchema: GenMessage<GenerateSkyboxResponse>;
/**
 * @generated from service avn.connect.v1.BlockadeService
 */
declare const BlockadeService: GenService<{
    /**
     * Generate a skybox image using the durable-job pattern (see Job in operations.proto)
     *
     * @generated from rpc avn.connect.v1.BlockadeService.GenerateSkybox
     */
    generateSkybox: {
        methodKind: "unary";
        input: typeof GenerateSkyboxRequestSchema;
        output: typeof GenerateSkyboxResponseSchema;
    };
    /**
     * @generated from rpc avn.connect.v1.BlockadeService.GetSkyboxStyleFamilies
     */
    getSkyboxStyleFamilies: {
        methodKind: "unary";
        input: typeof GetSkyboxStyleFamiliesRequestSchema;
        output: typeof GetSkyboxStyleFamiliesResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/categories.proto.
 */
declare const file_avn_connect_v1_categories: GenFile;
/**
 * @generated from message avn.connect.v1.Category
 */
type Category = Message<"avn.connect.v1.Category"> & {
    /**
     * Unique category ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Category name stored in plain text format
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Icon URL for the category. Accepted media types: image/png, image/jpeg, image/svg+xml
     *
     * @generated from field: string icon_url = 3;
     */
    iconUrl: string;
    /**
     * Preview image URL for the category. Accepted media types: image/png, image/jpeg, image/svg+xml
     *
     * @generated from field: string preview_url = 4;
     */
    previewUrl: string;
    /**
     * When category last updated
     *
     * @generated from field: google.protobuf.Timestamp updated = 5;
     */
    updated?: Timestamp;
    /**
     * Category summary stored in markdown format
     *
     * @generated from field: optional string summary = 22;
     */
    summary?: string;
    /**
     * Category description stored in markdown format
     *
     * @generated from field: optional string description = 6;
     */
    description?: string;
    /**
     * Category instructions stored in markdown format
     *
     * @generated from field: optional string instructions = 7;
     */
    instructions?: string;
    /**
     * Category keywords
     *
     * @generated from field: optional string keywords = 21;
     */
    keywords?: string;
    /**
     * Content language
     *
     * @generated from field: string language_id = 8;
     */
    languageId: string;
    /**
     * Content tags
     *
     * @generated from field: repeated int32 tags = 9;
     */
    tags: number[];
    /**
     * When category was published or unset if not published
     *
     * @generated from field: optional google.protobuf.Timestamp published = 10;
     */
    published?: Timestamp;
    /**
     * When category was featured or unset if not featured
     *
     * @generated from field: optional google.protobuf.Timestamp featured = 11;
     */
    featured?: Timestamp;
    /**
     * Category owner
     *
     * @generated from oneof avn.connect.v1.Category.owner
     */
    owner: {
        /**
         * Organization owner (if not zero)
         *
         * @generated from field: int32 organization_id = 12;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * User owner (if not zero)
         *
         * @generated from field: int32 user_id = 13;
         */
        value: number;
        case: "userId";
    } | {
        case: undefined;
        value?: undefined;
    };
    /**
     * Has this category been deleted?
     *
     * @generated from field: bool deleted = 14;
     */
    deleted: boolean;
    /**
     * Number of activities in this category
     *
     * @generated from field: int32 item_count = 15;
     */
    itemCount: number;
    /**
     * Number of activities in this category that are not supplementary materials
     *
     * @generated from field: int32 track_count = 16;
     */
    trackCount: number;
    /**
     * Is the category licensed?
     *
     * @generated from field: bool licensed = 23;
     */
    licensed: boolean;
    /**
     * Is the category permitted?
     *
     * @generated from field: bool permitted = 24;
     */
    permitted: boolean;
    /**
     * Is the category available to use?
     *
     * @generated from field: bool available = 25;
     */
    available: boolean;
};
/**
 * Describes the message avn.connect.v1.Category.
 * Use `create(CategorySchema)` to create a new message.
 */
declare const CategorySchema: GenMessage<Category>;
/**
 * @generated from service avn.connect.v1.CategoryService
 */
declare const CategoryService: GenService<{
    /**
     * Get a category from an ID
     *
     * @generated from rpc avn.connect.v1.CategoryService.GetCategory
     */
    getCategory: {
        methodKind: "unary";
        input: typeof GetEntityRequestSchema;
        output: typeof CategorySchema;
    };
    /**
     * Create a category for an organization or user
     *
     * @generated from rpc avn.connect.v1.CategoryService.CreateCategory
     */
    createCategory: {
        methodKind: "unary";
        input: typeof CreateEntityRequestSchema;
        output: typeof CreateEntityResponseSchema;
    };
    /**
     * Delete a category
     *
     * @generated from rpc avn.connect.v1.CategoryService.DeleteCategory
     */
    deleteCategory: {
        methodKind: "unary";
        input: typeof DeleteEntityRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Copy a category
     *
     * @generated from rpc avn.connect.v1.CategoryService.CopyCategory
     */
    copyCategory: {
        methodKind: "unary";
        input: typeof CopyEntityRequestSchema;
        output: typeof CreateEntityResponseSchema;
    };
    /**
     * Get the categories that belong to the requested organizations
     *
     * @generated from rpc avn.connect.v1.CategoryService.GetOrganizationCategories
     */
    getOrganizationCategories: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Get the categories that belong to the requested users
     *
     * @generated from rpc avn.connect.v1.CategoryService.GetUserCategories
     */
    getUserCategories: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Get all published activities in the given category
     *
     * @generated from rpc avn.connect.v1.CategoryService.GetActivities
     */
    getActivities: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Add activities to a category. child_ids are appended by default, or become the category's exact membership when replace_all is set. The order of child_ids is persisted as the activities' sort order.
     *
     * @generated from rpc avn.connect.v1.CategoryService.AddActivities
     */
    addActivities: {
        methodKind: "unary";
        input: typeof AddChildrenRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Remove an activity from a category
     *
     * @generated from rpc avn.connect.v1.CategoryService.RemoveActivities
     */
    removeActivities: {
        methodKind: "unary";
        input: typeof RemoveChildrenRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Add tags to a category
     *
     * @generated from rpc avn.connect.v1.CategoryService.AddTags
     */
    addTags: {
        methodKind: "unary";
        input: typeof AddTagsRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Remove tags from a category
     *
     * @generated from rpc avn.connect.v1.CategoryService.RemoveTags
     */
    removeTags: {
        methodKind: "unary";
        input: typeof RemoveTagsRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get the properties of one or more categories. Supports NAME, SUMMARY, DESCRIPTION, INSTRUCTIONS, KEYWORDS, LANGUAGE_ID, UPDATED, LICENSED, PERMITTED, ICON_URL, PREVIEW_URL, WALLPAPER_URL, PUBLISHED, FEATURED, ITEM_COUNT, TRACK_COUNT, ORGANIZATION_ID
     *
     * @generated from rpc avn.connect.v1.CategoryService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetEntityPropertiesRequestSchema;
        output: typeof GetEntityPropertiesResponseSchema;
    };
    /**
     * Set the properties of a category. Supports NAME, SUMMARY, DESCRIPTION, INSTRUCTIONS, KEYWORDS, ICON_URL, WALLPAPER_URL, PUBLISHED, LANGUAGE_ID, ORGANIZATION_ID
     *
     * @generated from rpc avn.connect.v1.CategoryService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetEntityPropertiesRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/certificates.proto.
 */
declare const file_avn_connect_v1_certificates: GenFile;
/**
 * @generated from message avn.connect.v1.Certificate
 */
type Certificate = Message<"avn.connect.v1.Certificate"> & {
    /**
     * SHA256 fingerprint
     *
     * @generated from field: string fingerprint = 1;
     */
    fingerprint: string;
    /**
     * Hostname that certificate is issued for
     *
     * @generated from field: string hostname = 2;
     */
    hostname: string;
    /**
     * Time range certificate is valid for
     *
     * @generated from field: google.protobuf.Timestamp valid_from = 3;
     */
    validFrom?: Timestamp;
    /**
     * @generated from field: google.protobuf.Timestamp valid_to = 4;
     */
    validTo?: Timestamp;
    /**
     * The private TLS certificate for servers
     *
     * @generated from field: string file_url = 5;
     */
    fileUrl: string;
    /**
     * The legacy certificate file is for use on legacy platforms like Mono
     *
     * @generated from field: string legacy_file_url = 6;
     */
    legacyFileUrl: string;
    /**
     * When the certificate was created
     *
     * @generated from field: google.protobuf.Timestamp created = 7;
     */
    created?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.Certificate.
 * Use `create(CertificateSchema)` to create a new message.
 */
declare const CertificateSchema: GenMessage<Certificate>;
/**
 * @generated from message avn.connect.v1.GetHostnameCertificatesRequest
 */
type GetHostnameCertificatesRequest = Message<"avn.connect.v1.GetHostnameCertificatesRequest"> & {
    /**
     * @generated from field: string hostname = 1;
     */
    hostname: string;
};
/**
 * Describes the message avn.connect.v1.GetHostnameCertificatesRequest.
 * Use `create(GetHostnameCertificatesRequestSchema)` to create a new message.
 */
declare const GetHostnameCertificatesRequestSchema: GenMessage<GetHostnameCertificatesRequest>;
/**
 * @generated from service avn.connect.v1.CertificateService
 */
declare const CertificateService: GenService<{
    /**
     * @generated from rpc avn.connect.v1.CertificateService.GetLatestCertificate
     */
    getLatestCertificate: {
        methodKind: "unary";
        input: typeof GetHostnameCertificatesRequestSchema;
        output: typeof CertificateSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/channels.proto.
 */
declare const file_avn_connect_v1_channels: GenFile;
/**
 * @generated from message avn.connect.v1.Channel
 */
type Channel = Message<"avn.connect.v1.Channel"> & {
    /**
     * ID of the channel entity
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Name of the channel stored in plain text format
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Icon URL for the channel. Accepted media types: image/png, image/jpeg, image/svg+xml
     *
     * @generated from field: string icon_url = 3;
     */
    iconUrl: string;
    /**
     * When channel was created
     *
     * @generated from field: google.protobuf.Timestamp created = 4;
     */
    created?: Timestamp;
    /**
     * When channel last updated
     *
     * @generated from field: google.protobuf.Timestamp updated = 5;
     */
    updated?: Timestamp;
    /**
     * Description of the channel stored in markdown format
     *
     * @generated from field: optional string description = 6;
     */
    description?: string;
    /**
     * Plan codes that enable this channel
     *
     * @generated from field: repeated string plan_codes = 7;
     */
    planCodes: string[];
    /**
     * When channel was published or unset if not published
     *
     * @generated from field: optional google.protobuf.Timestamp published = 8;
     */
    published?: Timestamp;
    /**
     * Is the channel licensed?
     *
     * @generated from field: bool licensed = 9;
     */
    licensed: boolean;
    /**
     * Is the channel permitted?
     *
     * @generated from field: bool permitted = 10;
     */
    permitted: boolean;
    /**
     * Is the channel available to use?
     *
     * @generated from field: bool available = 11;
     */
    available: boolean;
};
/**
 * Describes the message avn.connect.v1.Channel.
 * Use `create(ChannelSchema)` to create a new message.
 */
declare const ChannelSchema: GenMessage<Channel>;
/**
 * @generated from service avn.connect.v1.ChannelService
 */
declare const ChannelService: GenService<{
    /**
     * Get details for a specific channel
     *
     * @generated from rpc avn.connect.v1.ChannelService.GetChannel
     */
    getChannel: {
        methodKind: "unary";
        input: typeof GetEntityRequestSchema;
        output: typeof ChannelSchema;
    };
    /**
     * Get all channels available with the given authorization credentials
     *
     * @generated from rpc avn.connect.v1.ChannelService.GetBrowsableChannels
     */
    getBrowsableChannels: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Get all channels licensed with the given authorization credentials
     *
     * @generated from rpc avn.connect.v1.ChannelService.GetLicensedChannels
     */
    getLicensedChannels: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Bulk lookup of channel details by ID — utility for efficient batch fetches when channel IDs are already known. Not for general discovery; use SearchChannels or GetBrowsableChannels for that.
     *
     * @generated from rpc avn.connect.v1.ChannelService.GetBulkChannels
     */
    getBulkChannels: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Search published channels by name or description across all approved publishers.
     *
     * @generated from rpc avn.connect.v1.ChannelService.SearchChannels
     */
    searchChannels: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Search published profiles in the given set of channels.
     * All the profiles will belong to the channel, but the categories within those profiles may belong to other channels.
     *
     * @generated from rpc avn.connect.v1.ChannelService.SearchProfiles
     */
    searchProfiles: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Search published categories in the given set of channels.
     * All the categories will belong to the channel, but the activities within those categories may belong to other channels.
     *
     * @generated from rpc avn.connect.v1.ChannelService.SearchCategories
     */
    searchCategories: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Search published activities in the given set of channels. See eduverse://resources/searching-learning-resources for more details
     *
     * @generated from rpc avn.connect.v1.ChannelService.SearchActivities
     */
    searchActivities: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/clients.proto.
 */
declare const file_avn_connect_v1_clients: GenFile;
/**
 * @generated from message avn.connect.v1.RecordActionRequest
 */
type RecordActionRequest = Message<"avn.connect.v1.RecordActionRequest"> & {
    /**
     * Authorization info to provide context and permission
     *
     * @generated from field: avn.connect.v1.Authorization auth = 5;
     */
    auth?: Authorization;
    /**
     * Client ID (deprecated in favour of client credentials in the auth field)
     *
     * @generated from field: optional avn.connect.v1.ClientCredentials client = 1 [deprecated = true];
     * @deprecated
     */
    client?: ClientCredentials;
    /**
     * The action identifier
     *
     * @generated from field: string action_id = 2;
     */
    actionId: string;
    /**
     * The source of the action: button, anchor, etc...
     *
     * @generated from field: string source_id = 3;
     */
    sourceId: string;
    /**
     * The hosting platform, typically the web page hostname
     *
     * @generated from field: string host_id = 6;
     */
    hostId: string;
    /**
     * Optional extra data associated with the action
     *
     * @generated from field: optional google.protobuf.Struct data = 4;
     */
    data?: JsonObject;
};
/**
 * Describes the message avn.connect.v1.RecordActionRequest.
 * Use `create(RecordActionRequestSchema)` to create a new message.
 */
declare const RecordActionRequestSchema: GenMessage<RecordActionRequest>;
/**
 * @generated from message avn.connect.v1.RecordFeedbackRequest
 */
type RecordFeedbackRequest = Message<"avn.connect.v1.RecordFeedbackRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The feedback identifier
     *
     * @generated from field: string feedback_id = 2;
     */
    feedbackId: string;
    /**
     * The primary feedback reason ID
     *
     * @generated from field: string feedback_reason = 3;
     */
    feedbackReason: string;
    /**
     * Freeform details supplied by the user
     *
     * @generated from field: optional string feedback_detail = 4;
     */
    feedbackDetail?: string;
    /**
     * Optional extra structured data
     *
     * @generated from field: optional google.protobuf.Struct data = 5;
     */
    data?: JsonObject;
};
/**
 * Describes the message avn.connect.v1.RecordFeedbackRequest.
 * Use `create(RecordFeedbackRequestSchema)` to create a new message.
 */
declare const RecordFeedbackRequestSchema: GenMessage<RecordFeedbackRequest>;
/**
 * @generated from message avn.connect.v1.CreateClientCredentialsRequest
 */
type CreateClientCredentialsRequest = Message<"avn.connect.v1.CreateClientCredentialsRequest"> & {
    /**
     * Useful for user-friendly naming by prefixing
     *
     * @generated from field: optional string prefix = 1;
     */
    prefix?: string;
    /**
     * Useful for user-friendly naming by postfixing
     *
     * @generated from field: optional string postfix = 2;
     */
    postfix?: string;
};
/**
 * Describes the message avn.connect.v1.CreateClientCredentialsRequest.
 * Use `create(CreateClientCredentialsRequestSchema)` to create a new message.
 */
declare const CreateClientCredentialsRequestSchema: GenMessage<CreateClientCredentialsRequest>;
/**
 * @generated from message avn.connect.v1.CreateClientCredentialsResponse
 */
type CreateClientCredentialsResponse = Message<"avn.connect.v1.CreateClientCredentialsResponse"> & {
    /**
     * New client credentials
     *
     * @generated from field: avn.connect.v1.ClientCredentials client_credentials = 1;
     */
    clientCredentials?: ClientCredentials;
};
/**
 * Describes the message avn.connect.v1.CreateClientCredentialsResponse.
 * Use `create(CreateClientCredentialsResponseSchema)` to create a new message.
 */
declare const CreateClientCredentialsResponseSchema: GenMessage<CreateClientCredentialsResponse>;
/**
 * @generated from message avn.connect.v1.LighthouseServer
 */
type LighthouseServer = Message<"avn.connect.v1.LighthouseServer"> & {
    /**
     * @generated from field: string lighthouse_id = 1;
     */
    lighthouseId: string;
    /**
     * @generated from field: string wanAddress = 2;
     */
    wanAddress: string;
    /**
     * @generated from field: string wanHostname = 3;
     */
    wanHostname: string;
    /**
     * @generated from field: google.protobuf.Timestamp registered = 4;
     */
    registered?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.LighthouseServer.
 * Use `create(LighthouseServerSchema)` to create a new message.
 */
declare const LighthouseServerSchema: GenMessage<LighthouseServer>;
/**
 * @generated from message avn.connect.v1.RegisterLighthouseServerRequest
 */
type RegisterLighthouseServerRequest = Message<"avn.connect.v1.RegisterLighthouseServerRequest"> & {
    /**
     * @generated from field: avn.connect.v1.ClientCredentials client = 1;
     */
    client?: ClientCredentials;
};
/**
 * Describes the message avn.connect.v1.RegisterLighthouseServerRequest.
 * Use `create(RegisterLighthouseServerRequestSchema)` to create a new message.
 */
declare const RegisterLighthouseServerRequestSchema: GenMessage<RegisterLighthouseServerRequest>;
/**
 * @generated from message avn.connect.v1.RegisterLighthouseServerResponse
 */
type RegisterLighthouseServerResponse = Message<"avn.connect.v1.RegisterLighthouseServerResponse"> & {
    /**
     * @generated from field: avn.connect.v1.LighthouseServer server = 1;
     */
    server?: LighthouseServer;
};
/**
 * Describes the message avn.connect.v1.RegisterLighthouseServerResponse.
 * Use `create(RegisterLighthouseServerResponseSchema)` to create a new message.
 */
declare const RegisterLighthouseServerResponseSchema: GenMessage<RegisterLighthouseServerResponse>;
/**
 * @generated from message avn.connect.v1.GetLighthouseServersRequest
 */
type GetLighthouseServersRequest = Message<"avn.connect.v1.GetLighthouseServersRequest"> & {};
/**
 * Describes the message avn.connect.v1.GetLighthouseServersRequest.
 * Use `create(GetLighthouseServersRequestSchema)` to create a new message.
 */
declare const GetLighthouseServersRequestSchema: GenMessage<GetLighthouseServersRequest>;
/**
 * @generated from message avn.connect.v1.GetLighthouseServersResponse
 */
type GetLighthouseServersResponse = Message<"avn.connect.v1.GetLighthouseServersResponse"> & {
    /**
     * @generated from field: repeated avn.connect.v1.LighthouseServer servers = 1;
     */
    servers: LighthouseServer[];
};
/**
 * Describes the message avn.connect.v1.GetLighthouseServersResponse.
 * Use `create(GetLighthouseServersResponseSchema)` to create a new message.
 */
declare const GetLighthouseServersResponseSchema: GenMessage<GetLighthouseServersResponse>;
/**
 * @generated from service avn.connect.v1.ClientService
 */
declare const ClientService: GenService<{
    /**
     * Create credentials for a new client
     *
     * @generated from rpc avn.connect.v1.ClientService.CreateClientCredentials
     */
    createClientCredentials: {
        methodKind: "unary";
        input: typeof CreateClientCredentialsRequestSchema;
        output: typeof CreateClientCredentialsResponseSchema;
    };
    /**
     * Record application telemetry
     *
     * @generated from rpc avn.connect.v1.ClientService.RecordAction
     */
    recordAction: {
        methodKind: "unary";
        input: typeof RecordActionRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Record user feedback
     *
     * @generated from rpc avn.connect.v1.ClientService.RecordFeedback
     */
    recordFeedback: {
        methodKind: "unary";
        input: typeof RecordFeedbackRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Lighthouse servers provide stateless DNS resolution checking for avnlan.local style addresses
     *
     * @generated from rpc avn.connect.v1.ClientService.RegisterLighthouseServer
     */
    registerLighthouseServer: {
        methodKind: "unary";
        input: typeof RegisterLighthouseServerRequestSchema;
        output: typeof RegisterLighthouseServerResponseSchema;
    };
    /**
     * Get all registered lighthouse servers
     *
     * @generated from rpc avn.connect.v1.ClientService.GetLighthouseServers
     */
    getLighthouseServers: {
        methodKind: "unary";
        input: typeof GetLighthouseServersRequestSchema;
        output: typeof GetLighthouseServersResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/cloud.proto.
 */
declare const file_avn_connect_v1_cloud: GenFile;
/**
 * @generated from message avn.connect.v1.CloudFile
 */
type CloudFile = Message<"avn.connect.v1.CloudFile"> & {
    /**
     * Unique cloud file ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Cloud file owner
     *
     * @generated from oneof avn.connect.v1.CloudFile.owner
     */
    owner: {
        /**
         * Organization owner (if not zero)
         *
         * @generated from field: int32 organization_id = 2;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * User owner (if not zero)
         *
         * @generated from field: int32 user_id = 3;
         */
        value: number;
        case: "userId";
    } | {
        case: undefined;
        value?: undefined;
    };
    /**
     * AVNFS URL of cloud file
     *
     * @generated from field: string file_url = 4;
     */
    fileUrl: string;
    /**
     * When file was last modified
     *
     * @generated from field: google.protobuf.Timestamp updated = 5;
     */
    updated?: Timestamp;
    /**
     * Tags associated with this file
     *
     * @generated from field: repeated int32 tags = 6;
     */
    tags: number[];
    /**
     * Preview to use for the cloud file.
     * Deprecated: use icon_url instead, which carries the identical value.
     *
     * @generated from field: string preview_url = 7 [deprecated = true];
     * @deprecated
     */
    previewUrl: string;
    /**
     * Icon/preview image for the cloud file, transcoded per the request's
     * icon_spec (TranscodeImageSpec) when one is supplied.
     *
     * @generated from field: string icon_url = 8;
     */
    iconUrl: string;
    /**
     * Number of metadata entries attached to this file, so clients know
     * whether a GetMetadata call is worthwhile
     *
     * @generated from field: int32 metadata_count = 9;
     */
    metadataCount: number;
    /**
     * CLOUD_FILE_LEGACY_ID
     *
     * @generated from field: string legacy_id = 10;
     */
    legacyId: string;
    /**
     * Legacy fields
     *
     * @generated from field: optional string user_name = 11;
     */
    userName?: string;
    /**
     * @generated from field: optional string device_name = 12;
     */
    deviceName?: string;
    /**
     * @generated from field: optional int32 place_id = 13;
     */
    placeId?: number;
    /**
     * @generated from field: optional string file_name = 14;
     */
    fileName?: string;
    /**
     * @generated from field: optional string media_type = 15;
     */
    mediaType?: string;
    /**
     * @generated from field: optional int64 size_bytes = 16;
     */
    sizeBytes?: bigint;
};
/**
 * Describes the message avn.connect.v1.CloudFile.
 * Use `create(CloudFileSchema)` to create a new message.
 */
declare const CloudFileSchema: GenMessage<CloudFile>;
/**
 * @generated from message avn.connect.v1.GetCloudFilesRequest
 */
type GetCloudFilesRequest = Message<"avn.connect.v1.GetCloudFilesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Cloud file IDs
     *
     * @generated from field: repeated int32 entity_ids = 2;
     */
    entityIds: number[];
    /**
     * Icon transcoding instructions. No icon is returned if this is unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec icon_spec = 3;
     */
    iconSpec?: TranscodeImageSpec;
    /**
     * @generated from field: repeated string legacy_ids = 10;
     */
    legacyIds: string[];
};
/**
 * Describes the message avn.connect.v1.GetCloudFilesRequest.
 * Use `create(GetCloudFilesRequestSchema)` to create a new message.
 */
declare const GetCloudFilesRequestSchema: GenMessage<GetCloudFilesRequest>;
/**
 * @generated from message avn.connect.v1.GetCloudFilesResponse
 */
type GetCloudFilesResponse = Message<"avn.connect.v1.GetCloudFilesResponse"> & {
    /**
     * Cloud files that match the given ID list
     *
     * @generated from field: repeated avn.connect.v1.CloudFile results = 1;
     */
    results: CloudFile[];
};
/**
 * Describes the message avn.connect.v1.GetCloudFilesResponse.
 * Use `create(GetCloudFilesResponseSchema)` to create a new message.
 */
declare const GetCloudFilesResponseSchema: GenMessage<GetCloudFilesResponse>;
/**
 * @generated from message avn.connect.v1.AddCloudFilesRequest
 */
type AddCloudFilesRequest = Message<"avn.connect.v1.AddCloudFilesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Cloud file owner
     *
     * @generated from oneof avn.connect.v1.AddCloudFilesRequest.owner
     */
    owner: {
        /**
         * Organization owner (if not zero)
         *
         * @generated from field: int32 organization_id = 2;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * User owner (if not zero)
         *
         * @generated from field: int32 user_id = 3;
         */
        value: number;
        case: "userId";
    } | {
        case: undefined;
        value?: undefined;
    };
    /**
     * List of AVNFS file URLs to add
     *
     * @generated from field: repeated string file_urls = 4;
     */
    fileUrls: string[];
};
/**
 * Describes the message avn.connect.v1.AddCloudFilesRequest.
 * Use `create(AddCloudFilesRequestSchema)` to create a new message.
 */
declare const AddCloudFilesRequestSchema: GenMessage<AddCloudFilesRequest>;
/**
 * @generated from message avn.connect.v1.AddCloudFilesResponse
 */
type AddCloudFilesResponse = Message<"avn.connect.v1.AddCloudFilesResponse"> & {
    /**
     * IDs of files added
     *
     * @generated from field: repeated int32 entity_ids = 1;
     */
    entityIds: number[];
    /**
     * CLOUD_FILE_LEGACY_ID
     *
     * @generated from field: repeated string legacy_ids = 10;
     */
    legacyIds: string[];
};
/**
 * Describes the message avn.connect.v1.AddCloudFilesResponse.
 * Use `create(AddCloudFilesResponseSchema)` to create a new message.
 */
declare const AddCloudFilesResponseSchema: GenMessage<AddCloudFilesResponse>;
/**
 * @generated from message avn.connect.v1.RemoveCloudFilesRequest
 */
type RemoveCloudFilesRequest = Message<"avn.connect.v1.RemoveCloudFilesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Cloud file IDs to remove
     *
     * @generated from field: repeated int32 entity_ids = 2;
     */
    entityIds: number[];
    /**
     * @generated from field: repeated string legacy_ids = 10;
     */
    legacyIds: string[];
};
/**
 * Describes the message avn.connect.v1.RemoveCloudFilesRequest.
 * Use `create(RemoveCloudFilesRequestSchema)` to create a new message.
 */
declare const RemoveCloudFilesRequestSchema: GenMessage<RemoveCloudFilesRequest>;
/**
 * @generated from message avn.connect.v1.SearchCloudFilesRequest
 */
type SearchCloudFilesRequest = Message<"avn.connect.v1.SearchCloudFilesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Cloud file owner
     *
     * @generated from oneof avn.connect.v1.SearchCloudFilesRequest.owner
     */
    owner: {
        /**
         * Organization owner (if not zero)
         *
         * @generated from field: int32 organization_id = 2;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * User owner (if not zero)
         *
         * @generated from field: int32 user_id = 3;
         */
        value: number;
        case: "userId";
    } | {
        case: undefined;
        value?: undefined;
    };
    /**
     * Search text fields
     *
     * @generated from field: optional avn.connect.v1.TextSearch text_search = 4;
     */
    textSearch?: TextSearch;
    /**
     * Not implemented yet
     *
     * @generated from field: repeated avn.connect.v1.TagFilter tag_filters = 5;
     */
    tagFilters: TagFilter[];
    /**
     * Filter results by media type
     *
     * @generated from field: repeated string filter_media_types = 6;
     */
    filterMediaTypes: string[];
    /**
     * Filter for files added after this time
     *
     * @generated from field: optional google.protobuf.Timestamp after = 7;
     */
    after?: Timestamp;
    /**
     * Filter for files added before this time
     *
     * @generated from field: optional google.protobuf.Timestamp before = 8;
     */
    before?: Timestamp;
    /**
     * Clauses to order the results by
     *
     * @generated from field: repeated avn.connect.v1.OrderClause order_by = 9;
     */
    orderBy: OrderClause[];
    /**
     * Maximum number of results to return
     *
     * @generated from field: optional int32 page_size = 11;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search
     *
     * @generated from field: optional string page_token = 12;
     */
    pageToken?: string;
    /**
     * Icon transcoding instructions. No icon is returned if this is unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec icon_spec = 13;
     */
    iconSpec?: TranscodeImageSpec;
    /**
     * Metadata filters - all filters must pass (AND), matching tag_filters semantics
     *
     * @generated from field: repeated avn.connect.v1.MetadataFilter metadata_filters = 14;
     */
    metadataFilters: MetadataFilter[];
};
/**
 * Describes the message avn.connect.v1.SearchCloudFilesRequest.
 * Use `create(SearchCloudFilesRequestSchema)` to create a new message.
 */
declare const SearchCloudFilesRequestSchema: GenMessage<SearchCloudFilesRequest>;
/**
 * @generated from message avn.connect.v1.SearchCloudFilesResponse
 */
type SearchCloudFilesResponse = Message<"avn.connect.v1.SearchCloudFilesResponse"> & {
    /**
     * Search results
     *
     * @generated from field: repeated avn.connect.v1.CloudFile results = 1;
     */
    results: CloudFile[];
    /**
     * Token to use to get more pages of results or unset if no more results are available
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.SearchCloudFilesResponse.
 * Use `create(SearchCloudFilesResponseSchema)` to create a new message.
 */
declare const SearchCloudFilesResponseSchema: GenMessage<SearchCloudFilesResponse>;
/**
 * @generated from message avn.connect.v1.GetCloudSummaryRequest
 */
type GetCloudSummaryRequest = Message<"avn.connect.v1.GetCloudSummaryRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Cloud file owner
     *
     * @generated from oneof avn.connect.v1.GetCloudSummaryRequest.owner
     */
    owner: {
        /**
         * Organization owner (if not zero)
         *
         * @generated from field: int32 organization_id = 2;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * User owner (if not zero)
         *
         * @generated from field: int32 user_id = 3;
         */
        value: number;
        case: "userId";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message avn.connect.v1.GetCloudSummaryRequest.
 * Use `create(GetCloudSummaryRequestSchema)` to create a new message.
 */
declare const GetCloudSummaryRequestSchema: GenMessage<GetCloudSummaryRequest>;
/**
 * @generated from message avn.connect.v1.GetCloudSummaryResponse
 */
type GetCloudSummaryResponse = Message<"avn.connect.v1.GetCloudSummaryResponse"> & {
    /**
     * Total number of files in owner's cloud
     *
     * @generated from field: int32 total_count = 1;
     */
    totalCount: number;
    /**
     * Total bytes stored in owner's cloud
     *
     * @generated from field: int64 total_bytes = 2;
     */
    totalBytes: bigint;
    /**
     * Total capacity of owner's cloud
     *
     * @generated from field: int64 capacity_bytes = 3;
     */
    capacityBytes: bigint;
    /**
     * Timestamp of oldest file in cloud
     *
     * @generated from field: optional google.protobuf.Timestamp oldest = 4;
     */
    oldest?: Timestamp;
    /**
     * Timestamp of newest file in cloud
     *
     * @generated from field: optional google.protobuf.Timestamp newest = 5;
     */
    newest?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.GetCloudSummaryResponse.
 * Use `create(GetCloudSummaryResponseSchema)` to create a new message.
 */
declare const GetCloudSummaryResponseSchema: GenMessage<GetCloudSummaryResponse>;
/**
 * @generated from service avn.connect.v1.CloudService
 */
declare const CloudService: GenService<{
    /**
     * Get cloud files
     *
     * @generated from rpc avn.connect.v1.CloudService.GetCloudFiles
     */
    getCloudFiles: {
        methodKind: "unary";
        input: typeof GetCloudFilesRequestSchema;
        output: typeof GetCloudFilesResponseSchema;
    };
    /**
     * Add file to either a user or organization cloud depending on which owner field is set
     *
     * @generated from rpc avn.connect.v1.CloudService.AddCloudFiles
     */
    addCloudFiles: {
        methodKind: "unary";
        input: typeof AddCloudFilesRequestSchema;
        output: typeof AddCloudFilesResponseSchema;
    };
    /**
     * Remove cloud file
     *
     * @generated from rpc avn.connect.v1.CloudService.RemoveCloudFiles
     */
    removeCloudFiles: {
        methodKind: "unary";
        input: typeof RemoveCloudFilesRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Add tags to cloud file
     *
     * @generated from rpc avn.connect.v1.CloudService.AddTags
     */
    addTags: {
        methodKind: "unary";
        input: typeof AddTagsRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Remove tags from cloud file
     *
     * @generated from rpc avn.connect.v1.CloudService.RemoveTags
     */
    removeTags: {
        methodKind: "unary";
        input: typeof RemoveTagsRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Search cloud for matching files
     *
     * @generated from rpc avn.connect.v1.CloudService.SearchCloudFiles
     */
    searchCloudFiles: {
        methodKind: "unary";
        input: typeof SearchCloudFilesRequestSchema;
        output: typeof SearchCloudFilesResponseSchema;
    };
    /**
     * Get summary of cloud storage
     *
     * @generated from rpc avn.connect.v1.CloudService.GetCloudSummary
     */
    getCloudSummary: {
        methodKind: "unary";
        input: typeof GetCloudSummaryRequestSchema;
        output: typeof GetCloudSummaryResponseSchema;
    };
    /**
     * Get specific properties of one or more cloud files. Supports ID, FILENAME, ICON_URL, UPDATED, SIZE, ORGANIZATION_ID
     *
     * @generated from rpc avn.connect.v1.CloudService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetEntityPropertiesRequestSchema;
        output: typeof GetEntityPropertiesResponseSchema;
    };
    /**
     * Set the properties of one or more cloud files. Supports ICON_URL, FILENAME
     *
     * @generated from rpc avn.connect.v1.CloudService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetEntityPropertiesRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get metadata from a cloud file
     *
     * @generated from rpc avn.connect.v1.CloudService.GetMetadata
     */
    getMetadata: {
        methodKind: "unary";
        input: typeof MetadataRequestSchema;
        output: typeof GetMetadataResponseSchema;
    };
    /**
     * Set metadata for a cloud file
     * - Values are limited to 512 characters so that search filters stay index-backed
     * - Setting metadata does not change the file's updated timestamp
     *
     * @generated from rpc avn.connect.v1.CloudService.SetMetadata
     */
    setMetadata: {
        methodKind: "unary";
        input: typeof MetadataRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/content.proto.
 */
declare const file_avn_connect_v1_content: GenFile;
/**
 * Find or create a matching activity.
 * User-owned cloud files will create user-owned activities
 * Organization-owned cloud files will create organization-owned activities
 *
 * @generated from message avn.connect.v1.MatchActivityFromCloudRequest
 */
type MatchActivityFromCloudRequest = Message<"avn.connect.v1.MatchActivityFromCloudRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
};
/**
 * Describes the message avn.connect.v1.MatchActivityFromCloudRequest.
 * Use `create(MatchActivityFromCloudRequestSchema)` to create a new message.
 */
declare const MatchActivityFromCloudRequestSchema: GenMessage<MatchActivityFromCloudRequest>;
/**
 * @generated from message avn.connect.v1.MatchActivityFromFilesRequest
 */
type MatchActivityFromFilesRequest = Message<"avn.connect.v1.MatchActivityFromFilesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Icon to use for the entity
     *
     * @generated from field: string icon_url = 3;
     */
    iconUrl: string;
    /**
     * @generated from field: repeated int32 tags = 4;
     */
    tags: number[];
    /**
     * @generated from field: repeated string file_urls = 5;
     */
    fileUrls: string[];
    /**
     * Optional override for the org to assign
     *
     * @generated from field: optional int32 organization_id = 6;
     */
    organizationId?: number;
};
/**
 * Describes the message avn.connect.v1.MatchActivityFromFilesRequest.
 * Use `create(MatchActivityFromFilesRequestSchema)` to create a new message.
 */
declare const MatchActivityFromFilesRequestSchema: GenMessage<MatchActivityFromFilesRequest>;
/**
 * @generated from message avn.connect.v1.MatchActivityFromUrlRequest
 */
type MatchActivityFromUrlRequest = Message<"avn.connect.v1.MatchActivityFromUrlRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Icon to use for the entity
     *
     * @generated from field: string icon_url = 3;
     */
    iconUrl: string;
    /**
     * @generated from field: repeated int32 tags = 4;
     */
    tags: number[];
    /**
     * @generated from field: string url = 5;
     */
    url: string;
    /**
     * @generated from field: optional string context = 6;
     */
    context?: string;
    /**
     * Optional override for the org to assign
     *
     * @generated from field: optional int32 organization_id = 7;
     */
    organizationId?: number;
};
/**
 * Describes the message avn.connect.v1.MatchActivityFromUrlRequest.
 * Use `create(MatchActivityFromUrlRequestSchema)` to create a new message.
 */
declare const MatchActivityFromUrlRequestSchema: GenMessage<MatchActivityFromUrlRequest>;
/**
 * @generated from message avn.connect.v1.MatchActivityResponse
 */
type MatchActivityResponse = Message<"avn.connect.v1.MatchActivityResponse"> & {
    /**
     * @generated from field: avn.connect.v1.EntityInfo activity = 1;
     */
    activity?: EntityInfo;
};
/**
 * Describes the message avn.connect.v1.MatchActivityResponse.
 * Use `create(MatchActivityResponseSchema)` to create a new message.
 */
declare const MatchActivityResponseSchema: GenMessage<MatchActivityResponse>;
/**
 * @generated from message avn.connect.v1.SubmitCommunityCategoryRequest
 */
type SubmitCommunityCategoryRequest = Message<"avn.connect.v1.SubmitCommunityCategoryRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
};
/**
 * Describes the message avn.connect.v1.SubmitCommunityCategoryRequest.
 * Use `create(SubmitCommunityCategoryRequestSchema)` to create a new message.
 */
declare const SubmitCommunityCategoryRequestSchema: GenMessage<SubmitCommunityCategoryRequest>;
/**
 * @generated from service avn.connect.v1.ContentService
 */
declare const ContentService: GenService<{
    /**
     * Find or create an activity that matches the given cloud file
     *
     * @generated from rpc avn.connect.v1.ContentService.MatchActivityFromCloud
     */
    matchActivityFromCloud: {
        methodKind: "unary";
        input: typeof MatchActivityFromCloudRequestSchema;
        output: typeof MatchActivityResponseSchema;
    };
    /**
     * Find or create an activity that matches the given file URLs
     *
     * @generated from rpc avn.connect.v1.ContentService.MatchActivityFromFiles
     */
    matchActivityFromFiles: {
        methodKind: "unary";
        input: typeof MatchActivityFromFilesRequestSchema;
        output: typeof MatchActivityResponseSchema;
    };
    /**
     * Find or create an activity that matches the given web link
     *
     * @generated from rpc avn.connect.v1.ContentService.MatchActivityFromUrl
     */
    matchActivityFromUrl: {
        methodKind: "unary";
        input: typeof MatchActivityFromUrlRequestSchema;
        output: typeof MatchActivityResponseSchema;
    };
    /**
     * User submissions for community library
     *
     * @generated from rpc avn.connect.v1.ContentService.SubmitCommunityCategory
     */
    submitCommunityCategory: {
        methodKind: "unary";
        input: typeof SubmitCommunityCategoryRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/countries.proto.
 */
declare const file_avn_connect_v1_countries: GenFile;
/**
 * @generated from message avn.connect.v1.GetCountryRequest
 */
type GetCountryRequest = Message<"avn.connect.v1.GetCountryRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Country ID (ISO 3166-1 alpha-2)
     *
     * @generated from field: string country_id = 2;
     */
    countryId: string;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 3;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetCountryRequest.
 * Use `create(GetCountryRequestSchema)` to create a new message.
 */
declare const GetCountryRequestSchema: GenMessage<GetCountryRequest>;
/**
 * @generated from message avn.connect.v1.GetCountriesRequest
 */
type GetCountriesRequest = Message<"avn.connect.v1.GetCountriesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 2;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetCountriesRequest.
 * Use `create(GetCountriesRequestSchema)` to create a new message.
 */
declare const GetCountriesRequestSchema: GenMessage<GetCountriesRequest>;
/**
 * @generated from message avn.connect.v1.GetCountriesResponse
 */
type GetCountriesResponse = Message<"avn.connect.v1.GetCountriesResponse"> & {
    /**
     * Map of all supported countries
     *
     * @generated from field: map<string, avn.connect.v1.Country> results = 1;
     */
    results: {
        [key: string]: Country;
    };
};
/**
 * Describes the message avn.connect.v1.GetCountriesResponse.
 * Use `create(GetCountriesResponseSchema)` to create a new message.
 */
declare const GetCountriesResponseSchema: GenMessage<GetCountriesResponse>;
/**
 * @generated from message avn.connect.v1.Country
 */
type Country = Message<"avn.connect.v1.Country"> & {
    /**
     * ISO 3166-1 alpha-2 (default key)
     *
     * @generated from field: string country_id = 1;
     */
    countryId: string;
    /**
     * ISO 3166-1 alpha-3
     *
     * @generated from field: string alpha3 = 2;
     */
    alpha3: string;
    /**
     * Name translated into request language
     *
     * @generated from field: string name = 3;
     */
    name: string;
    /**
     * Name in the default language of the country
     *
     * @generated from field: string native_name = 4;
     */
    nativeName: string;
    /**
     * Most popular language used by this country
     *
     * @generated from field: string default_language_id = 5;
     */
    defaultLanguageId: string;
    /**
     * Default locale for presenting information
     *
     * @generated from field: string default_locale_id = 6;
     */
    defaultLocaleId: string;
    /**
     * Parent organization to use when creating regional organizations
     *
     * @generated from field: int32 default_organization_id = 7;
     */
    defaultOrganizationId: number;
    /**
     * Country tag that matches this country used to annotate resources
     *
     * @generated from field: optional int32 tag_id = 8;
     */
    tagId?: number;
};
/**
 * Describes the message avn.connect.v1.Country.
 * Use `create(CountrySchema)` to create a new message.
 */
declare const CountrySchema: GenMessage<Country>;
/**
 * @generated from service avn.connect.v1.CountryService
 */
declare const CountryService: GenService<{
    /**
     * Get a country from an ID
     *
     * @generated from rpc avn.connect.v1.CountryService.GetCountry
     */
    getCountry: {
        methodKind: "unary";
        input: typeof GetCountryRequestSchema;
        output: typeof CountrySchema;
    };
    /**
     * Get all supported countries
     *
     * @generated from rpc avn.connect.v1.CountryService.GetCountries
     */
    getCountries: {
        methodKind: "unary";
        input: typeof GetCountriesRequestSchema;
        output: typeof GetCountriesResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/delightex.proto.
 */
declare const file_avn_connect_v1_delightex: GenFile;
/**
 * Live details of a provisioned school. Contains no Delightex ids.
 *
 * @generated from message avn.connect.v1.DelightexSchoolInfo
 */
type DelightexSchoolInfo = Message<"avn.connect.v1.DelightexSchoolInfo"> & {
    /**
     * Display name of the school on the Delightex side
     *
     * @generated from field: string name = 1;
     */
    name: string;
    /**
     * Seats currently allocated to the school (live from Delightex)
     *
     * @generated from field: int32 seats_allocated = 2;
     */
    seatsAllocated: number;
    /**
     * Seats currently occupied by teacher and student accounts (live from Delightex)
     *
     * @generated from field: int32 seats_occupied = 3;
     */
    seatsOccupied: number;
};
/**
 * Describes the message avn.connect.v1.DelightexSchoolInfo.
 * Use `create(DelightexSchoolInfoSchema)` to create a new message.
 */
declare const DelightexSchoolInfoSchema: GenMessage<DelightexSchoolInfo>;
/**
 * @generated from message avn.connect.v1.DelightexStatus
 */
type DelightexStatus = Message<"avn.connect.v1.DelightexStatus"> & {
    /**
     * @generated from field: avn.connect.v1.DelightexLicenseState license_state = 1;
     */
    licenseState: DelightexLicenseState;
    /**
     * @generated from field: avn.connect.v1.DelightexSchoolState school_state = 2;
     */
    schoolState: DelightexSchoolState;
    /**
     * State of the calling user's account in this organization's school
     *
     * @generated from field: avn.connect.v1.DelightexUserState user_state = 3;
     */
    userState: DelightexUserState;
    /**
     * Seats the organization's current licenses entitle it to, whether or not
     * a school exists yet
     *
     * @generated from field: int32 licensed_seats = 4;
     */
    licensedSeats: number;
    /**
     * Only present when school_state is PROVISIONED
     *
     * @generated from field: optional avn.connect.v1.DelightexSchoolInfo school = 5;
     */
    school?: DelightexSchoolInfo;
};
/**
 * Describes the message avn.connect.v1.DelightexStatus.
 * Use `create(DelightexStatusSchema)` to create a new message.
 */
declare const DelightexStatusSchema: GenMessage<DelightexStatus>;
/**
 * @generated from message avn.connect.v1.DelightexGetStatusRequest
 */
type DelightexGetStatusRequest = Message<"avn.connect.v1.DelightexGetStatusRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The ClassConnect organization to query
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
};
/**
 * Describes the message avn.connect.v1.DelightexGetStatusRequest.
 * Use `create(DelightexGetStatusRequestSchema)` to create a new message.
 */
declare const DelightexGetStatusRequestSchema: GenMessage<DelightexGetStatusRequest>;
/**
 * @generated from message avn.connect.v1.DelightexProvisionSchoolRequest
 */
type DelightexProvisionSchoolRequest = Message<"avn.connect.v1.DelightexProvisionSchoolRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The ClassConnect organization to create a Delightex school for
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
};
/**
 * Describes the message avn.connect.v1.DelightexProvisionSchoolRequest.
 * Use `create(DelightexProvisionSchoolRequestSchema)` to create a new message.
 */
declare const DelightexProvisionSchoolRequestSchema: GenMessage<DelightexProvisionSchoolRequest>;
/**
 * @generated from message avn.connect.v1.DelightexProvisionUserRequest
 */
type DelightexProvisionUserRequest = Message<"avn.connect.v1.DelightexProvisionUserRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The ClassConnect organization whose school the account is created in
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
};
/**
 * Describes the message avn.connect.v1.DelightexProvisionUserRequest.
 * Use `create(DelightexProvisionUserRequestSchema)` to create a new message.
 */
declare const DelightexProvisionUserRequestSchema: GenMessage<DelightexProvisionUserRequest>;
/**
 * @generated from message avn.connect.v1.DelightexCreateLoginLinkRequest
 */
type DelightexCreateLoginLinkRequest = Message<"avn.connect.v1.DelightexCreateLoginLinkRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The ClassConnect organization whose school the caller is signing in to
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
};
/**
 * Describes the message avn.connect.v1.DelightexCreateLoginLinkRequest.
 * Use `create(DelightexCreateLoginLinkRequestSchema)` to create a new message.
 */
declare const DelightexCreateLoginLinkRequestSchema: GenMessage<DelightexCreateLoginLinkRequest>;
/**
 * @generated from message avn.connect.v1.DelightexCreateLoginLinkResponse
 */
type DelightexCreateLoginLinkResponse = Message<"avn.connect.v1.DelightexCreateLoginLinkResponse"> & {
    /**
     * Full sign-in URL carrying a one-time login code (e.g. https://.../?auth_code=123456).
     * Expires on first use; mint a fresh link for every sign-in.
     *
     * @generated from field: string url = 1;
     */
    url: string;
};
/**
 * Describes the message avn.connect.v1.DelightexCreateLoginLinkResponse.
 * Use `create(DelightexCreateLoginLinkResponseSchema)` to create a new message.
 */
declare const DelightexCreateLoginLinkResponseSchema: GenMessage<DelightexCreateLoginLinkResponse>;
/**
 * @generated from message avn.connect.v1.DelightexResolveShareLinkRequest
 */
type DelightexResolveShareLinkRequest = Message<"avn.connect.v1.DelightexResolveShareLinkRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * A public Delightex share link, e.g. https://edu.delightex.com/GNJ-XRX
     *
     * @generated from field: string url = 2;
     */
    url: string;
};
/**
 * Describes the message avn.connect.v1.DelightexResolveShareLinkRequest.
 * Use `create(DelightexResolveShareLinkRequestSchema)` to create a new message.
 */
declare const DelightexResolveShareLinkRequestSchema: GenMessage<DelightexResolveShareLinkRequest>;
/**
 * @generated from message avn.connect.v1.DelightexResolveShareLinkResponse
 */
type DelightexResolveShareLinkResponse = Message<"avn.connect.v1.DelightexResolveShareLinkResponse"> & {
    /**
     * Scene name
     *
     * @generated from field: string name = 1;
     */
    name: string;
    /**
     * Scene description (may be empty)
     *
     * @generated from field: string description = 2;
     */
    description: string;
    /**
     * Scene preview image URL (may be empty when no preview could be derived)
     *
     * @generated from field: string icon_url = 3;
     */
    iconUrl: string;
};
/**
 * Describes the message avn.connect.v1.DelightexResolveShareLinkResponse.
 * Use `create(DelightexResolveShareLinkResponseSchema)` to create a new message.
 */
declare const DelightexResolveShareLinkResponseSchema: GenMessage<DelightexResolveShareLinkResponse>;
/**
 * @generated from enum avn.connect.v1.DelightexLicenseState
 */
declare enum DelightexLicenseState {
    /**
     * @generated from enum value: DELIGHTEX_LICENSE_STATE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * The organization holds no qualifying license (seat formula evaluates to 0)
     *
     * @generated from enum value: DELIGHTEX_LICENSE_STATE_UNLICENSED = 1;
     */
    UNLICENSED = 1,
    /**
     * The organization holds a qualifying license
     *
     * @generated from enum value: DELIGHTEX_LICENSE_STATE_LICENSED = 2;
     */
    LICENSED = 2
}
/**
 * Describes the enum avn.connect.v1.DelightexLicenseState.
 */
declare const DelightexLicenseStateSchema: GenEnum<DelightexLicenseState>;
/**
 * @generated from enum avn.connect.v1.DelightexSchoolState
 */
declare enum DelightexSchoolState {
    /**
     * @generated from enum value: DELIGHTEX_SCHOOL_STATE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * No Delightex school has been created for this organization yet
     *
     * @generated from enum value: DELIGHTEX_SCHOOL_STATE_NOT_PROVISIONED = 1;
     */
    NOT_PROVISIONED = 1,
    /**
     * The organization has a Delightex school
     *
     * @generated from enum value: DELIGHTEX_SCHOOL_STATE_PROVISIONED = 2;
     */
    PROVISIONED = 2
}
/**
 * Describes the enum avn.connect.v1.DelightexSchoolState.
 */
declare const DelightexSchoolStateSchema: GenEnum<DelightexSchoolState>;
/**
 * @generated from enum avn.connect.v1.DelightexUserState
 */
declare enum DelightexUserState {
    /**
     * @generated from enum value: DELIGHTEX_USER_STATE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * The calling user has no Delightex account in this organization's school
     *
     * @generated from enum value: DELIGHTEX_USER_STATE_NO_ACCOUNT = 1;
     */
    NO_ACCOUNT = 1,
    /**
     * The calling user has a Delightex account in this organization's school
     *
     * @generated from enum value: DELIGHTEX_USER_STATE_PROVISIONED = 2;
     */
    PROVISIONED = 2
}
/**
 * Describes the enum avn.connect.v1.DelightexUserState.
 */
declare const DelightexUserStateSchema: GenEnum<DelightexUserState>;
/**
 * Integration with Delightex (formerly CoSpaces Edu): each ClassConnect organization
 * maps to at most one Delightex school, and each (organization, user) pair to at most
 * one Delightex teacher account. Both are provisioned lazily, gated on the org holding
 * a qualifying license (see dev-ops/Delightex/implementation-plan.md for the seat formula).
 *
 * Delightex school and user ids are deliberately absent from this API: every RPC
 * resolves them server-side from the caller's credentials and the organization id,
 * so clients can never address another organization's school.
 *
 * @generated from service avn.connect.v1.DelightexService
 */
declare const DelightexService: GenService<{
    /**
     * Everything the ClassVR Player page needs in one call: license, school and
     * caller-account state, plus live seat counts when the school exists.
     *
     * @generated from rpc avn.connect.v1.DelightexService.GetStatus
     */
    getStatus: {
        methodKind: "unary";
        input: typeof DelightexGetStatusRequestSchema;
        output: typeof DelightexStatusSchema;
    };
    /**
     * Create the organization's Delightex school (idempotent; any licensed member).
     *
     * @generated from rpc avn.connect.v1.DelightexService.ProvisionSchool
     */
    provisionSchool: {
        methodKind: "unary";
        input: typeof DelightexProvisionSchoolRequestSchema;
        output: typeof DelightexStatusSchema;
    };
    /**
     * Create the caller's own Delightex teacher account in the organization's school.
     *
     * @generated from rpc avn.connect.v1.DelightexService.ProvisionUser
     */
    provisionUser: {
        methodKind: "unary";
        input: typeof DelightexProvisionUserRequestSchema;
        output: typeof DelightexStatusSchema;
    };
    /**
     * Mint a one-time login code for the caller's Delightex account and return the sign-in URL.
     * Codes are single-use and also expire after two minutes, so this is called on demand, never prefetched.
     *
     * @generated from rpc avn.connect.v1.DelightexService.CreateLoginLink
     */
    createLoginLink: {
        methodKind: "unary";
        input: typeof DelightexCreateLoginLinkRequestSchema;
        output: typeof DelightexCreateLoginLinkResponseSchema;
    };
    /**
     * Resolve a public Delightex share link (https://{server}/XXX-XXX) to its scene
     * metadata, for importing shared scenes as activities.
     *
     * @generated from rpc avn.connect.v1.DelightexService.ResolveShareLink
     */
    resolveShareLink: {
        methodKind: "unary";
        input: typeof DelightexResolveShareLinkRequestSchema;
        output: typeof DelightexResolveShareLinkResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/presence.proto.
 */
declare const file_avn_connect_v1_presence: GenFile;
/**
 * @generated from message avn.connect.v1.PresenceUpdate
 */
type PresenceUpdate = Message<"avn.connect.v1.PresenceUpdate"> & {
    /**
     * @generated from field: avn.connect.v1.PresenceState state = 1;
     */
    state: PresenceState;
    /**
     * @generated from field: avn.connect.v1.PresenceInfo info = 2;
     */
    info?: PresenceInfo;
};
/**
 * Describes the message avn.connect.v1.PresenceUpdate.
 * Use `create(PresenceUpdateSchema)` to create a new message.
 */
declare const PresenceUpdateSchema: GenMessage<PresenceUpdate>;
/**
 * @generated from message avn.connect.v1.PresenceInfo
 */
type PresenceInfo = Message<"avn.connect.v1.PresenceInfo"> & {
    /**
     * @generated from field: string connection_id = 1;
     */
    connectionId: string;
    /**
     * @generated from field: optional string session_id = 2;
     */
    sessionId?: string;
    /**
     * @generated from field: optional string room_id = 3;
     */
    roomId?: string;
    /**
     * @generated from field: optional string asset_id = 4;
     */
    assetId?: string;
};
/**
 * Describes the message avn.connect.v1.PresenceInfo.
 * Use `create(PresenceInfoSchema)` to create a new message.
 */
declare const PresenceInfoSchema: GenMessage<PresenceInfo>;
/**
 * @generated from enum avn.connect.v1.PresenceState
 */
declare enum PresenceState {
    /**
     * @generated from enum value: PRESENCE_STATE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: PRESENCE_STATE_ADDED = 1;
     */
    ADDED = 1,
    /**
     * @generated from enum value: PRESENCE_STATE_REMOVED = 2;
     */
    REMOVED = 2,
    /**
     * @generated from enum value: PRESENCE_STATE_CHANGED = 3;
     */
    CHANGED = 3
}
/**
 * Describes the enum avn.connect.v1.PresenceState.
 */
declare const PresenceStateSchema: GenEnum<PresenceState>;

/**
 * Describes the file avn/connect/v1/geometry.proto.
 */
declare const file_avn_connect_v1_geometry: GenFile;
/**
 * @generated from message avn.connect.v1.Vector3
 */
type Vector3 = Message<"avn.connect.v1.Vector3"> & {
    /**
     * @generated from field: double x = 1;
     */
    x: number;
    /**
     * @generated from field: double y = 2;
     */
    y: number;
    /**
     * @generated from field: double z = 3;
     */
    z: number;
};
/**
 * Describes the message avn.connect.v1.Vector3.
 * Use `create(Vector3Schema)` to create a new message.
 */
declare const Vector3Schema: GenMessage<Vector3>;
/**
 * @generated from message avn.connect.v1.Quaternion
 */
type Quaternion = Message<"avn.connect.v1.Quaternion"> & {
    /**
     * @generated from field: double x = 1;
     */
    x: number;
    /**
     * @generated from field: double y = 2;
     */
    y: number;
    /**
     * @generated from field: double z = 3;
     */
    z: number;
    /**
     * @generated from field: double w = 4;
     */
    w: number;
};
/**
 * Describes the message avn.connect.v1.Quaternion.
 * Use `create(QuaternionSchema)` to create a new message.
 */
declare const QuaternionSchema: GenMessage<Quaternion>;

/**
 * Describes the file avn/connect/v1/lesson_context.proto.
 */
declare const file_avn_connect_v1_lesson_context: GenFile;
/**
 * @generated from message avn.connect.v1.LessonContext
 */
type LessonContext = Message<"avn.connect.v1.LessonContext"> & {
    /**
     * TODO: Lesson plan, learning module modules, POIs - i.e. soft context for the guide rather than forced "focus" context
     *
     * @generated from field: optional avn.connect.v1.LessonFocus focus = 1;
     */
    focus?: LessonFocus;
};
/**
 * Describes the message avn.connect.v1.LessonContext.
 * Use `create(LessonContextSchema)` to create a new message.
 */
declare const LessonContextSchema: GenMessage<LessonContext>;
/**
 * @generated from message avn.connect.v1.LessonFocus
 */
type LessonFocus = Message<"avn.connect.v1.LessonFocus"> & {
    /**
     * @generated from field: string room_id = 1;
     */
    roomId: string;
    /**
     * @generated from field: string asset_id = 2;
     */
    assetId: string;
    /**
     * @generated from field: optional avn.connect.v1.Vector3 position = 3;
     */
    position?: Vector3;
    /**
     * @generated from field: optional avn.connect.v1.Quaternion orientation = 4;
     */
    orientation?: Quaternion;
    /**
     * Should the user be allowed to go back?
     *
     * @generated from field: bool back_lock = 5;
     */
    backLock: boolean;
    /**
     * Should the user be allowed to use the general scene selector?
     *
     * @generated from field: bool explore_lock = 6;
     */
    exploreLock: boolean;
    /**
     * Should the user be focused exclusively on this scene or be allowed to navigate to linked scenes?
     *
     * @generated from field: bool navigation_lock = 7;
     */
    navigationLock: boolean;
};
/**
 * Describes the message avn.connect.v1.LessonFocus.
 * Use `create(LessonFocusSchema)` to create a new message.
 */
declare const LessonFocusSchema: GenMessage<LessonFocus>;

/**
 * Describes the file avn/connect/v1/partners.proto.
 */
declare const file_avn_connect_v1_partners: GenFile;
/**
 * @generated from message avn.connect.v1.PartnerSession
 */
type PartnerSession = Message<"avn.connect.v1.PartnerSession"> & {
    /**
     * @generated from field: string partner_id = 1;
     */
    partnerId: string;
    /**
     * @generated from field: string session_id = 2;
     */
    sessionId: string;
};
/**
 * Describes the message avn.connect.v1.PartnerSession.
 * Use `create(PartnerSessionSchema)` to create a new message.
 */
declare const PartnerSessionSchema: GenMessage<PartnerSession>;

/**
 * Describes the file avn/connect/v1/grants.proto.
 */
declare const file_avn_connect_v1_grants: GenFile;
/**
 * @generated from message avn.connect.v1.GrantInfo
 */
type GrantInfo = Message<"avn.connect.v1.GrantInfo"> & {
    /**
     * Unique grant ID
     *
     * @generated from field: optional string grant_id = 1;
     */
    grantId?: string;
    /**
     * Plan codes enabled by this grant, which will be matched to channels and features
     *
     * @generated from field: repeated string plan_codes = 2;
     */
    planCodes: string[];
    /**
     * Channels directly permitted by this grant
     *
     * @generated from field: repeated int32 permitted_channels = 7;
     */
    permittedChannels: number[];
    /**
     * The source of the grant
     *
     * @generated from oneof avn.connect.v1.GrantInfo.source
     */
    source: {
        /**
         * Grant is associated with a user
         *
         * @generated from field: int32 user_id = 4;
         */
        value: number;
        case: "userId";
    } | {
        /**
         * Grant is associated with an organization (will be the ID of the licensee, not a channel library organization)
         *
         * @generated from field: int32 organization_id = 5;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * Partner allocated grant
         *
         * @generated from field: avn.connect.v1.PartnerSession partner_session = 6;
         */
        value: PartnerSession;
        case: "partnerSession";
    } | {
        /**
         * Grant from a Hall Pass
         *
         * @generated from field: string pass_id = 8;
         */
        value: string;
        case: "passId";
    } | {
        /**
         * Grants is associated with how the dimension was created, e.g. the client used, a referrer, etc...
         *
         * @generated from field: string context = 9;
         */
        value: string;
        case: "context";
    } | {
        case: undefined;
        value?: undefined;
    };
    /**
     * When the grant expires
     *
     * @generated from field: optional google.protobuf.Timestamp expires = 20;
     */
    expires?: Timestamp;
    /**
     * Grant origin type
     *
     * @generated from field: avn.connect.v1.GrantType grant_type = 21;
     */
    grantType: GrantType;
};
/**
 * Describes the message avn.connect.v1.GrantInfo.
 * Use `create(GrantInfoSchema)` to create a new message.
 */
declare const GrantInfoSchema: GenMessage<GrantInfo>;
/**
 * @generated from message avn.connect.v1.GetUserGrantsRequest
 */
type GetUserGrantsRequest = Message<"avn.connect.v1.GetUserGrantsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Unique user ID
     *
     * @generated from field: int32 user_id = 2;
     */
    userId: number;
};
/**
 * Describes the message avn.connect.v1.GetUserGrantsRequest.
 * Use `create(GetUserGrantsRequestSchema)` to create a new message.
 */
declare const GetUserGrantsRequestSchema: GenMessage<GetUserGrantsRequest>;
/**
 * @generated from message avn.connect.v1.GetOrganizationGrantsRequest
 */
type GetOrganizationGrantsRequest = Message<"avn.connect.v1.GetOrganizationGrantsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Unique organization ID
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
};
/**
 * Describes the message avn.connect.v1.GetOrganizationGrantsRequest.
 * Use `create(GetOrganizationGrantsRequestSchema)` to create a new message.
 */
declare const GetOrganizationGrantsRequestSchema: GenMessage<GetOrganizationGrantsRequest>;
/**
 * @generated from message avn.connect.v1.GetGrantsResponse
 */
type GetGrantsResponse = Message<"avn.connect.v1.GetGrantsResponse"> & {
    /**
     * Available grants
     *
     * @generated from field: repeated avn.connect.v1.GrantInfo grants = 1;
     */
    grants: GrantInfo[];
};
/**
 * Describes the message avn.connect.v1.GetGrantsResponse.
 * Use `create(GetGrantsResponseSchema)` to create a new message.
 */
declare const GetGrantsResponseSchema: GenMessage<GetGrantsResponse>;
/**
 * Grant origin types
 *
 * @generated from enum avn.connect.v1.GrantType
 */
declare enum GrantType {
    /**
     * @generated from enum value: GRANT_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Grant comes from user ownership or from the user's membership of the content owning organization
     *
     * @generated from enum value: GRANT_TYPE_PERMITTED = 1;
     */
    PERMITTED = 1,
    /**
     * Grant comes from an organization subscription (the grantee is licensed)
     *
     * @generated from enum value: GRANT_TYPE_LICENSED = 2;
     */
    LICENSED = 2
}
/**
 * Describes the enum avn.connect.v1.GrantType.
 */
declare const GrantTypeSchema: GenEnum<GrantType>;
/**
 * @generated from service avn.connect.v1.GrantService
 */
declare const GrantService: GenService<{
    /**
     * Get all grants available to the given user based on their organization membership
     *
     * @generated from rpc avn.connect.v1.GrantService.GetUserGrants
     */
    getUserGrants: {
        methodKind: "unary";
        input: typeof GetUserGrantsRequestSchema;
        output: typeof GetGrantsResponseSchema;
    };
    /**
     * Get all grants available to the given organization
     *
     * @generated from rpc avn.connect.v1.GrantService.GetOrganizationGrants
     */
    getOrganizationGrants: {
        methodKind: "unary";
        input: typeof GetOrganizationGrantsRequestSchema;
        output: typeof GetGrantsResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/dimensions.proto.
 */
declare const file_avn_connect_v1_dimensions: GenFile;
/**
 * @generated from message avn.connect.v1.CreateDimensionRequest
 */
type CreateDimensionRequest = Message<"avn.connect.v1.CreateDimensionRequest"> & {
    /**
     * The client that is making the request
     *
     * @generated from field: avn.connect.v1.ClientCredentials client = 1;
     */
    client?: ClientCredentials;
    /**
     * Authorization for the dimension creator
     *
     * @generated from field: optional avn.connect.v1.Authorization auth = 2;
     */
    auth?: Authorization;
    /**
     * A hall pass to use for additional licensing
     *
     * @generated from field: optional string pass_id = 3;
     */
    passId?: string;
    /**
     * Which Eduverse cloud domain to use?
     *
     * @generated from field: optional string preferred_domain = 4;
     */
    preferredDomain?: string;
    /**
     * Where is the request coming from? (typically a hostname)
     *
     * @generated from field: optional string referrer = 5;
     */
    referrer?: string;
    /**
     * Narrow dimension license scope to a specific organization
     *
     * @generated from field: optional int32 context_organization_id = 6;
     */
    contextOrganizationId?: number;
};
/**
 * Describes the message avn.connect.v1.CreateDimensionRequest.
 * Use `create(CreateDimensionRequestSchema)` to create a new message.
 */
declare const CreateDimensionRequestSchema: GenMessage<CreateDimensionRequest>;
/**
 * @generated from message avn.connect.v1.CreateDimensionResponse
 */
type CreateDimensionResponse = Message<"avn.connect.v1.CreateDimensionResponse"> & {
    /**
     * Unique ID of new dimension
     *
     * @generated from field: string dimension_id = 1;
     */
    dimensionId: string;
};
/**
 * Describes the message avn.connect.v1.CreateDimensionResponse.
 * Use `create(CreateDimensionResponseSchema)` to create a new message.
 */
declare const CreateDimensionResponseSchema: GenMessage<CreateDimensionResponse>;
/**
 * @generated from message avn.connect.v1.GetDimensionRequest
 */
type GetDimensionRequest = Message<"avn.connect.v1.GetDimensionRequest"> & {
    /**
     * Client ID
     *
     * @generated from field: avn.connect.v1.ClientCredentials client = 1;
     */
    client?: ClientCredentials;
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 2;
     */
    auth?: Authorization;
    /**
     * Unique ID of dimension to get
     *
     * @generated from field: string dimension_id = 3;
     */
    dimensionId: string;
};
/**
 * Describes the message avn.connect.v1.GetDimensionRequest.
 * Use `create(GetDimensionRequestSchema)` to create a new message.
 */
declare const GetDimensionRequestSchema: GenMessage<GetDimensionRequest>;
/**
 * @generated from message avn.connect.v1.JoinDimensionRequest
 */
type JoinDimensionRequest = Message<"avn.connect.v1.JoinDimensionRequest"> & {
    /**
     * Client ID
     *
     * @generated from field: avn.connect.v1.ClientCredentials client = 1;
     */
    client?: ClientCredentials;
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 2;
     */
    auth?: Authorization;
    /**
     * @generated from field: string dimension_id = 3;
     */
    dimensionId: string;
};
/**
 * Describes the message avn.connect.v1.JoinDimensionRequest.
 * Use `create(JoinDimensionRequestSchema)` to create a new message.
 */
declare const JoinDimensionRequestSchema: GenMessage<JoinDimensionRequest>;
/**
 * @generated from message avn.connect.v1.DimensionEvent
 */
type DimensionEvent = Message<"avn.connect.v1.DimensionEvent"> & {
    /**
     * Status of the connected dimension
     *
     * @generated from field: optional avn.connect.v1.DimensionStatus status = 1;
     */
    status?: DimensionStatus;
    /**
     * Immutable info about the dimension
     *
     * @generated from field: optional avn.connect.v1.DimensionInfo info = 2;
     */
    info?: DimensionInfo;
    /**
     * Connection details including credentials for future calls
     *
     * @generated from field: optional avn.connect.v1.ConnectionInstance connection = 3;
     */
    connection?: ConnectionInstance;
    /**
     * Broadcast message to display
     *
     * @generated from field: optional avn.connect.v1.DimensionBroadcast broadcast = 4;
     */
    broadcast?: DimensionBroadcast;
    /**
     * Track people joinging and leaving the dimension
     *
     * @generated from field: optional avn.connect.v1.PresenceUpdate presence = 5;
     */
    presence?: PresenceUpdate;
    /**
     * Track lesson context changes (gather and look)
     *
     * @generated from field: optional avn.connect.v1.LessonContext lesson = 6;
     */
    lesson?: LessonContext;
};
/**
 * Describes the message avn.connect.v1.DimensionEvent.
 * Use `create(DimensionEventSchema)` to create a new message.
 */
declare const DimensionEventSchema: GenMessage<DimensionEvent>;
/**
 * @generated from message avn.connect.v1.DimensionStatus
 */
type DimensionStatus = Message<"avn.connect.v1.DimensionStatus"> & {
    /**
     * Dimension state
     *
     * @generated from field: avn.connect.v1.OperationState state = 1;
     */
    state: OperationState;
    /**
     * Additional details about the dimension state
     *
     * @generated from field: optional string detail = 2;
     */
    detail?: string;
};
/**
 * Describes the message avn.connect.v1.DimensionStatus.
 * Use `create(DimensionStatusSchema)` to create a new message.
 */
declare const DimensionStatusSchema: GenMessage<DimensionStatus>;
/**
 * @generated from message avn.connect.v1.DimensionInstance
 */
type DimensionInstance = Message<"avn.connect.v1.DimensionInstance"> & {
    /**
     * Dimension properties
     *
     * @generated from field: avn.connect.v1.DimensionInfo info = 1;
     */
    info?: DimensionInfo;
    /**
     * Content available though this dimension
     *
     * @generated from field: avn.connect.v1.AvailableContent content = 2;
     */
    content?: AvailableContent;
    /**
     * Permissions for all users within this dimension
     *
     * @generated from field: avn.connect.v1.InteractionPermissions permissions = 4;
     */
    permissions?: InteractionPermissions;
    /**
     * Recommended user interface features for all users
     *
     * @generated from field: avn.connect.v1.UserInterfaceFeatures features = 5;
     */
    features?: UserInterfaceFeatures;
};
/**
 * Describes the message avn.connect.v1.DimensionInstance.
 * Use `create(DimensionInstanceSchema)` to create a new message.
 */
declare const DimensionInstanceSchema: GenMessage<DimensionInstance>;
/**
 * @generated from message avn.connect.v1.DimensionInfo
 */
type DimensionInfo = Message<"avn.connect.v1.DimensionInfo"> & {
    /**
     * Dimension unique ID
     *
     * @generated from field: string id = 1;
     */
    id: string;
    /**
     * Display name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * When the dimension was created
     *
     * @generated from field: google.protobuf.Timestamp created = 3;
     */
    created?: Timestamp;
    /**
     * How the dimensions lifetype is controlled
     *
     * @generated from field: avn.connect.v1.ExpiryStrategy expiry_strategy = 4;
     */
    expiryStrategy: ExpiryStrategy;
    /**
     * Base domain for dimension access
     *
     * @generated from field: string domain = 5;
     */
    domain: string;
    /**
     * Associated pass ID
     *
     * @generated from field: optional string pass_id = 6;
     */
    passId?: string;
    /**
     * Dimension access limits
     *
     * @generated from field: avn.connect.v1.AccessLimits access_limits = 7;
     */
    accessLimits?: AccessLimits;
    /**
     * How the dimension was created
     *
     * @generated from field: avn.connect.v1.DimensionOrigin origin = 8;
     */
    origin?: DimensionOrigin;
    /**
     * Grants associated with this dimension
     *
     * @generated from field: repeated avn.connect.v1.GrantInfo grants = 9;
     */
    grants: GrantInfo[];
    /**
     * A message to show users who join the dimension
     *
     * @generated from field: optional string entry_message = 10;
     */
    entryMessage?: string;
};
/**
 * Describes the message avn.connect.v1.DimensionInfo.
 * Use `create(DimensionInfoSchema)` to create a new message.
 */
declare const DimensionInfoSchema: GenMessage<DimensionInfo>;
/**
 * @generated from message avn.connect.v1.DimensionOrigin
 */
type DimensionOrigin = Message<"avn.connect.v1.DimensionOrigin"> & {
    /**
     * User client ID
     *
     * @generated from field: optional string client_id = 1;
     */
    clientId?: string;
    /**
     * User Eduverse ID
     *
     * @generated from field: optional int32 user_id = 2;
     */
    userId?: number;
    /**
     * Associated partner sessions
     *
     * @generated from field: optional avn.connect.v1.PartnerSession partner_session = 3;
     */
    partnerSession?: PartnerSession;
};
/**
 * Describes the message avn.connect.v1.DimensionOrigin.
 * Use `create(DimensionOriginSchema)` to create a new message.
 */
declare const DimensionOriginSchema: GenMessage<DimensionOrigin>;
/**
 * @generated from message avn.connect.v1.DimensionBroadcast
 */
type DimensionBroadcast = Message<"avn.connect.v1.DimensionBroadcast"> & {
    /**
     * Message to send to all users in the dimension
     *
     * @generated from field: string message = 1;
     */
    message: string;
    /**
     * Connection ID of announcer
     *
     * @generated from field: optional string announcer_connection_id = 2;
     */
    announcerConnectionId?: string;
};
/**
 * Describes the message avn.connect.v1.DimensionBroadcast.
 * Use `create(DimensionBroadcastSchema)` to create a new message.
 */
declare const DimensionBroadcastSchema: GenMessage<DimensionBroadcast>;
/**
 * @generated from message avn.connect.v1.AccessLimits
 */
type AccessLimits = Message<"avn.connect.v1.AccessLimits"> & {
    /**
     * How many users each room is allowed to host simultaneously
     *
     * @generated from field: int32 room_capacity = 1;
     */
    roomCapacity: number;
    /**
     * How many users the whole dimension is allowed to host simultaneously
     *
     * @generated from field: int32 dimension_capacity = 2;
     */
    dimensionCapacity: number;
    /**
     * Users must join with one of these identity providers
     *
     * @generated from field: repeated avn.connect.v1.IdentityProvider identity_providers = 3;
     */
    identityProviders: IdentityProvider[];
    /**
     * User emails addresses must match this whitelist
     *
     * @generated from field: repeated string email_whitelist = 4;
     */
    emailWhitelist: string[];
};
/**
 * Describes the message avn.connect.v1.AccessLimits.
 * Use `create(AccessLimitsSchema)` to create a new message.
 */
declare const AccessLimitsSchema: GenMessage<AccessLimits>;
/**
 * @generated from message avn.connect.v1.SetLessonContextRequest
 */
type SetLessonContextRequest = Message<"avn.connect.v1.SetLessonContextRequest"> & {
    /**
     * Dimension connection credentials
     *
     * @generated from field: avn.connect.v1.ConnectionCredentials credentials = 1;
     */
    credentials?: ConnectionCredentials;
    /**
     * Dimension ID
     *
     * @generated from field: string dimension_id = 2;
     */
    dimensionId: string;
    /**
     * Current lesson context
     *
     * @generated from field: optional avn.connect.v1.LessonContext context = 3;
     */
    context?: LessonContext;
};
/**
 * Describes the message avn.connect.v1.SetLessonContextRequest.
 * Use `create(SetLessonContextRequestSchema)` to create a new message.
 */
declare const SetLessonContextRequestSchema: GenMessage<SetLessonContextRequest>;
/**
 * @generated from message avn.connect.v1.SetLessonContextResponse
 */
type SetLessonContextResponse = Message<"avn.connect.v1.SetLessonContextResponse"> & {
    /**
     * Lesson context state
     *
     * @generated from field: avn.connect.v1.OperationState state = 1;
     */
    state: OperationState;
    /**
     * Additional information about the lesson context state
     *
     * @generated from field: optional string detail = 2;
     */
    detail?: string;
};
/**
 * Describes the message avn.connect.v1.SetLessonContextResponse.
 * Use `create(SetLessonContextResponseSchema)` to create a new message.
 */
declare const SetLessonContextResponseSchema: GenMessage<SetLessonContextResponse>;
/**
 * @generated from enum avn.connect.v1.ExpiryStrategy
 */
declare enum ExpiryStrategy {
    /**
     * @generated from enum value: EXPIRY_STRATEGY_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Any active connection keeps the dimension alive
     *
     * @generated from enum value: EXPIRY_STRATEGY_ANY_CONNECTION = 1;
     */
    ANY_CONNECTION = 1,
    /**
     * Only the owners connection keeps the dimension alive
     *
     * @generated from enum value: EXPIRY_STRATEGY_ONLY_OWNER = 2;
     */
    ONLY_OWNER = 2
}
/**
 * Describes the enum avn.connect.v1.ExpiryStrategy.
 */
declare const ExpiryStrategySchema: GenEnum<ExpiryStrategy>;
/**
 * @generated from service avn.connect.v1.DimensionService
 */
declare const DimensionService: GenService<{
    /**
     * Create a new dimension
     *
     * @generated from rpc avn.connect.v1.DimensionService.CreateDimension
     */
    createDimension: {
        methodKind: "unary";
        input: typeof CreateDimensionRequestSchema;
        output: typeof CreateDimensionResponseSchema;
    };
    /**
     * Get an existing dimension
     *
     * @generated from rpc avn.connect.v1.DimensionService.GetDimension
     */
    getDimension: {
        methodKind: "unary";
        input: typeof GetDimensionRequestSchema;
        output: typeof DimensionInstanceSchema;
    };
    /**
     * Join a dimension
     *
     * @generated from rpc avn.connect.v1.DimensionService.JoinDimension
     */
    joinDimension: {
        methodKind: "server_streaming";
        input: typeof JoinDimensionRequestSchema;
        output: typeof DimensionEventSchema;
    };
    /**
     * Set the current context of a dimension for everyone
     *
     * @generated from rpc avn.connect.v1.DimensionService.SetLessonContext
     */
    setLessonContext: {
        methodKind: "unary";
        input: typeof SetLessonContextRequestSchema;
        output: typeof SetLessonContextResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/geo.proto.
 */
declare const file_avn_connect_v1_geo: GenFile;
/**
 * @generated from message avn.connect.v1.GetGeoPlaceRequest
 */
type GetGeoPlaceRequest = Message<"avn.connect.v1.GetGeoPlaceRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Unique place ID
     *
     * @generated from field: string place_id = 2;
     */
    placeId: string;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 3;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetGeoPlaceRequest.
 * Use `create(GetGeoPlaceRequestSchema)` to create a new message.
 */
declare const GetGeoPlaceRequestSchema: GenMessage<GetGeoPlaceRequest>;
/**
 * @generated from message avn.connect.v1.GetGeoPlaceResponse
 */
type GetGeoPlaceResponse = Message<"avn.connect.v1.GetGeoPlaceResponse"> & {
    /**
     * Resolved geographic place
     *
     * @generated from field: avn.connect.v1.GeoPlace place = 1;
     */
    place?: GeoPlace;
    /**
     * Heuristically composed ClassConnect database fields
     *
     * @generated from field: avn.connect.v1.GeoAddress address = 2;
     */
    address?: GeoAddress;
    /**
     * Full result from geolocation service
     *
     * @generated from field: optional avn.connect.v1.AwsPlacesAddress aws_places_address = 3;
     */
    awsPlacesAddress?: AwsPlacesAddress;
    /**
     * Emails associated with place
     *
     * @generated from field: repeated avn.connect.v1.GeoContact emails = 4;
     */
    emails: GeoContact[];
    /**
     * Fax numbers associated with place
     *
     * @generated from field: repeated avn.connect.v1.GeoContact faxes = 5;
     */
    faxes: GeoContact[];
    /**
     * Phone number associated with place
     *
     * @generated from field: repeated avn.connect.v1.GeoContact phones = 6;
     */
    phones: GeoContact[];
    /**
     * Websites associated with place
     *
     * @generated from field: repeated avn.connect.v1.GeoContact websites = 7;
     */
    websites: GeoContact[];
};
/**
 * Describes the message avn.connect.v1.GetGeoPlaceResponse.
 * Use `create(GetGeoPlaceResponseSchema)` to create a new message.
 */
declare const GetGeoPlaceResponseSchema: GenMessage<GetGeoPlaceResponse>;
/**
 * @generated from message avn.connect.v1.GeoSuggestRequest
 */
type GeoSuggestRequest = Message<"avn.connect.v1.GeoSuggestRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Text to search for
     *
     * @generated from field: string text = 2;
     */
    text: string;
    /**
     * Optional list of countries to include in the search
     *
     * @generated from field: repeated string country_ids = 3;
     */
    countryIds: string[];
    /**
     * Optional position to use for ordering results
     *
     * @generated from field: optional avn.connect.v1.GeoLocation bias_position = 4;
     */
    biasPosition?: GeoLocation;
    /**
     * Max number of results
     *
     * @generated from field: optional int32 page_size = 5;
     */
    pageSize?: number;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 6;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GeoSuggestRequest.
 * Use `create(GeoSuggestRequestSchema)` to create a new message.
 */
declare const GeoSuggestRequestSchema: GenMessage<GeoSuggestRequest>;
/**
 * @generated from message avn.connect.v1.GeoSuggestResponse
 */
type GeoSuggestResponse = Message<"avn.connect.v1.GeoSuggestResponse"> & {
    /**
     * Matching places
     *
     * @generated from field: repeated avn.connect.v1.GeoPlace results = 1;
     */
    results: GeoPlace[];
};
/**
 * Describes the message avn.connect.v1.GeoSuggestResponse.
 * Use `create(GeoSuggestResponseSchema)` to create a new message.
 */
declare const GeoSuggestResponseSchema: GenMessage<GeoSuggestResponse>;
/**
 * @generated from message avn.connect.v1.GeoPlace
 */
type GeoPlace = Message<"avn.connect.v1.GeoPlace"> & {
    /**
     * Unique place ID
     *
     * @generated from field: string place_id = 1;
     */
    placeId: string;
    /**
     * Display name
     *
     * @generated from field: string title = 2;
     */
    title: string;
    /**
     * Type of place
     *
     * @generated from field: avn.connect.v1.GeoPlaceType place_type = 3;
     */
    placeType: GeoPlaceType;
    /**
     * Geographic location on the Earth
     *
     * @generated from field: optional avn.connect.v1.GeoLocation position = 7;
     */
    position?: GeoLocation;
};
/**
 * Describes the message avn.connect.v1.GeoPlace.
 * Use `create(GeoPlaceSchema)` to create a new message.
 */
declare const GeoPlaceSchema: GenMessage<GeoPlace>;
/**
 * Full results from AWS Places service
 *
 * @generated from message avn.connect.v1.AwsPlacesAddress
 */
type AwsPlacesAddress = Message<"avn.connect.v1.AwsPlacesAddress"> & {
    /**
     * @generated from field: string address_number = 1;
     */
    addressNumber: string;
    /**
     * @generated from field: string building = 2;
     */
    building: string;
    /**
     * @generated from field: string street = 3;
     */
    street: string;
    /**
     * @generated from field: string block = 4;
     */
    block: string;
    /**
     * @generated from field: string sub_block = 5;
     */
    subBlock: string;
    /**
     * @generated from field: repeated string intersection = 6;
     */
    intersection: string[];
    /**
     * @generated from field: string locality = 7;
     */
    locality: string;
    /**
     * @generated from field: string region = 8;
     */
    region: string;
    /**
     * @generated from field: string sub_region = 9;
     */
    subRegion: string;
    /**
     * @generated from field: string district = 10;
     */
    district: string;
    /**
     * @generated from field: string sub_district = 11;
     */
    subDistrict: string;
    /**
     * Post or zip code
     *
     * @generated from field: string post_code = 12;
     */
    postCode: string;
    /**
     * Country ID
     *
     * @generated from field: string country_id = 13;
     */
    countryId: string;
};
/**
 * Describes the message avn.connect.v1.AwsPlacesAddress.
 * Use `create(AwsPlacesAddressSchema)` to create a new message.
 */
declare const AwsPlacesAddressSchema: GenMessage<AwsPlacesAddress>;
/**
 * @generated from message avn.connect.v1.GeoAddress
 */
type GeoAddress = Message<"avn.connect.v1.GeoAddress"> & {
    /**
     * Street name and building name or number
     *
     * @generated from field: string street_address = 1;
     */
    streetAddress: string;
    /**
     * City, town, or village
     *
     * @generated from field: string city = 2;
     */
    city: string;
    /**
     * State or municipality
     *
     * @generated from field: string state = 3;
     */
    state: string;
    /**
     * Post or zip code
     *
     * @generated from field: string post_code = 4;
     */
    postCode: string;
    /**
     * Country ID
     *
     * @generated from field: string country_id = 5;
     */
    countryId: string;
};
/**
 * Describes the message avn.connect.v1.GeoAddress.
 * Use `create(GeoAddressSchema)` to create a new message.
 */
declare const GeoAddressSchema: GenMessage<GeoAddress>;
/**
 * Annotated contact information (email, mobile, fax, etc...)
 *
 * @generated from message avn.connect.v1.GeoContact
 */
type GeoContact = Message<"avn.connect.v1.GeoContact"> & {
    /**
     * Display label for contact information
     *
     * @generated from field: string label = 1;
     */
    label: string;
    /**
     * Contact information
     *
     * @generated from field: string value = 2;
     */
    value: string;
};
/**
 * Describes the message avn.connect.v1.GeoContact.
 * Use `create(GeoContactSchema)` to create a new message.
 */
declare const GeoContactSchema: GenMessage<GeoContact>;
/**
 * @generated from message avn.connect.v1.GeoLocation
 */
type GeoLocation = Message<"avn.connect.v1.GeoLocation"> & {
    /**
     * Longitude (degrees)
     *
     * @generated from field: float lon = 1;
     */
    lon: number;
    /**
     * Latitude (degrees)
     *
     * @generated from field: float lat = 2;
     */
    lat: number;
};
/**
 * Describes the message avn.connect.v1.GeoLocation.
 * Use `create(GeoLocationSchema)` to create a new message.
 */
declare const GeoLocationSchema: GenMessage<GeoLocation>;
/**
 * Rectangular boundary
 *
 * @generated from message avn.connect.v1.GeoBounds
 */
type GeoBounds = Message<"avn.connect.v1.GeoBounds"> & {
    /**
     * South-west corner of boundary
     *
     * @generated from field: avn.connect.v1.GeoLocation sw = 1;
     */
    sw?: GeoLocation;
    /**
     * North-east corner of boundary
     *
     * @generated from field: avn.connect.v1.GeoLocation ne = 2;
     */
    ne?: GeoLocation;
};
/**
 * Describes the message avn.connect.v1.GeoBounds.
 * Use `create(GeoBoundsSchema)` to create a new message.
 */
declare const GeoBoundsSchema: GenMessage<GeoBounds>;
/**
 * @generated from enum avn.connect.v1.GeoPlaceType
 */
declare enum GeoPlaceType {
    /**
     * @generated from enum value: GEO_PLACE_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_BLOCK = 1;
     */
    BLOCK = 1,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_COUNTRY = 2;
     */
    COUNTRY = 2,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_DISTRICT = 3;
     */
    DISTRICT = 3,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_INTERPOLATED_ADDRESS = 4;
     */
    INTERPOLATED_ADDRESS = 4,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_INTERSECTION = 5;
     */
    INTERSECTION = 5,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_LOCALITY = 6;
     */
    LOCALITY = 6,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_POINT_ADDRESS = 7;
     */
    POINT_ADDRESS = 7,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_POINT_OF_INTEREST = 8;
     */
    POINT_OF_INTEREST = 8,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_POSTAL_CODE = 9;
     */
    POSTAL_CODE = 9,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_REGION = 10;
     */
    REGION = 10,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_STREET = 11;
     */
    STREET = 11,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_SUB_BLOCK = 12;
     */
    SUB_BLOCK = 12,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_SUB_DISTRICT = 13;
     */
    SUB_DISTRICT = 13,
    /**
     * @generated from enum value: GEO_PLACE_TYPE_SUB_REGION = 14;
     */
    SUB_REGION = 14
}
/**
 * Describes the enum avn.connect.v1.GeoPlaceType.
 */
declare const GeoPlaceTypeSchema: GenEnum<GeoPlaceType>;
/**
 * @generated from service avn.connect.v1.GeoService
 */
declare const GeoService: GenService<{
    /**
     * Find a place using a given id
     *
     * @generated from rpc avn.connect.v1.GeoService.GetGeoPlace
     */
    getGeoPlace: {
        methodKind: "unary";
        input: typeof GetGeoPlaceRequestSchema;
        output: typeof GetGeoPlaceResponseSchema;
    };
    /**
     * Lightweight searching suitable for things like autocomplete
     *
     * @generated from rpc avn.connect.v1.GeoService.GeoSuggest
     */
    geoSuggest: {
        methodKind: "unary";
        input: typeof GeoSuggestRequestSchema;
        output: typeof GeoSuggestResponseSchema;
    };
}>;

/**
 * Describes the file grpc/health/v1/healthcheck.proto.
 */
declare const file_grpc_health_v1_healthcheck: GenFile;
/**
 * @generated from message grpc.health.v1.HealthCheckRequest
 */
type HealthCheckRequest = Message<"grpc.health.v1.HealthCheckRequest"> & {
    /**
     * @generated from field: string service = 1;
     */
    service: string;
};
/**
 * Describes the message grpc.health.v1.HealthCheckRequest.
 * Use `create(HealthCheckRequestSchema)` to create a new message.
 */
declare const HealthCheckRequestSchema: GenMessage<HealthCheckRequest>;
/**
 * @generated from message grpc.health.v1.HealthCheckResponse
 */
type HealthCheckResponse = Message<"grpc.health.v1.HealthCheckResponse"> & {
    /**
     * @generated from field: grpc.health.v1.HealthCheckResponse.ServingStatus status = 1;
     */
    status: HealthCheckResponse_ServingStatus;
};
/**
 * Describes the message grpc.health.v1.HealthCheckResponse.
 * Use `create(HealthCheckResponseSchema)` to create a new message.
 */
declare const HealthCheckResponseSchema: GenMessage<HealthCheckResponse>;
/**
 * @generated from enum grpc.health.v1.HealthCheckResponse.ServingStatus
 */
declare enum HealthCheckResponse_ServingStatus {
    /**
     * @generated from enum value: UNKNOWN = 0;
     */
    UNKNOWN = 0,
    /**
     * @generated from enum value: SERVING = 1;
     */
    SERVING = 1,
    /**
     * @generated from enum value: NOT_SERVING = 2;
     */
    NOT_SERVING = 2,
    /**
     * Used only by the Watch method.
     *
     * @generated from enum value: SERVICE_UNKNOWN = 3;
     */
    SERVICE_UNKNOWN = 3
}
/**
 * Describes the enum grpc.health.v1.HealthCheckResponse.ServingStatus.
 */
declare const HealthCheckResponse_ServingStatusSchema: GenEnum<HealthCheckResponse_ServingStatus>;
/**
 * @generated from service grpc.health.v1.Health
 */
declare const Health: GenService<{
    /**
     * @generated from rpc grpc.health.v1.Health.Check
     */
    check: {
        methodKind: "unary";
        input: typeof HealthCheckRequestSchema;
        output: typeof HealthCheckResponseSchema;
    };
    /**
     * @generated from rpc grpc.health.v1.Health.Watch
     */
    watch: {
        methodKind: "server_streaming";
        input: typeof HealthCheckRequestSchema;
        output: typeof HealthCheckResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/info.proto.
 */
declare const file_avn_connect_v1_info: GenFile;
/**
 * @generated from message avn.connect.v1.GetNewsRequest
 */
type GetNewsRequest = Message<"avn.connect.v1.GetNewsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 2;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetNewsRequest.
 * Use `create(GetNewsRequestSchema)` to create a new message.
 */
declare const GetNewsRequestSchema: GenMessage<GetNewsRequest>;
/**
 * @generated from message avn.connect.v1.GetNewsResponse
 */
type GetNewsResponse = Message<"avn.connect.v1.GetNewsResponse"> & {
    /**
     * Blog posts
     *
     * @generated from field: repeated avn.connect.v1.Hyperlink links = 1;
     */
    links: Hyperlink[];
};
/**
 * Describes the message avn.connect.v1.GetNewsResponse.
 * Use `create(GetNewsResponseSchema)` to create a new message.
 */
declare const GetNewsResponseSchema: GenMessage<GetNewsResponse>;
/**
 * @generated from message avn.connect.v1.Hyperlink
 */
type Hyperlink = Message<"avn.connect.v1.Hyperlink"> & {
    /**
     * Anchor text
     *
     * @generated from field: string text = 1;
     */
    text: string;
    /**
     * Linked document
     *
     * @generated from field: string link_url = 2;
     */
    linkUrl: string;
    /**
     * Preview to use for display
     *
     * @generated from field: string preview_url = 3;
     */
    previewUrl: string;
};
/**
 * Describes the message avn.connect.v1.Hyperlink.
 * Use `create(HyperlinkSchema)` to create a new message.
 */
declare const HyperlinkSchema: GenMessage<Hyperlink>;
/**
 * @generated from message avn.connect.v1.GetGeoFeedRequest
 */
type GetGeoFeedRequest = Message<"avn.connect.v1.GetGeoFeedRequest"> & {
    /**
     * Authorization for the request. Accepted for consistency but not required:
     * this feed is intended to be public.
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
};
/**
 * Describes the message avn.connect.v1.GetGeoFeedRequest.
 * Use `create(GetGeoFeedRequestSchema)` to create a new message.
 */
declare const GetGeoFeedRequestSchema: GenMessage<GetGeoFeedRequest>;
/**
 * @generated from message avn.connect.v1.GetGeoFeedResponse
 */
type GetGeoFeedResponse = Message<"avn.connect.v1.GetGeoFeedResponse"> & {
    /**
     * Activity clusters, each at an approximate (IP-derived) location
     *
     * @generated from field: repeated avn.connect.v1.GeoFeedCell cells = 1;
     */
    cells: GeoFeedCell[];
    /**
     * When this snapshot was generated
     *
     * @generated from field: google.protobuf.Timestamp generated = 2;
     */
    generated?: Timestamp;
    /**
     * The rolling window (seconds) of activity represented in this snapshot
     *
     * @generated from field: int32 window_seconds = 3;
     */
    windowSeconds: number;
};
/**
 * Describes the message avn.connect.v1.GetGeoFeedResponse.
 * Use `create(GetGeoFeedResponseSchema)` to create a new message.
 */
declare const GetGeoFeedResponseSchema: GenMessage<GetGeoFeedResponse>;
/**
 * A cluster of recent activity: plays of one activity reported from one
 * source (an organization, or a source network for events without one).
 * activity_id and source together form the aggregation key.
 *
 * @generated from message avn.connect.v1.GeoFeedCell
 */
type GeoFeedCell = Message<"avn.connect.v1.GeoFeedCell"> & {
    /**
     * Approximate location of the cluster, as resolved from one of the source's
     * reporting IP addresses (city-level at best, country centroid otherwise) —
     * a source egressing through several addresses displays at the first one
     * located, so all its cells share an anchor.
     *
     * @generated from field: avn.connect.v1.GeoLocation location = 1;
     */
    location?: GeoLocation;
    /**
     * Number of pings aggregated into this cell within the window
     *
     * @generated from field: int32 count = 2;
     */
    count: number;
    /**
     * The activity being played at this cluster (0 if unknown)
     *
     * @generated from field: int32 activity_id = 3;
     */
    activityId: number;
    /**
     * Opaque, pseudonymous tag for the reporting organization (or network, for
     * events recorded without one): a salted hash — never the org id or address
     * itself, and stable only for the lifetime of the serving process.
     * Distinguishes same-location cells from different sources, e.g. two
     * schools resolved to the same city.
     *
     * @generated from field: string source = 4;
     */
    source: string;
    /**
     * Age of each ping in this cell (seconds before `generated`, oldest first;
     * one entry per counted ping). Ages rather than absolute timestamps, so
     * client clock skew cannot misplace them. Lets a client joining mid-window
     * reconstruct when the plays happened rather than treating the whole
     * window as "now".
     *
     * @generated from field: repeated uint32 age_seconds = 5;
     */
    ageSeconds: number[];
};
/**
 * Describes the message avn.connect.v1.GeoFeedCell.
 * Use `create(GeoFeedCellSchema)` to create a new message.
 */
declare const GeoFeedCellSchema: GenMessage<GeoFeedCell>;
/**
 * Information about Eduverse
 *
 * @generated from service avn.connect.v1.InfoService
 */
declare const InfoService: GenService<{
    /**
     * Get the latest news from the Eduverse blog
     *
     * @generated from rpc avn.connect.v1.InfoService.GetNews
     */
    getNews: {
        methodKind: "unary";
        input: typeof GetNewsRequestSchema;
        output: typeof GetNewsResponseSchema;
    };
    /**
     * Aggregated, anonymised feed of recent ClassVR activity grouped into
     * approximate locations. Intended as a public "activity around the world" feed.
     *
     * @generated from rpc avn.connect.v1.InfoService.GetGeoFeed
     */
    getGeoFeed: {
        methodKind: "unary";
        input: typeof GetGeoFeedRequestSchema;
        output: typeof GetGeoFeedResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/ktx.proto.
 */
declare const file_avn_connect_v1_ktx: GenFile;
/**
 * Supports a subset of the useful parameters for toktx
 *
 * @generated from message avn.connect.v1.ToKtxRequest
 */
type ToKtxRequest = Message<"avn.connect.v1.ToKtxRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: avn.connect.v1.ToKtxParameters params = 2;
     */
    params?: ToKtxParameters;
};
/**
 * Describes the message avn.connect.v1.ToKtxRequest.
 * Use `create(ToKtxRequestSchema)` to create a new message.
 */
declare const ToKtxRequestSchema: GenMessage<ToKtxRequest>;
/**
 * @generated from message avn.connect.v1.ToKtxParameters
 */
type ToKtxParameters = Message<"avn.connect.v1.ToKtxParameters"> & {
    /**
     * Input files
     *
     * @generated from field: repeated string urls = 1;
     */
    urls: string[];
    /**
     * --cubemap    KTX file is for a cubemap. At least 6 <infile>s must be provided,
     *              more if --mipmap is also specified. Provide the images in the
     *              order +X, -X, +Y, -Y, +Z, -Z where the arrangement is a
     *              left-handed coordinate system with +Y up. So if you're facing +Z,
     *              -X will be on your left and +X on your right. If --layers > 1
     *              is specified, provide the faces for layer 0 first then for
     *              layer 1, etc. Images must have an upper left origin so
     *              --lower_left_maps_to_s0t0 is ignored with this option.
     *
     * @generated from field: optional bool cubemap = 2;
     */
    cubemap?: boolean;
    /**
     * --genmipmap  Causes mipmaps to be generated for each input file. This option
     *              is mutually exclusive with --automipmap and --mipmap. When set
     *              the following mipmap-generation related options become valid,
     *              otherwise they are ignored.
     *
     * @generated from field: optional bool genmipmap = 3;
     */
    genmipmap?: boolean;
    /**
     * --target_type <type>
     *              Specify the number of components in the created texture. type is
     *              one of the following strings: @c R, @c RG, @c RGB or @c RGBA.
     *              Excess input components will be dropped. Output components with
     *              no mapping from the input will be set to 0 or, if the alpha
     *              component, 1.0.
     *
     * @generated from field: optional string target_type = 4;
     */
    targetType?: string;
    /**
     * --t2         Output in KTX2 format. Default is KTX.
     *
     * @generated from field: optional bool t2 = 5;
     */
    t2?: boolean;
    /**
     * --bcmp       Supercompress the image data with ETC1S / BasisLZ. Implies --t2.
     *              RED images will become RGB with RED in each component. RG images
     *              will have R in the RGB part and G in the alpha part of the
     *              compressed texture. When set, the following BasisLZ-related
     *              options become valid, otherwise they are ignored.
     *
     * @generated from field: optional bool bcmp = 6;
     */
    bcmp?: boolean;
    /**
     *     --clevel <level>
     *              ETC1S / BasisLZ compression level, an encoding speed vs. quality
     *              tradeoff. Range is [0,5], default is 1. Higher values are slower,
     *              but give higher quality.
     *
     * @generated from field: optional int32 clevel = 7;
     */
    clevel?: number;
    /**
     *     --qlevel <level>
     *              ETC1S / BasisLZ quality level. Range is [1,255]. Lower gives
     *              better compression/lower quality/faster. Higher gives less
     *              compression/higher quality/slower. --qlevel automatically
     *              determines values for --max_endpoints, --max-selectors,
     *              --endpoint_rdo_threshold and --selector_rdo_threshold for the
     *              target quality level. Setting these options overrides the values
     *              determined by -qlevel which defaults to 128 if neither it nor
     *              both of --max_endpoints and --max_selectors have been set.
     *
     *              Note that both of --max_endpoints and --max_selectors
     *              must be set for them to have any effect. If all three options
     *              are set, a warning will be issued that --qlevel will be ignored.
     *
     *              Note also that --qlevel will only determine values for
     *              --endpoint_rdo_threshold and --selector_rdo_threshold when
     *              its value exceeds 128, otherwise their defaults will be used.
     *
     * @generated from field: optional int32 qlevel = 8;
     */
    qlevel?: number;
    /**
     * DEPRECATED: https://github.com/KhronosGroup/KTX-Software/discussions/601
     *     --normal_map
     *              Tunes codec parameters for better quality on normal maps (no
     *              selector RDO, no endpoint RDO). Only valid for linear textures.
     *
     * @generated from field: optional bool normal_map = 9 [deprecated = true];
     * @deprecated
     */
    normalMap?: boolean;
    /**
     * --uastc [<level>]
     *              Create a texture in high-quality transcodable UASTC format.
     *              Implies --t2. The optional parameter <level> selects a speed
     *              vs quality tradeoff as shown in the following table:
     *
     *                Level |  Speed    | Quality
     *                ----- | -------   | -------
     *                  0   |  Fastest  | 43.45dB
     *                  1   |  Faster   | 46.49dB
     *                  2   |  Default  | 47.47dB
     *                  3   |  Slower   | 48.01dB
     *                  4   | Very slow | 48.24dB
     *
     *              You are strongly encouraged to also specify --zcmp to losslessly
     *              compress the UASTC data. This and any LZ-style compression can
     *              be made more effective by conditioning the UASTC texture data
     *              using the Rate Distortion Optimization (RDO) post-process stage.
     *
     * @generated from field: optional int32 uastc = 10;
     */
    uastc?: number;
    /**
     * --zcmp [<compressionLevel>]
     *              Supercompress the data with Zstandard. Implies --t2. Can be used
     *              with data in any format except ETC1S / BasisLZ (--bcmp). Most
     *              effective with RDO-conditioned UASTC or uncompressed formats. The
     *              optional compressionLevel range is 1 - 22 and the default is 3.
     *              Lower values=faster but give less compression. Values above 20
     *              should be used with caution as they require more memory.
     *
     * @generated from field: optional int32 zcmp = 11;
     */
    zcmp?: number;
    /**
     * --assign_oetf <linear|srgb>
     *              Force the created texture to have the specified transfer
     *              function. If this is specified, implicit or explicit color space
     *              information from the input file(s) will be ignored and no color
     *              transformation will be performed. USE WITH CAUTION preferably
     *              only when you know the file format information is wrong.
     *
     * @generated from field: optional string assign_oetf = 12;
     */
    assignOetf?: string;
    /**
     * --assign_primaries <bt709|none|srgb>
     *              Force the created texture to have the specified primaries. If
     *              this is specified, implicit or explicit color space information
     *              from the input file(s) will be ignored and no color
     *              transformation will be performed. USE WITH CAUTION preferably
     *              only when you know the file format information is wrong.
     *
     * @generated from field: optional string assign_primaries = 13;
     */
    assignPrimaries?: string;
    /**
     * --convert_oetf <linear|srgb>
     *              Convert the input images to the specified transfer function, if
     *              the current transfer function is different. If both this and
     *              --assign_oetf are specified, conversion will be performed from
     *              the assigned transfer function to the transfer function specified
     *              by this option, if different.
     *
     * @generated from field: optional string convert_oetf = 14;
     */
    convertOetf?: string;
    /**
     *   You can prevent conversion of the normal map to two components
     *   by specifying '--input_swizzle rgb1'.
     *
     * @generated from field: optional bool normal_mode = 15;
     */
    normalMode?: boolean;
    /**
     * --input_swizzle <swizzle>
     *              Swizzle the input components according to swizzle which is an
     *              alhpanumeric sequence matching the regular expression
     *              ^[rgba01]{4}$.
     *
     * @generated from field: optional string input_swizzle = 16;
     */
    inputSwizzle?: string;
};
/**
 * Describes the message avn.connect.v1.ToKtxParameters.
 * Use `create(ToKtxParametersSchema)` to create a new message.
 */
declare const ToKtxParametersSchema: GenMessage<ToKtxParameters>;
/**
 * @generated from message avn.connect.v1.ToKtxResponse
 */
type ToKtxResponse = Message<"avn.connect.v1.ToKtxResponse"> & {
    /**
     * @generated from field: string url = 1;
     */
    url: string;
};
/**
 * Describes the message avn.connect.v1.ToKtxResponse.
 * Use `create(ToKtxResponseSchema)` to create a new message.
 */
declare const ToKtxResponseSchema: GenMessage<ToKtxResponse>;
/**
 * @generated from service avn.connect.v1.KtxService
 */
declare const KtxService: GenService<{
    /**
     * @generated from rpc avn.connect.v1.KtxService.ToKtx
     */
    toKtx: {
        methodKind: "unary";
        input: typeof ToKtxRequestSchema;
        output: typeof ToKtxResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/languages.proto.
 */
declare const file_avn_connect_v1_languages: GenFile;
/**
 * @generated from message avn.connect.v1.Language
 */
type Language = Message<"avn.connect.v1.Language"> & {
    /**
     * Unique language ID (IETF BCP 47)
     *
     * @generated from field: string language_id = 1;
     */
    languageId: string;
    /**
     * Name (in the language itself)
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Display name (in the target language)
     *
     * @generated from field: string text = 6;
     */
    text: string;
    /**
     * Name in English
     *
     * @generated from field: string name_english = 3;
     */
    nameEnglish: string;
    /**
     * Text direction
     *
     * @generated from field: avn.connect.v1.TextDirection dir = 4;
     */
    dir: TextDirection;
    /**
     * Associated content tag
     *
     * @generated from field: optional int32 tag_id = 5;
     */
    tagId?: number;
};
/**
 * Describes the message avn.connect.v1.Language.
 * Use `create(LanguageSchema)` to create a new message.
 */
declare const LanguageSchema: GenMessage<Language>;
/**
 * @generated from message avn.connect.v1.GetLanguagesRequest
 */
type GetLanguagesRequest = Message<"avn.connect.v1.GetLanguagesRequest"> & {
    /**
     * Translation instructions for the display name. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 1;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetLanguagesRequest.
 * Use `create(GetLanguagesRequestSchema)` to create a new message.
 */
declare const GetLanguagesRequestSchema: GenMessage<GetLanguagesRequest>;
/**
 * @generated from message avn.connect.v1.GetLanguagesResponse
 */
type GetLanguagesResponse = Message<"avn.connect.v1.GetLanguagesResponse"> & {
    /**
     * All supported languages
     *
     * @generated from field: repeated avn.connect.v1.Language languages = 1;
     */
    languages: Language[];
};
/**
 * Describes the message avn.connect.v1.GetLanguagesResponse.
 * Use `create(GetLanguagesResponseSchema)` to create a new message.
 */
declare const GetLanguagesResponseSchema: GenMessage<GetLanguagesResponse>;
/**
 * @generated from enum avn.connect.v1.TextDirection
 */
declare enum TextDirection {
    /**
     * Text runs from left-to-right
     *
     * @generated from enum value: TEXT_DIRECTION_LTR = 0;
     */
    LTR = 0,
    /**
     * Text runs from right-to-left
     *
     * @generated from enum value: TEXT_DIRECTION_RTL = 1;
     */
    RTL = 1
}
/**
 * Describes the enum avn.connect.v1.TextDirection.
 */
declare const TextDirectionSchema: GenEnum<TextDirection>;
/**
 * @generated from service avn.connect.v1.LanguageService
 */
declare const LanguageService: GenService<{
    /**
     * Get all supported languages
     *
     * @generated from rpc avn.connect.v1.LanguageService.GetLanguages
     */
    getLanguages: {
        methodKind: "unary";
        input: typeof GetLanguagesRequestSchema;
        output: typeof GetLanguagesResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/neighbors.proto.
 */
declare const file_avn_connect_v1_neighbors: GenFile;
/**
 * @generated from message avn.connect.v1.NeighborServer
 */
type NeighborServer = Message<"avn.connect.v1.NeighborServer"> & {
    /**
     * Server ID
     *
     * @generated from field: string client_id = 1;
     */
    clientId: string;
    /**
     * Ordered list of WAN IPs the server has called in on
     *
     * @generated from field: repeated string wan_addresses = 3;
     */
    wanAddresses: string[];
    /**
     * The LAN port for the local server
     *
     * @generated from field: int32 lan_port = 4;
     */
    lanPort: number;
    /**
     * Server display name
     *
     * @generated from field: string client_name = 5;
     */
    clientName: string;
    /**
     * Ordered list of the LAN hostnames for the server
     *
     * @generated from field: repeated string lan_hostnames = 6;
     */
    lanHostnames: string[];
};
/**
 * Describes the message avn.connect.v1.NeighborServer.
 * Use `create(NeighborServerSchema)` to create a new message.
 */
declare const NeighborServerSchema: GenMessage<NeighborServer>;
/**
 * @generated from message avn.connect.v1.RegisterNeighborServerRequest
 */
type RegisterNeighborServerRequest = Message<"avn.connect.v1.RegisterNeighborServerRequest"> & {
    /**
     * @generated from field: avn.connect.v1.ClientCredentials client = 1;
     */
    client?: ClientCredentials;
    /**
     * The LAN port for this server
     *
     * @generated from field: int32 lan_port = 3;
     */
    lanPort: number;
    /**
     * The LAN addresses for this server
     *
     * @generated from field: repeated string lan_addresses = 4;
     */
    lanAddresses: string[];
    /**
     * Server display name
     *
     * @generated from field: string client_name = 5;
     */
    clientName: string;
    /**
     * Server statistics with flexible schema
     *
     * @generated from field: optional google.protobuf.Struct client_statistics = 6;
     */
    clientStatistics?: JsonObject;
};
/**
 * Describes the message avn.connect.v1.RegisterNeighborServerRequest.
 * Use `create(RegisterNeighborServerRequestSchema)` to create a new message.
 */
declare const RegisterNeighborServerRequestSchema: GenMessage<RegisterNeighborServerRequest>;
/**
 * @generated from message avn.connect.v1.RegisterNeighborServerResponse
 */
type RegisterNeighborServerResponse = Message<"avn.connect.v1.RegisterNeighborServerResponse"> & {
    /**
     * @generated from field: avn.connect.v1.NeighborServer server = 1;
     */
    server?: NeighborServer;
};
/**
 * Describes the message avn.connect.v1.RegisterNeighborServerResponse.
 * Use `create(RegisterNeighborServerResponseSchema)` to create a new message.
 */
declare const RegisterNeighborServerResponseSchema: GenMessage<RegisterNeighborServerResponse>;
/**
 * @generated from service avn.connect.v1.NeighborService
 */
declare const NeighborService: GenService<{
    /**
     * @generated from rpc avn.connect.v1.NeighborService.RegisterNeighborServer
     */
    registerNeighborServer: {
        methodKind: "unary";
        input: typeof RegisterNeighborServerRequestSchema;
        output: typeof RegisterNeighborServerResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/organization_membership.proto.
 */
declare const file_avn_connect_v1_organization_membership: GenFile;
/**
 * Users can belong to one or more organization
 *
 * @generated from message avn.connect.v1.OrganizationMembership
 */
type OrganizationMembership = Message<"avn.connect.v1.OrganizationMembership"> & {
    /**
     * User ID
     *
     * @generated from field: int32 user_id = 1;
     */
    userId: number;
    /**
     * Organization ID
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
    /**
     * Role ID
     *
     * @generated from field: int32 role_id = 3;
     */
    roleId: number;
    /**
     * Any permissions in addition to those granted by the role
     *
     * @generated from field: repeated string additional_permissions = 4;
     */
    additionalPermissions: string[];
};
/**
 * Describes the message avn.connect.v1.OrganizationMembership.
 * Use `create(OrganizationMembershipSchema)` to create a new message.
 */
declare const OrganizationMembershipSchema: GenMessage<OrganizationMembership>;

/**
 * Describes the file avn/connect/v1/organizations.proto.
 */
declare const file_avn_connect_v1_organizations: GenFile;
/**
 * A member of an organization
 *
 * @generated from message avn.connect.v1.OrganizationUser
 */
type OrganizationUser = Message<"avn.connect.v1.OrganizationUser"> & {
    /**
     * Membership details (role and any additional permissions)
     *
     * @generated from field: avn.connect.v1.OrganizationMembership membership = 1;
     */
    membership?: OrganizationMembership;
    /**
     * User display name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * User email address
     *
     * @generated from field: string email = 3;
     */
    email: string;
    /**
     * When the user last logged in
     *
     * @generated from field: optional google.protobuf.Timestamp last_login = 4;
     */
    lastLogin?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.OrganizationUser.
 * Use `create(OrganizationUserSchema)` to create a new message.
 */
declare const OrganizationUserSchema: GenMessage<OrganizationUser>;
/**
 * @generated from message avn.connect.v1.GetOrganizationUsersRequest
 */
type GetOrganizationUsersRequest = Message<"avn.connect.v1.GetOrganizationUsersRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Organization to list members for
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
    /**
     * Maximum number of results to return. Defaults to 30 when unset or 0, and is clamped to a
     * maximum of 256. Negative values are rejected.
     *
     * @generated from field: optional int32 page_size = 3;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search. Must be a token returned as next_page_token by an
     * earlier call; malformed tokens are rejected rather than returning an empty page.
     *
     * @generated from field: optional string page_token = 4;
     */
    pageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetOrganizationUsersRequest.
 * Use `create(GetOrganizationUsersRequestSchema)` to create a new message.
 */
declare const GetOrganizationUsersRequestSchema: GenMessage<GetOrganizationUsersRequest>;
/**
 * @generated from message avn.connect.v1.GetOrganizationUsersResponse
 */
type GetOrganizationUsersResponse = Message<"avn.connect.v1.GetOrganizationUsersResponse"> & {
    /**
     * Organization members
     *
     * @generated from field: repeated avn.connect.v1.OrganizationUser results = 1;
     */
    results: OrganizationUser[];
    /**
     * Token to use to get more pages of results or unset if no more results are available
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetOrganizationUsersResponse.
 * Use `create(GetOrganizationUsersResponseSchema)` to create a new message.
 */
declare const GetOrganizationUsersResponseSchema: GenMessage<GetOrganizationUsersResponse>;
/**
 * @generated from message avn.connect.v1.SetOrganizationMembershipRequest
 */
type SetOrganizationMembershipRequest = Message<"avn.connect.v1.SetOrganizationMembershipRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Membership state to apply. Identifies the target user and organization; the role and additional permissions replace any existing membership record
     *
     * @generated from field: avn.connect.v1.OrganizationMembership membership = 2;
     */
    membership?: OrganizationMembership;
};
/**
 * Describes the message avn.connect.v1.SetOrganizationMembershipRequest.
 * Use `create(SetOrganizationMembershipRequestSchema)` to create a new message.
 */
declare const SetOrganizationMembershipRequestSchema: GenMessage<SetOrganizationMembershipRequest>;
/**
 * @generated from message avn.connect.v1.RemoveOrganizationUserRequest
 */
type RemoveOrganizationUserRequest = Message<"avn.connect.v1.RemoveOrganizationUserRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Organization to remove the user from
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
    /**
     * User to remove
     *
     * @generated from field: int32 user_id = 3;
     */
    userId: number;
};
/**
 * Describes the message avn.connect.v1.RemoveOrganizationUserRequest.
 * Use `create(RemoveOrganizationUserRequestSchema)` to create a new message.
 */
declare const RemoveOrganizationUserRequestSchema: GenMessage<RemoveOrganizationUserRequest>;
/**
 * @generated from message avn.connect.v1.GetSubordinateOrganizationsRequest
 */
type GetSubordinateOrganizationsRequest = Message<"avn.connect.v1.GetSubordinateOrganizationsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Organization whose direct children are listed
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
    /**
     * Maximum number of results to return. Defaults to 30 when unset or 0, and is clamped to a
     * maximum of 256. Negative values are rejected.
     *
     * @generated from field: optional int32 page_size = 3;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search. Must be a token returned as next_page_token by an
     * earlier call; malformed tokens are rejected rather than returning an empty page.
     *
     * @generated from field: optional string page_token = 4;
     */
    pageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetSubordinateOrganizationsRequest.
 * Use `create(GetSubordinateOrganizationsRequestSchema)` to create a new message.
 */
declare const GetSubordinateOrganizationsRequestSchema: GenMessage<GetSubordinateOrganizationsRequest>;
/**
 * @generated from message avn.connect.v1.GetSubordinateOrganizationsResponse
 */
type GetSubordinateOrganizationsResponse = Message<"avn.connect.v1.GetSubordinateOrganizationsResponse"> & {
    /**
     * Direct child organizations, ordered by name then ID
     *
     * @generated from field: repeated avn.connect.v1.OrganizationInfo results = 1;
     */
    results: OrganizationInfo[];
    /**
     * Token to use to get more pages of results or unset if no more results are available
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetSubordinateOrganizationsResponse.
 * Use `create(GetSubordinateOrganizationsResponseSchema)` to create a new message.
 */
declare const GetSubordinateOrganizationsResponseSchema: GenMessage<GetSubordinateOrganizationsResponse>;
/**
 * @generated from message avn.connect.v1.JoinOrganizationRequest
 */
type JoinOrganizationRequest = Message<"avn.connect.v1.JoinOrganizationRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Secret join code to permit user to join an organization
     *
     * @generated from field: string join_code = 2;
     */
    joinCode: string;
};
/**
 * Describes the message avn.connect.v1.JoinOrganizationRequest.
 * Use `create(JoinOrganizationRequestSchema)` to create a new message.
 */
declare const JoinOrganizationRequestSchema: GenMessage<JoinOrganizationRequest>;
/**
 * @generated from message avn.connect.v1.JoinOrganizationResponse
 */
type JoinOrganizationResponse = Message<"avn.connect.v1.JoinOrganizationResponse"> & {};
/**
 * Describes the message avn.connect.v1.JoinOrganizationResponse.
 * Use `create(JoinOrganizationResponseSchema)` to create a new message.
 */
declare const JoinOrganizationResponseSchema: GenMessage<JoinOrganizationResponse>;
/**
 * @generated from message avn.connect.v1.CreateOrganizationRequest
 */
type CreateOrganizationRequest = Message<"avn.connect.v1.CreateOrganizationRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Initial information for creating an organization
     *
     * @generated from field: avn.connect.v1.OrganizationSpec organization_spec = 2;
     */
    organizationSpec?: OrganizationSpec;
};
/**
 * Describes the message avn.connect.v1.CreateOrganizationRequest.
 * Use `create(CreateOrganizationRequestSchema)` to create a new message.
 */
declare const CreateOrganizationRequestSchema: GenMessage<CreateOrganizationRequest>;
/**
 * @generated from message avn.connect.v1.CreateOrganizationResponse
 */
type CreateOrganizationResponse = Message<"avn.connect.v1.CreateOrganizationResponse"> & {
    /**
     * Newly created organization
     *
     * @generated from field: avn.connect.v1.Organization organization = 1;
     */
    organization?: Organization;
};
/**
 * Describes the message avn.connect.v1.CreateOrganizationResponse.
 * Use `create(CreateOrganizationResponseSchema)` to create a new message.
 */
declare const CreateOrganizationResponseSchema: GenMessage<CreateOrganizationResponse>;
/**
 * @generated from message avn.connect.v1.OrganizationInfo
 */
type OrganizationInfo = Message<"avn.connect.v1.OrganizationInfo"> & {
    /**
     * Organization ID
     *
     * @generated from field: int32 organization_id = 1;
     */
    organizationId: number;
    /**
     * Display name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * When the organization was last modified
     *
     * @generated from field: google.protobuf.Timestamp updated = 4;
     */
    updated?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.OrganizationInfo.
 * Use `create(OrganizationInfoSchema)` to create a new message.
 */
declare const OrganizationInfoSchema: GenMessage<OrganizationInfo>;
/**
 * @generated from message avn.connect.v1.Organization
 */
type Organization = Message<"avn.connect.v1.Organization"> & {
    /**
     * Unique organization ID
     *
     * @generated from field: int32 organization_id = 1;
     */
    organizationId: number;
    /**
     * Contact email address
     *
     * @generated from field: string email = 2;
     */
    email: string;
    /**
     * Display name
     *
     * @generated from field: string name = 3;
     */
    name: string;
    /**
     * Postal address
     *
     * @generated from field: string address = 4;
     */
    address: string;
    /**
     * Post or ZIP code
     *
     * @generated from field: string postcode = 5;
     */
    postcode: string;
    /**
     * Primary contact phone number
     *
     * @generated from field: string phone = 6;
     */
    phone: string;
    /**
     * Local timezone
     *
     * @generated from field: string timezone = 7;
     */
    timezone: string;
    /**
     * Default language ID
     *
     * @generated from field: string language_id = 8;
     */
    languageId: string;
    /**
     * Has this organization been deleted?
     *
     * @generated from field: bool deleted = 9;
     */
    deleted: boolean;
    /**
     * When the organization was created
     *
     * @generated from field: optional google.protobuf.Timestamp created = 10;
     */
    created?: Timestamp;
    /**
     * When the organization was last modified
     *
     * @generated from field: optional google.protobuf.Timestamp updated = 11;
     */
    updated?: Timestamp;
    /**
     * Secret to use for device enrollment
     *
     * @generated from field: optional string enrollment_secret = 12;
     */
    enrollmentSecret?: string;
    /**
     * city
     *
     * @generated from field: string city = 13;
     */
    city: string;
    /**
     * State or province
     *
     * @generated from field: string state = 14;
     */
    state: string;
    /**
     * Country
     *
     * @generated from field: string country_id = 15;
     */
    countryId: string;
    /**
     * Is this organization an approved publisher?
     *
     * @generated from field: bool publisher = 16;
     */
    publisher: boolean;
    /**
     * ID of the parent organization in the hierarchy. 0 only for the root organization
     *
     * @generated from field: int32 parent_id = 17;
     */
    parentId: number;
};
/**
 * Describes the message avn.connect.v1.Organization.
 * Use `create(OrganizationSchema)` to create a new message.
 */
declare const OrganizationSchema: GenMessage<Organization>;
/**
 * Used for creating organizations
 *
 * @generated from message avn.connect.v1.OrganizationSpec
 */
type OrganizationSpec = Message<"avn.connect.v1.OrganizationSpec"> & {
    /**
     * Display name
     *
     * @generated from field: string name = 1;
     */
    name: string;
    /**
     * Postal address
     *
     * @generated from field: string address = 2;
     */
    address: string;
    /**
     * @generated from field: string city = 3;
     */
    city: string;
    /**
     * @generated from field: string state = 4;
     */
    state: string;
    /**
     * @generated from field: string postcode = 5;
     */
    postcode: string;
    /**
     * @generated from field: string country_id = 6;
     */
    countryId: string;
    /**
     * @generated from field: string phone = 7;
     */
    phone: string;
    /**
     * Parent organization ID
     *
     * @generated from field: int32 parent_id = 8;
     */
    parentId: number;
    /**
     * Contact email address
     *
     * @generated from field: optional string email = 9;
     */
    email?: string;
};
/**
 * Describes the message avn.connect.v1.OrganizationSpec.
 * Use `create(OrganizationSpecSchema)` to create a new message.
 */
declare const OrganizationSpecSchema: GenMessage<OrganizationSpec>;
/**
 * @generated from service avn.connect.v1.OrganizationService
 */
declare const OrganizationService: GenService<{
    /**
     * Get an organization from an ID
     *
     * @generated from rpc avn.connect.v1.OrganizationService.GetOrganization
     */
    getOrganization: {
        methodKind: "unary";
        input: typeof GetEntityRequestSchema;
        output: typeof OrganizationSchema;
    };
    /**
     * Users can join organizations using join codes
     *
     * @generated from rpc avn.connect.v1.OrganizationService.JoinOrganization
     */
    joinOrganization: {
        methodKind: "unary";
        input: typeof JoinOrganizationRequestSchema;
        output: typeof JoinOrganizationResponseSchema;
    };
    /**
     * Create a new organization
     *
     * @generated from rpc avn.connect.v1.OrganizationService.CreateOrganization
     */
    createOrganization: {
        methodKind: "unary";
        input: typeof CreateOrganizationRequestSchema;
        output: typeof CreateOrganizationResponseSchema;
    };
    /**
     * Get the requested properties from every requested organization. Supports NAME, ADDRESS, CITY, STATE, POSTCODE, PHONE, EMAIL, PARENT_ID, UPDATED
     *
     * @generated from rpc avn.connect.v1.OrganizationService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetEntityPropertiesRequestSchema;
        output: typeof GetEntityPropertiesResponseSchema;
    };
    /**
     * Set the properties of one or more organizations. Supports NAME, ADDRESS, CITY, STATE, POSTCODE, PHONE, EMAIL, PARENT_ID. Setting PARENT_ID moves the organization within the hierarchy: the caller needs `editOrganizations` on both the organization and the new parent, the new parent must exist, and the move must not create a loop (the new parent cannot be the organization itself or one of its descendants). The root organization cannot be moved
     *
     * @generated from rpc avn.connect.v1.OrganizationService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetEntityPropertiesRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get the users that are members of an organization together with their membership details. Requires the `viewUsers` permission for the organization
     *
     * @generated from rpc avn.connect.v1.OrganizationService.GetOrganizationUsers
     */
    getOrganizationUsers: {
        methodKind: "unary";
        input: typeof GetOrganizationUsersRequestSchema;
        output: typeof GetOrganizationUsersResponseSchema;
    };
    /**
     * Set a member's role and additional permissions within an organization. Replaces the whole membership record, adding the user as a member if necessary. Requires the `editOrganizations` permission for the organization; callers cannot modify their own membership, cannot assign a role above their own inherited role level, and can only grant additional permissions they hold themselves
     *
     * @generated from rpc avn.connect.v1.OrganizationService.SetOrganizationMembership
     */
    setOrganizationMembership: {
        methodKind: "unary";
        input: typeof SetOrganizationMembershipRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Remove a user from an organization. Requires the `editOrganizations` permission for the organization; callers cannot remove themselves
     *
     * @generated from rpc avn.connect.v1.OrganizationService.RemoveOrganizationUser
     */
    removeOrganizationUser: {
        methodKind: "unary";
        input: typeof RemoveOrganizationUserRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * List the direct child organizations of an organization (one level only, not the whole subtree), ordered by name. Requires the `viewSubordinateOrganizations` permission for the parent organization. Walk further down by calling again with a child's ID; walk up via the `parent_id` field of `Organization`
     *
     * @generated from rpc avn.connect.v1.OrganizationService.GetSubordinateOrganizations
     */
    getSubordinateOrganizations: {
        methodKind: "unary";
        input: typeof GetSubordinateOrganizationsRequestSchema;
        output: typeof GetSubordinateOrganizationsResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/passes.proto.
 */
declare const file_avn_connect_v1_passes: GenFile;
/**
 * A pass is a safe way of sharing grants using a unqiue pass ID.
 * Passes are used to create licensed dimensions.
 *
 * @generated from message avn.connect.v1.Pass
 */
type Pass = Message<"avn.connect.v1.Pass"> & {
    /**
     * Unique pass ID (sharing code)
     *
     * @generated from field: string pass_id = 1;
     */
    passId: string;
    /**
     * Maximum user capacity of dimensions
     *
     * @generated from field: int32 capacity = 2;
     */
    capacity: number;
    /**
     * Additional information about this pass
     *
     * @generated from field: string description = 3;
     */
    description: string;
    /**
     * When the pass is valid until
     *
     * @generated from field: optional google.protobuf.Timestamp expires = 4;
     */
    expires?: Timestamp;
    /**
     * Grants associated with this pass
     *
     * @generated from field: repeated avn.connect.v1.GrantInfo grants = 5;
     */
    grants: GrantInfo[];
    /**
     * Content available with this pass
     *
     * @generated from field: avn.connect.v1.AvailableContent content = 6;
     */
    content?: AvailableContent;
};
/**
 * Describes the message avn.connect.v1.Pass.
 * Use `create(PassSchema)` to create a new message.
 */
declare const PassSchema: GenMessage<Pass>;
/**
 * @generated from message avn.connect.v1.CreatePassRequest
 */
type CreatePassRequest = Message<"avn.connect.v1.CreatePassRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: optional avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Which Eduverse cloud domain to use?
     *
     * @generated from field: optional string preferred_domain = 2;
     */
    preferredDomain?: string;
    /**
     * Narrow dimension grant scope to a specific organization
     *
     * @generated from field: optional int32 context_organization_id = 3;
     */
    contextOrganizationId?: number;
};
/**
 * Describes the message avn.connect.v1.CreatePassRequest.
 * Use `create(CreatePassRequestSchema)` to create a new message.
 */
declare const CreatePassRequestSchema: GenMessage<CreatePassRequest>;
/**
 * @generated from message avn.connect.v1.CreatePassResponse
 */
type CreatePassResponse = Message<"avn.connect.v1.CreatePassResponse"> & {
    /**
     * Created pass ID
     *
     * @generated from field: string pass_id = 1;
     */
    passId: string;
};
/**
 * Describes the message avn.connect.v1.CreatePassResponse.
 * Use `create(CreatePassResponseSchema)` to create a new message.
 */
declare const CreatePassResponseSchema: GenMessage<CreatePassResponse>;
/**
 * @generated from message avn.connect.v1.DeletePassRequest
 */
type DeletePassRequest = Message<"avn.connect.v1.DeletePassRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: optional avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Pass to be deleted
     *
     * @generated from field: string pass_id = 2;
     */
    passId: string;
};
/**
 * Describes the message avn.connect.v1.DeletePassRequest.
 * Use `create(DeletePassRequestSchema)` to create a new message.
 */
declare const DeletePassRequestSchema: GenMessage<DeletePassRequest>;
/**
 * @generated from message avn.connect.v1.GetPassRequest
 */
type GetPassRequest = Message<"avn.connect.v1.GetPassRequest"> & {
    /**
     * Pass ID
     *
     * @generated from field: string pass_id = 1;
     */
    passId: string;
};
/**
 * Describes the message avn.connect.v1.GetPassRequest.
 * Use `create(GetPassRequestSchema)` to create a new message.
 */
declare const GetPassRequestSchema: GenMessage<GetPassRequest>;
/**
 * @generated from message avn.connect.v1.GetPassResponse
 */
type GetPassResponse = Message<"avn.connect.v1.GetPassResponse"> & {
    /**
     * Pass information
     *
     * @generated from field: avn.connect.v1.Pass result = 1;
     */
    result?: Pass;
};
/**
 * Describes the message avn.connect.v1.GetPassResponse.
 * Use `create(GetPassResponseSchema)` to create a new message.
 */
declare const GetPassResponseSchema: GenMessage<GetPassResponse>;
/**
 * @generated from message avn.connect.v1.ResolveAssetRequest
 */
type ResolveAssetRequest = Message<"avn.connect.v1.ResolveAssetRequest"> & {
    /**
     * Pass ID
     *
     * @generated from field: string pass_id = 1;
     */
    passId: string;
    /**
     * Activity asset ID
     *
     * @generated from field: string asset_id = 2;
     */
    assetId: string;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 3;
     */
    translate?: TranslationSpec;
    /**
     * Icon transcoding instructions. No icon is returned if this in unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec icon_spec = 4;
     */
    iconSpec?: TranscodeImageSpec;
    /**
     * Preview transcoding instructions. No preview is returned if this is unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec preview_spec = 5;
     */
    previewSpec?: TranscodeImageSpec;
};
/**
 * Describes the message avn.connect.v1.ResolveAssetRequest.
 * Use `create(ResolveAssetRequestSchema)` to create a new message.
 */
declare const ResolveAssetRequestSchema: GenMessage<ResolveAssetRequest>;
/**
 * @generated from service avn.connect.v1.PassService
 */
declare const PassService: GenService<{
    /**
     * Create a new pass
     *
     * @generated from rpc avn.connect.v1.PassService.CreatePass
     */
    createPass: {
        methodKind: "unary";
        input: typeof CreatePassRequestSchema;
        output: typeof CreatePassResponseSchema;
    };
    /**
     * Create a new pass
     *
     * @generated from rpc avn.connect.v1.PassService.DeletePass
     */
    deletePass: {
        methodKind: "unary";
        input: typeof DeletePassRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get information about a specific pass including the licensed channels
     *
     * @generated from rpc avn.connect.v1.PassService.GetPass
     */
    getPass: {
        methodKind: "unary";
        input: typeof GetPassRequestSchema;
        output: typeof GetPassResponseSchema;
    };
    /**
     * Resolve an activity asset ID in the grant context of a pass
     *
     * @generated from rpc avn.connect.v1.PassService.ResolveAsset
     */
    resolveAsset: {
        methodKind: "unary";
        input: typeof ResolveAssetRequestSchema;
        output: typeof EntityInfoSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/permissions.proto.
 */
declare const file_avn_connect_v1_permissions: GenFile;
/**
 * @generated from message avn.connect.v1.Permission
 */
type Permission = Message<"avn.connect.v1.Permission"> & {
    /**
     * Unique ID of the permission
     *
     * @generated from field: string permission_id = 1;
     */
    permissionId: string;
    /**
     * Display name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Scope of the permission
     *
     * @generated from field: avn.connect.v1.PermissionScope scope = 3;
     */
    scope: PermissionScope;
    /**
     * A display-friendly description of the permission
     *
     * @generated from field: string description = 4;
     */
    description: string;
};
/**
 * Describes the message avn.connect.v1.Permission.
 * Use `create(PermissionSchema)` to create a new message.
 */
declare const PermissionSchema: GenMessage<Permission>;
/**
 * @generated from message avn.connect.v1.GetPermissionsRequest
 */
type GetPermissionsRequest = Message<"avn.connect.v1.GetPermissionsRequest"> & {};
/**
 * Describes the message avn.connect.v1.GetPermissionsRequest.
 * Use `create(GetPermissionsRequestSchema)` to create a new message.
 */
declare const GetPermissionsRequestSchema: GenMessage<GetPermissionsRequest>;
/**
 * @generated from message avn.connect.v1.GetPermissionsResponse
 */
type GetPermissionsResponse = Message<"avn.connect.v1.GetPermissionsResponse"> & {
    /**
     * All permissions
     *
     * @generated from field: repeated avn.connect.v1.Permission permissions = 1;
     */
    permissions: Permission[];
};
/**
 * Describes the message avn.connect.v1.GetPermissionsResponse.
 * Use `create(GetPermissionsResponseSchema)` to create a new message.
 */
declare const GetPermissionsResponseSchema: GenMessage<GetPermissionsResponse>;
/**
 * @generated from message avn.connect.v1.IsPermittedRequest
 */
type IsPermittedRequest = Message<"avn.connect.v1.IsPermittedRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The permissions to test
     *
     * @generated from field: string permissions_id = 2;
     */
    permissionsId: string;
    /**
     * The user to test or unset to use the ID of the authorizing user
     *
     * @generated from field: optional int32 user_id = 3;
     */
    userId?: number;
    /**
     * The organization for non-global permissions
     *
     * @generated from field: optional int32 organization_id = 4;
     */
    organizationId?: number;
};
/**
 * Describes the message avn.connect.v1.IsPermittedRequest.
 * Use `create(IsPermittedRequestSchema)` to create a new message.
 */
declare const IsPermittedRequestSchema: GenMessage<IsPermittedRequest>;
/**
 * @generated from message avn.connect.v1.IsPermittedResponse
 */
type IsPermittedResponse = Message<"avn.connect.v1.IsPermittedResponse"> & {
    /**
     * True if the user has the permission
     *
     * @generated from field: bool value = 1;
     */
    value: boolean;
};
/**
 * Describes the message avn.connect.v1.IsPermittedResponse.
 * Use `create(IsPermittedResponseSchema)` to create a new message.
 */
declare const IsPermittedResponseSchema: GenMessage<IsPermittedResponse>;
/**
 * @generated from enum avn.connect.v1.PermissionScope
 */
declare enum PermissionScope {
    /**
     * @generated from enum value: PERMISSION_SCOPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * GLOBAL permissions apply everywhere regardless of organization
     *
     * @generated from enum value: PERMISSION_SCOPE_GLOBAL = 1;
     */
    GLOBAL = 1,
    /**
     * IHERITED permissions flow from parent-to-child, e.g. granting an admin editing rights over subordinate organizations.
     *
     * @generated from enum value: PERMISSION_SCOPE_INHERITED = 2;
     */
    INHERITED = 2,
    /**
     * BRANCH permissions also flow from parent-to-child and child-to-parent, e.g. granting an organization member permission to view the name of the organization's parent.
     *
     * @generated from enum value: PERMISSION_SCOPE_BRANCH = 3;
     */
    BRANCH = 3
}
/**
 * Describes the enum avn.connect.v1.PermissionScope.
 */
declare const PermissionScopeSchema: GenEnum<PermissionScope>;
/**
 * @generated from service avn.connect.v1.PermissionService
 */
declare const PermissionService: GenService<{
    /**
     * Get all permissions
     *
     * @generated from rpc avn.connect.v1.PermissionService.GetPermissions
     */
    getPermissions: {
        methodKind: "unary";
        input: typeof GetPermissionsRequestSchema;
        output: typeof GetPermissionsResponseSchema;
    };
    /**
     * Does a user have a specific permission for a specific organization?
     *
     * @generated from rpc avn.connect.v1.PermissionService.IsPermitted
     */
    isPermitted: {
        methodKind: "unary";
        input: typeof IsPermittedRequestSchema;
        output: typeof IsPermittedResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/profiles.proto.
 */
declare const file_avn_connect_v1_profiles: GenFile;
/**
 * @generated from message avn.connect.v1.Profile
 */
type Profile = Message<"avn.connect.v1.Profile"> & {
    /**
     * Unique profile ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Profile name stored in plain text format
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Icon URL for the profile. Accepted media types: image/png, image/jpeg, image/svg+xml
     *
     * @generated from field: string icon_url = 3;
     */
    iconUrl: string;
    /**
     * Preview image URL for the profile. Accepted media types: image/png, image/jpeg, image/svg+xml
     *
     * @generated from field: string preview_url = 4;
     */
    previewUrl: string;
    /**
     * When profile last updated
     *
     * @generated from field: google.protobuf.Timestamp updated = 5;
     */
    updated?: Timestamp;
    /**
     * Profile summary stored in markdown format
     *
     * @generated from field: optional string summary = 22;
     */
    summary?: string;
    /**
     * Profile description stored in markdown format
     *
     * @generated from field: optional string description = 6;
     */
    description?: string;
    /**
     * Profile instructions stored in markdown format
     *
     * @generated from field: optional string instructions = 7;
     */
    instructions?: string;
    /**
     * Profile keywords
     *
     * @generated from field: optional string keywords = 21;
     */
    keywords?: string;
    /**
     * Content language
     *
     * @generated from field: string language_id = 8;
     */
    languageId: string;
    /**
     * Content tags
     *
     * @generated from field: repeated int32 tags = 9;
     */
    tags: number[];
    /**
     * When profile was published or unset if not published
     *
     * @generated from field: optional google.protobuf.Timestamp published = 10;
     */
    published?: Timestamp;
    /**
     * When profile was featured or unset if not featured
     *
     * @generated from field: optional google.protobuf.Timestamp featured = 11;
     */
    featured?: Timestamp;
    /**
     * Profile file owner
     *
     * @generated from oneof avn.connect.v1.Profile.owner
     */
    owner: {
        /**
         * Organization owner (if not zero)
         *
         * @generated from field: int32 organization_id = 12;
         */
        value: number;
        case: "organizationId";
    } | {
        /**
         * User owner (if not zero)
         *
         * @generated from field: int32 user_id = 13;
         */
        value: number;
        case: "userId";
    } | {
        case: undefined;
        value?: undefined;
    };
    /**
     * Has this profile been deleted?
     *
     * @generated from field: bool deleted = 14;
     */
    deleted: boolean;
    /**
     * Number of categories in this profile
     *
     * @generated from field: int32 item_count = 15;
     */
    itemCount: number;
    /**
     * Is the profile licensed?
     *
     * @generated from field: bool licensed = 23;
     */
    licensed: boolean;
    /**
     * Is the profile permitted?
     *
     * @generated from field: bool permitted = 24;
     */
    permitted: boolean;
    /**
     * Is the profile available to use?
     *
     * @generated from field: bool available = 25;
     */
    available: boolean;
};
/**
 * Describes the message avn.connect.v1.Profile.
 * Use `create(ProfileSchema)` to create a new message.
 */
declare const ProfileSchema: GenMessage<Profile>;
/**
 * @generated from service avn.connect.v1.ProfileService
 */
declare const ProfileService: GenService<{
    /**
     * Get a profile from an ID
     *
     * @generated from rpc avn.connect.v1.ProfileService.GetProfile
     */
    getProfile: {
        methodKind: "unary";
        input: typeof GetEntityRequestSchema;
        output: typeof ProfileSchema;
    };
    /**
     * Create a profile for an organization or user
     *
     * @generated from rpc avn.connect.v1.ProfileService.CreateProfile
     */
    createProfile: {
        methodKind: "unary";
        input: typeof CreateEntityRequestSchema;
        output: typeof CreateEntityResponseSchema;
    };
    /**
     * Delete a profile
     *
     * @generated from rpc avn.connect.v1.ProfileService.DeleteProfile
     */
    deleteProfile: {
        methodKind: "unary";
        input: typeof DeleteEntityRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get a page of published categories in the given profile (paged via page_size/page_token; follow next_page_token for the rest)
     *
     * @generated from rpc avn.connect.v1.ProfileService.GetCategories
     */
    getCategories: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Get a page of published activities in the given profile (paged via page_size/page_token; follow next_page_token for the rest)
     *
     * @generated from rpc avn.connect.v1.ProfileService.GetActivities
     */
    getActivities: {
        methodKind: "unary";
        input: typeof EntityInfoListRequestSchema;
        output: typeof EntityInfoListResponseSchema;
    };
    /**
     * Add categories to a profile. child_ids are appended by default, or become the profile's exact membership when replace_all is set. The order of child_ids is persisted as the categories' sort order.
     *
     * @generated from rpc avn.connect.v1.ProfileService.AddCategories
     */
    addCategories: {
        methodKind: "unary";
        input: typeof AddChildrenRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Remove a category from a profile
     *
     * @generated from rpc avn.connect.v1.ProfileService.RemoveCategories
     */
    removeCategories: {
        methodKind: "unary";
        input: typeof RemoveChildrenRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Add tags to a profile
     *
     * @generated from rpc avn.connect.v1.ProfileService.AddTags
     */
    addTags: {
        methodKind: "unary";
        input: typeof AddTagsRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Remove tags from a profile
     *
     * @generated from rpc avn.connect.v1.ProfileService.RemoveTags
     */
    removeTags: {
        methodKind: "unary";
        input: typeof RemoveTagsRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get the properties of one or more profiles. Supports NAME, SUMMARY, DESCRIPTION, INSTRUCTIONS, KEYWORDS, LANGUAGE_ID, UPDATED, LICENSED, PERMITTED, ICON_URL, PREVIEW_URL, WALLPAPER_URL, PUBLISHED, FEATURED, ITEM_COUNT, ORGANIZATION_ID
     *
     * @generated from rpc avn.connect.v1.ProfileService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetEntityPropertiesRequestSchema;
        output: typeof GetEntityPropertiesResponseSchema;
    };
    /**
     * Set the properties of a profile. Supports NAME, SUMMARY, DESCRIPTION, INSTRUCTIONS, KEYWORDS, ICON_URL, WALLPAPER_URL, PUBLISHED, LANGUAGE_ID, ORGANIZATION_ID
     *
     * @generated from rpc avn.connect.v1.ProfileService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetEntityPropertiesRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/roles.proto.
 */
declare const file_avn_connect_v1_roles: GenFile;
/**
 * @generated from message avn.connect.v1.Role
 */
type Role = Message<"avn.connect.v1.Role"> & {
    /**
     * Unique role ID
     *
     * @generated from field: int32 role_id = 1;
     */
    roleId: number;
    /**
     * Role display name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Role security level (higher values have more permissions)
     *
     * @generated from field: int32 level = 3;
     */
    level: number;
    /**
     * Permission IDs associated with this role
     *
     * @generated from field: repeated string permission_ids = 4;
     */
    permissionIds: string[];
};
/**
 * Describes the message avn.connect.v1.Role.
 * Use `create(RoleSchema)` to create a new message.
 */
declare const RoleSchema: GenMessage<Role>;
/**
 * @generated from message avn.connect.v1.GetRolesRequest
 */
type GetRolesRequest = Message<"avn.connect.v1.GetRolesRequest"> & {};
/**
 * Describes the message avn.connect.v1.GetRolesRequest.
 * Use `create(GetRolesRequestSchema)` to create a new message.
 */
declare const GetRolesRequestSchema: GenMessage<GetRolesRequest>;
/**
 * @generated from message avn.connect.v1.GetRolesResponse
 */
type GetRolesResponse = Message<"avn.connect.v1.GetRolesResponse"> & {
    /**
     * All roles
     *
     * @generated from field: repeated avn.connect.v1.Role roles = 1;
     */
    roles: Role[];
};
/**
 * Describes the message avn.connect.v1.GetRolesResponse.
 * Use `create(GetRolesResponseSchema)` to create a new message.
 */
declare const GetRolesResponseSchema: GenMessage<GetRolesResponse>;
/**
 * @generated from service avn.connect.v1.RoleService
 */
declare const RoleService: GenService<{
    /**
     * Get all user-organization roles
     *
     * @generated from rpc avn.connect.v1.RoleService.GetRoles
     */
    getRoles: {
        methodKind: "unary";
        input: typeof GetRolesRequestSchema;
        output: typeof GetRolesResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/rooms.proto.
 */
declare const file_avn_connect_v1_rooms: GenFile;
/**
 * @generated from message avn.connect.v1.RoomInfo
 */
type RoomInfo = Message<"avn.connect.v1.RoomInfo"> & {
    /**
     * @generated from field: string domain = 1;
     */
    domain: string;
    /**
     * @generated from field: string dimension_id = 2;
     */
    dimensionId: string;
    /**
     * @generated from field: string room_id = 3;
     */
    roomId: string;
    /**
     * @generated from field: string name = 4;
     */
    name: string;
    /**
     * Icon to use for the room
     *
     * @generated from field: string icon_url = 5;
     */
    iconUrl: string;
    /**
     * @generated from field: string screenshot_url = 6;
     */
    screenshotUrl: string;
    /**
     * @generated from field: string asset_id = 7;
     */
    assetId: string;
    /**
     * @generated from field: int32 activity_id = 8;
     */
    activityId: number;
    /**
     * When the room was created
     *
     * @generated from field: google.protobuf.Timestamp created = 9;
     */
    created?: Timestamp;
    /**
     * Additional parameters that define the room
     *
     * @generated from field: map<string, string> asset_parameters = 10;
     */
    assetParameters: {
        [key: string]: string;
    };
};
/**
 * Describes the message avn.connect.v1.RoomInfo.
 * Use `create(RoomInfoSchema)` to create a new message.
 */
declare const RoomInfoSchema: GenMessage<RoomInfo>;
/**
 * @generated from message avn.connect.v1.GetRoomRequest
 */
type GetRoomRequest = Message<"avn.connect.v1.GetRoomRequest"> & {
    /**
     * @generated from field: string room_id = 1;
     */
    roomId: string;
};
/**
 * Describes the message avn.connect.v1.GetRoomRequest.
 * Use `create(GetRoomRequestSchema)` to create a new message.
 */
declare const GetRoomRequestSchema: GenMessage<GetRoomRequest>;
/**
 * @generated from message avn.connect.v1.GetRoomResponse
 */
type GetRoomResponse = Message<"avn.connect.v1.GetRoomResponse"> & {
    /**
     * @generated from field: avn.connect.v1.RoomInfo room_info = 1;
     */
    roomInfo?: RoomInfo;
};
/**
 * Describes the message avn.connect.v1.GetRoomResponse.
 * Use `create(GetRoomResponseSchema)` to create a new message.
 */
declare const GetRoomResponseSchema: GenMessage<GetRoomResponse>;
/**
 * @generated from message avn.connect.v1.OpenRoomRequest
 */
type OpenRoomRequest = Message<"avn.connect.v1.OpenRoomRequest"> & {
    /**
     * @generated from field: string dimension_id = 1;
     */
    dimensionId: string;
    /**
     * @generated from field: string url = 2;
     */
    url: string;
};
/**
 * Describes the message avn.connect.v1.OpenRoomRequest.
 * Use `create(OpenRoomRequestSchema)` to create a new message.
 */
declare const OpenRoomRequestSchema: GenMessage<OpenRoomRequest>;
/**
 * @generated from message avn.connect.v1.OpenRoomResponse
 */
type OpenRoomResponse = Message<"avn.connect.v1.OpenRoomResponse"> & {
    /**
     * @generated from field: avn.connect.v1.RoomInfo room_info = 1;
     */
    roomInfo?: RoomInfo;
};
/**
 * Describes the message avn.connect.v1.OpenRoomResponse.
 * Use `create(OpenRoomResponseSchema)` to create a new message.
 */
declare const OpenRoomResponseSchema: GenMessage<OpenRoomResponse>;
/**
 * @generated from message avn.connect.v1.EnterRoomRequest
 */
type EnterRoomRequest = Message<"avn.connect.v1.EnterRoomRequest"> & {
    /**
     * @generated from field: avn.connect.v1.ConnectionCredentials credentials = 1;
     */
    credentials?: ConnectionCredentials;
    /**
     * @generated from field: string room_id = 2;
     */
    roomId: string;
    /**
     * @generated from field: string session_id = 3;
     */
    sessionId: string;
};
/**
 * Describes the message avn.connect.v1.EnterRoomRequest.
 * Use `create(EnterRoomRequestSchema)` to create a new message.
 */
declare const EnterRoomRequestSchema: GenMessage<EnterRoomRequest>;
/**
 * @generated from message avn.connect.v1.EnterRoomResponse
 */
type EnterRoomResponse = Message<"avn.connect.v1.EnterRoomResponse"> & {
    /**
     * @generated from field: avn.connect.v1.RoomInfo room_info = 1;
     */
    roomInfo?: RoomInfo;
};
/**
 * Describes the message avn.connect.v1.EnterRoomResponse.
 * Use `create(EnterRoomResponseSchema)` to create a new message.
 */
declare const EnterRoomResponseSchema: GenMessage<EnterRoomResponse>;
/**
 * @generated from message avn.connect.v1.ResolveMediaRequest
 */
type ResolveMediaRequest = Message<"avn.connect.v1.ResolveMediaRequest"> & {
    /**
     * @generated from field: string dimension_id = 1;
     */
    dimensionId: string;
    /**
     * @generated from field: string asset_id = 2;
     */
    assetId: string;
};
/**
 * Describes the message avn.connect.v1.ResolveMediaRequest.
 * Use `create(ResolveMediaRequestSchema)` to create a new message.
 */
declare const ResolveMediaRequestSchema: GenMessage<ResolveMediaRequest>;
/**
 * @generated from message avn.connect.v1.ResolveMediaResponse
 */
type ResolveMediaResponse = Message<"avn.connect.v1.ResolveMediaResponse"> & {
    /**
     * @generated from field: string asset_url = 1;
     */
    assetUrl: string;
    /**
     * @generated from field: string thumbnail_url = 2;
     */
    thumbnailUrl: string;
    /**
     * @generated from field: string mime_type = 3;
     */
    mimeType: string;
    /**
     * @generated from field: repeated int32 tag_ids = 4;
     */
    tagIds: number[];
};
/**
 * Describes the message avn.connect.v1.ResolveMediaResponse.
 * Use `create(ResolveMediaResponseSchema)` to create a new message.
 */
declare const ResolveMediaResponseSchema: GenMessage<ResolveMediaResponse>;
/**
 * @generated from service avn.connect.v1.RoomService
 */
declare const RoomService: GenService<{
    /**
     * Lookup a room by ID
     *
     * @generated from rpc avn.connect.v1.RoomService.GetRoom
     */
    getRoom: {
        methodKind: "unary";
        input: typeof GetRoomRequestSchema;
        output: typeof GetRoomResponseSchema;
    };
    /**
     * Open a room for a given dimension-URL combination (may return an existing room)
     *
     * @generated from rpc avn.connect.v1.RoomService.OpenRoom
     */
    openRoom: {
        methodKind: "unary";
        input: typeof OpenRoomRequestSchema;
        output: typeof OpenRoomResponseSchema;
    };
    /**
     * Record entry to a room
     *
     * @generated from rpc avn.connect.v1.RoomService.EnterRoom
     */
    enterRoom: {
        methodKind: "unary";
        input: typeof EnterRoomRequestSchema;
        output: typeof EnterRoomResponseSchema;
    };
    /**
     * Legacy function for hubs media resolution
     *
     * @generated from rpc avn.connect.v1.RoomService.ResolveMedia
     */
    resolveMedia: {
        methodKind: "unary";
        input: typeof ResolveMediaRequestSchema;
        output: typeof ResolveMediaResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/speech.proto.
 */
declare const file_avn_connect_v1_speech: GenFile;
/**
 * @generated from message avn.connect.v1.SynthesizeSpeechRequest
 */
type SynthesizeSpeechRequest = Message<"avn.connect.v1.SynthesizeSpeechRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The text to synthesize
     *
     * @generated from field: string text = 2;
     */
    text: string;
    /**
     * Speaker ID for voice selection (varies voice within same gender/language)
     *
     * @generated from field: int32 speaker_id = 6;
     */
    speakerId: number;
    /**
     * IETF BCP 47 language tag for the speaker
     *
     * @generated from field: string language_id = 3;
     */
    languageId: string;
    /**
     * Gender of the speaker
     *
     * @generated from field: avn.connect.v1.SpeakerGender gender = 4;
     */
    gender: SpeakerGender;
    /**
     * Additional speech flags
     *
     * @generated from field: repeated avn.connect.v1.SpeechFlag speech_flags = 5;
     */
    speechFlags: SpeechFlag[];
    /**
     * Output file spec (OPUS is the default)
     *
     * @generated from field: optional avn.connect.v1.SpeechFileSpec output_spec = 7;
     */
    outputSpec?: SpeechFileSpec;
};
/**
 * Describes the message avn.connect.v1.SynthesizeSpeechRequest.
 * Use `create(SynthesizeSpeechRequestSchema)` to create a new message.
 */
declare const SynthesizeSpeechRequestSchema: GenMessage<SynthesizeSpeechRequest>;
/**
 * @generated from message avn.connect.v1.SynthesizeSpeechResponse
 */
type SynthesizeSpeechResponse = Message<"avn.connect.v1.SynthesizeSpeechResponse"> & {
    /**
     * URL of the synthesized audio file
     *
     * @generated from field: string audio_url = 1;
     */
    audioUrl: string;
    /**
     * `SpeechMarks` binary file AVNFS URL. Only guarenteed to be returned if SPEECH_FLAG_REQUIRE_SPEECH_MARKS is in the request.
     *
     * @generated from field: optional string speech_marks_url = 5;
     */
    speechMarksUrl?: string;
    /**
     * Duration of the audio in seconds
     *
     * @generated from field: float duration_seconds = 2;
     */
    durationSeconds: number;
    /**
     * Populated if there were synth errors
     *
     * @generated from field: repeated string errors = 3;
     */
    errors: string[];
    /**
     * Populated if there were synth warnings
     *
     * @generated from field: repeated string warnings = 4;
     */
    warnings: string[];
};
/**
 * Describes the message avn.connect.v1.SynthesizeSpeechResponse.
 * Use `create(SynthesizeSpeechResponseSchema)` to create a new message.
 */
declare const SynthesizeSpeechResponseSchema: GenMessage<SynthesizeSpeechResponse>;
/**
 * @generated from message avn.connect.v1.SynthesizeTranscriptRequest
 */
type SynthesizeTranscriptRequest = Message<"avn.connect.v1.SynthesizeTranscriptRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The transcript to synthesize
     *
     * @generated from field: string transcript_url = 2;
     */
    transcriptUrl: string;
    /**
     * Output file spec (OPUS is the default)
     *
     * @generated from field: optional avn.connect.v1.SpeechFileSpec output_spec = 3;
     */
    outputSpec?: SpeechFileSpec;
};
/**
 * Describes the message avn.connect.v1.SynthesizeTranscriptRequest.
 * Use `create(SynthesizeTranscriptRequestSchema)` to create a new message.
 */
declare const SynthesizeTranscriptRequestSchema: GenMessage<SynthesizeTranscriptRequest>;
/**
 * @generated from message avn.connect.v1.SynthesizeTranscriptResponse
 */
type SynthesizeTranscriptResponse = Message<"avn.connect.v1.SynthesizeTranscriptResponse"> & {
    /**
     * `Speech` message response (binary AVNFS file)
     *
     * @generated from field: string speech_url = 1;
     */
    speechUrl: string;
    /**
     * Populated if there were synth errors
     *
     * @generated from field: repeated string errors = 2;
     */
    errors: string[];
    /**
     * Populated if there were synth warnings
     *
     * @generated from field: repeated string warnings = 3;
     */
    warnings: string[];
};
/**
 * Describes the message avn.connect.v1.SynthesizeTranscriptResponse.
 * Use `create(SynthesizeTranscriptResponseSchema)` to create a new message.
 */
declare const SynthesizeTranscriptResponseSchema: GenMessage<SynthesizeTranscriptResponse>;
/**
 * @generated from message avn.connect.v1.PronunciationAnalysisRequest
 */
type PronunciationAnalysisRequest = Message<"avn.connect.v1.PronunciationAnalysisRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * IETF BCP 47 language tag
     *
     * @generated from field: string language_id = 2;
     */
    languageId: string;
    /**
     * AVNFS URL of speech audio to analyze (synthesized from text if absent)
     *
     * @generated from field: optional string speech_url = 3;
     */
    speechUrl?: string;
    /**
     * Reference text (transcribed from audio file if absent)
     *
     * @generated from field: optional string text = 4;
     */
    text?: string;
};
/**
 * Describes the message avn.connect.v1.PronunciationAnalysisRequest.
 * Use `create(PronunciationAnalysisRequestSchema)` to create a new message.
 */
declare const PronunciationAnalysisRequestSchema: GenMessage<PronunciationAnalysisRequest>;
/**
 * @generated from message avn.connect.v1.PronunciationAnalysisResponse
 */
type PronunciationAnalysisResponse = Message<"avn.connect.v1.PronunciationAnalysisResponse"> & {
    /**
     * IPA symbols space-separated by word
     *
     * @generated from field: string phonemes = 1;
     */
    phonemes: string;
    /**
     * Timings for phonemes
     *
     * @generated from field: repeated avn.connect.v1.PhonemeDetail phoneme_details = 2;
     */
    phonemeDetails: PhonemeDetail[];
    /**
     * AVNFS URL of the sample audio used for analysis
     *
     * @generated from field: string sample_url = 3;
     */
    sampleUrl: string;
};
/**
 * Describes the message avn.connect.v1.PronunciationAnalysisResponse.
 * Use `create(PronunciationAnalysisResponseSchema)` to create a new message.
 */
declare const PronunciationAnalysisResponseSchema: GenMessage<PronunciationAnalysisResponse>;
/**
 * @generated from message avn.connect.v1.PhonemeDetail
 */
type PhonemeDetail = Message<"avn.connect.v1.PhonemeDetail"> & {
    /**
     * Phoneme or space for word gaps
     *
     * @generated from field: string phoneme = 1;
     */
    phoneme: string;
    /**
     * Start time in seconds
     *
     * @generated from field: float start = 4;
     */
    start: number;
    /**
     * End time in seconds
     *
     * @generated from field: float end = 5;
     */
    end: number;
};
/**
 * Describes the message avn.connect.v1.PhonemeDetail.
 * Use `create(PhonemeDetailSchema)` to create a new message.
 */
declare const PhonemeDetailSchema: GenMessage<PhonemeDetail>;
/**
 * @generated from message avn.connect.v1.Speech
 */
type Speech = Message<"avn.connect.v1.Speech"> & {
    /**
     * Audio segments of the speech
     *
     * @generated from field: repeated avn.connect.v1.SpeechSegment segments = 1;
     */
    segments: SpeechSegment[];
};
/**
 * Describes the message avn.connect.v1.Speech.
 * Use `create(SpeechSchema)` to create a new message.
 */
declare const SpeechSchema: GenMessage<Speech>;
/**
 * @generated from message avn.connect.v1.SpeechSegment
 */
type SpeechSegment = Message<"avn.connect.v1.SpeechSegment"> & {
    /**
     * Audio clip AVNFS URL
     *
     * @generated from field: string audio_url = 1;
     */
    audioUrl: string;
    /**
     * `SpeechMarks` binary file AVNFS URL. Only guarenteed to be returned if SPEECH_FLAG_REQUIRE_SPEECH_MARKS is in the request.
     *
     * @generated from field: string speech_marks_url = 3;
     */
    speechMarksUrl: string;
    /**
     * Length of the audio clip
     *
     * @generated from field: float duration_seconds = 2;
     */
    durationSeconds: number;
};
/**
 * Describes the message avn.connect.v1.SpeechSegment.
 * Use `create(SpeechSegmentSchema)` to create a new message.
 */
declare const SpeechSegmentSchema: GenMessage<SpeechSegment>;
/**
 * @generated from message avn.connect.v1.Speaker
 */
type Speaker = Message<"avn.connect.v1.Speaker"> & {
    /**
     * Unique ID of speaker within speech
     *
     * @generated from field: int32 speaker_id = 1;
     */
    speakerId: number;
    /**
     * Speaker voice gender
     *
     * @generated from field: avn.connect.v1.SpeakerGender gender = 2;
     */
    gender: SpeakerGender;
    /**
     * Speaker name (display only)
     *
     * @generated from field: optional string name = 3;
     */
    name?: string;
    /**
     * Modifiers for speech generation
     *
     * @generated from field: repeated avn.connect.v1.SpeechFlag speech_flags = 4;
     */
    speechFlags: SpeechFlag[];
};
/**
 * Describes the message avn.connect.v1.Speaker.
 * Use `create(SpeakerSchema)` to create a new message.
 */
declare const SpeakerSchema: GenMessage<Speaker>;
/**
 * @generated from message avn.connect.v1.SpeechMarks
 */
type SpeechMarks = Message<"avn.connect.v1.SpeechMarks"> & {
    /**
     * @generated from field: repeated avn.connect.v1.SpeechMark marks = 1;
     */
    marks: SpeechMark[];
};
/**
 * Describes the message avn.connect.v1.SpeechMarks.
 * Use `create(SpeechMarksSchema)` to create a new message.
 */
declare const SpeechMarksSchema: GenMessage<SpeechMarks>;
/**
 * @generated from message avn.connect.v1.SpeechMark
 */
type SpeechMark = Message<"avn.connect.v1.SpeechMark"> & {
    /**
     * @generated from field: avn.connect.v1.SpeechMarkType type = 1;
     */
    type: SpeechMarkType;
    /**
     * @generated from field: float time_seconds = 2;
     */
    timeSeconds: number;
    /**
     * @generated from field: int32 start_bytes = 3;
     */
    startBytes: number;
    /**
     * @generated from field: int32 end_bytes = 4;
     */
    endBytes: number;
    /**
     * @generated from field: string value = 5;
     */
    value: string;
};
/**
 * Describes the message avn.connect.v1.SpeechMark.
 * Use `create(SpeechMarkSchema)` to create a new message.
 */
declare const SpeechMarkSchema: GenMessage<SpeechMark>;
/**
 * @generated from message avn.connect.v1.GetCapabilitiesRequest
 */
type GetCapabilitiesRequest = Message<"avn.connect.v1.GetCapabilitiesRequest"> & {};
/**
 * Describes the message avn.connect.v1.GetCapabilitiesRequest.
 * Use `create(GetCapabilitiesRequestSchema)` to create a new message.
 */
declare const GetCapabilitiesRequestSchema: GenMessage<GetCapabilitiesRequest>;
/**
 * @generated from message avn.connect.v1.GetCapabilitiesResponse
 */
type GetCapabilitiesResponse = Message<"avn.connect.v1.GetCapabilitiesResponse"> & {
    /**
     * Languages supported for TTS
     *
     * @generated from field: repeated string supported_language_ids = 1;
     */
    supportedLanguageIds: string[];
};
/**
 * Describes the message avn.connect.v1.GetCapabilitiesResponse.
 * Use `create(GetCapabilitiesResponseSchema)` to create a new message.
 */
declare const GetCapabilitiesResponseSchema: GenMessage<GetCapabilitiesResponse>;
/**
 * @generated from message avn.connect.v1.SpeechFileSpec
 */
type SpeechFileSpec = Message<"avn.connect.v1.SpeechFileSpec"> & {
    /**
     * @generated from field: avn.connect.v1.SpeechFileFormat format = 1;
     */
    format: SpeechFileFormat;
};
/**
 * Describes the message avn.connect.v1.SpeechFileSpec.
 * Use `create(SpeechFileSpecSchema)` to create a new message.
 */
declare const SpeechFileSpecSchema: GenMessage<SpeechFileSpec>;
/**
 * @generated from enum avn.connect.v1.SpeechMarkType
 */
declare enum SpeechMarkType {
    /**
     * @generated from enum value: SPEECH_MARK_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: SPEECH_MARK_TYPE_SENTENCE = 1;
     */
    SENTENCE = 1,
    /**
     * @generated from enum value: SPEECH_MARK_TYPE_WORD = 2;
     */
    WORD = 2,
    /**
     * @generated from enum value: SPEECH_MARK_TYPE_VISME = 3;
     */
    VISME = 3
}
/**
 * Describes the enum avn.connect.v1.SpeechMarkType.
 */
declare const SpeechMarkTypeSchema: GenEnum<SpeechMarkType>;
/**
 * @generated from enum avn.connect.v1.SpeechFileFormat
 */
declare enum SpeechFileFormat {
    /**
     * @generated from enum value: SPEECH_FILE_FORMAT_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * OPUS audio (preferred option)
     *
     * @generated from enum value: SPEECH_FILE_FORMAT_OGG_OPUS = 1;
     */
    OGG_OPUS = 1,
    /**
     * MP3 audio
     *
     * @generated from enum value: SPEECH_FILE_FORMAT_MP3 = 2;
     */
    MP3 = 2
}
/**
 * Describes the enum avn.connect.v1.SpeechFileFormat.
 */
declare const SpeechFileFormatSchema: GenEnum<SpeechFileFormat>;
/**
 * @generated from enum avn.connect.v1.SpeakerGender
 */
declare enum SpeakerGender {
    /**
     * @generated from enum value: SPEAKER_GENDER_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: SPEAKER_GENDER_NEUTRAL = 1;
     */
    NEUTRAL = 1,
    /**
     * @generated from enum value: SPEAKER_GENDER_MALE = 2;
     */
    MALE = 2,
    /**
     * @generated from enum value: SPEAKER_GENDER_FEMALE = 3;
     */
    FEMALE = 3
}
/**
 * Describes the enum avn.connect.v1.SpeakerGender.
 */
declare const SpeakerGenderSchema: GenEnum<SpeakerGender>;
/**
 * @generated from enum avn.connect.v1.SpeechFlag
 */
declare enum SpeechFlag {
    /**
     * @generated from enum value: SPEECH_FLAG_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Don't translate this speaker or segment
     *
     * @generated from enum value: SPEECH_FLAG_NO_TRANSLATION = 1;
     */
    NO_TRANSLATION = 1,
    /**
     * Speech of a child
     *
     * @generated from enum value: SPEECH_FLAG_CHILD = 2;
     */
    CHILD = 2,
    /**
     * Speech input is in IPA phonemes
     *
     * @generated from enum value: SPEECH_FLAG_PHONEME = 3;
     */
    PHONEME = 3,
    /**
     * Force the output of `SpeechMarks` even it means using a simpler speech model
     *
     * @generated from enum value: SPEECH_FLAG_REQUIRE_SPEECH_MARKS = 4;
     */
    REQUIRE_SPEECH_MARKS = 4
}
/**
 * Describes the enum avn.connect.v1.SpeechFlag.
 */
declare const SpeechFlagSchema: GenEnum<SpeechFlag>;
/**
 * @generated from service avn.connect.v1.SpeechService
 */
declare const SpeechService: GenService<{
    /**
     * Capabilities of the speech engine
     *
     * @generated from rpc avn.connect.v1.SpeechService.GetCapabilities
     */
    getCapabilities: {
        methodKind: "unary";
        input: typeof GetCapabilitiesRequestSchema;
        output: typeof GetCapabilitiesResponseSchema;
    };
    /**
     * Synthesize speech from a text string
     *
     * @generated from rpc avn.connect.v1.SpeechService.SynthesizeSpeech
     */
    synthesizeSpeech: {
        methodKind: "unary";
        input: typeof SynthesizeSpeechRequestSchema;
        output: typeof SynthesizeSpeechResponseSchema;
    };
    /**
     * Synthesize speech to match a Transcript
     *
     * @generated from rpc avn.connect.v1.SpeechService.SynthesizeTranscript
     */
    synthesizeTranscript: {
        methodKind: "unary";
        input: typeof SynthesizeTranscriptRequestSchema;
        output: typeof SynthesizeTranscriptResponseSchema;
    };
    /**
     * Analyze pronunciation: extract phonemes from audio and/or text
     *
     * @generated from rpc avn.connect.v1.SpeechService.PronunciationAnalysis
     */
    pronunciationAnalysis: {
        methodKind: "unary";
        input: typeof PronunciationAnalysisRequestSchema;
        output: typeof PronunciationAnalysisResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/three_sixty_cities.proto.
 */
declare const file_avn_connect_v1_three_sixty_cities: GenFile;
/**
 * @generated from message avn.connect.v1.SearchImagesRequest
 */
type SearchImagesRequest = Message<"avn.connect.v1.SearchImagesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: string search_text = 2;
     */
    searchText: string;
    /**
     * @generated from field: optional int32 page_size = 3;
     */
    pageSize?: number;
    /**
     * @generated from field: optional string page_token = 4;
     */
    pageToken?: string;
    /**
     * Translation instructions. The original text is returned if this is unset.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 5;
     */
    translate?: TranslationSpec;
    /**
     * Icon transcoding instructions. No icon is returned if this in unset.
     *
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec icon_spec = 6;
     */
    iconSpec?: TranscodeImageSpec;
    /**
     * @generated from field: optional avn.connect.v1.TranscodeImageSpec preview_spec = 7;
     */
    previewSpec?: TranscodeImageSpec;
};
/**
 * Describes the message avn.connect.v1.SearchImagesRequest.
 * Use `create(SearchImagesRequestSchema)` to create a new message.
 */
declare const SearchImagesRequestSchema: GenMessage<SearchImagesRequest>;
/**
 * @generated from message avn.connect.v1.SearchImagesResponse
 */
type SearchImagesResponse = Message<"avn.connect.v1.SearchImagesResponse"> & {
    /**
     * @generated from field: repeated avn.connect.v1.EntityInfo results = 1;
     */
    results: EntityInfo[];
    /**
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.SearchImagesResponse.
 * Use `create(SearchImagesResponseSchema)` to create a new message.
 */
declare const SearchImagesResponseSchema: GenMessage<SearchImagesResponse>;
/**
 * @generated from service avn.connect.v1.ThreeSixtyCitiesService
 */
declare const ThreeSixtyCitiesService: GenService<{
    /**
     * @generated from rpc avn.connect.v1.ThreeSixtyCitiesService.SearchImages
     */
    searchImages: {
        methodKind: "unary";
        input: typeof SearchImagesRequestSchema;
        output: typeof SearchImagesResponseSchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/transcriptions.proto.
 */
declare const file_avn_connect_v1_transcriptions: GenFile;
/**
 * @generated from message avn.connect.v1.GetMediaTranscriptRequest
 */
type GetMediaTranscriptRequest = Message<"avn.connect.v1.GetMediaTranscriptRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The media file to transcribe
     *
     * @generated from field: string media_url = 2;
     */
    mediaUrl: string;
    /**
     * Optional on-demand translation. Set language_id to a target BCP 47 language to
     * translate every segment of the transcript into it; leave unset to return the
     * transcript unchanged (which may itself contain more than one language).
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 3;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetMediaTranscriptRequest.
 * Use `create(GetMediaTranscriptRequestSchema)` to create a new message.
 */
declare const GetMediaTranscriptRequestSchema: GenMessage<GetMediaTranscriptRequest>;
/**
 * @generated from message avn.connect.v1.GetActivityTranscriptRequest
 */
type GetActivityTranscriptRequest = Message<"avn.connect.v1.GetActivityTranscriptRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The target activity
     *
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
    /**
     * Optional on-demand translation. Set language_id to a target BCP 47 language to
     * translate every segment of the transcript into it; leave unset to return the
     * original. A transcript's language(s) are per-segment and independent of the
     * activity's own language_id.
     *
     * @generated from field: avn.connect.v1.TranslationSpec translate = 3;
     */
    translate?: TranslationSpec;
};
/**
 * Describes the message avn.connect.v1.GetActivityTranscriptRequest.
 * Use `create(GetActivityTranscriptRequestSchema)` to create a new message.
 */
declare const GetActivityTranscriptRequestSchema: GenMessage<GetActivityTranscriptRequest>;
/**
 * @generated from message avn.connect.v1.SetActivityTranscriptRequest
 */
type SetActivityTranscriptRequest = Message<"avn.connect.v1.SetActivityTranscriptRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * The target activity
     *
     * @generated from field: int32 entity_id = 2;
     */
    entityId: number;
    /**
     * The AVNFS URL of the binary Transcript file to use
     *
     * @generated from field: string transcript_url = 3;
     */
    transcriptUrl: string;
};
/**
 * Describes the message avn.connect.v1.SetActivityTranscriptRequest.
 * Use `create(SetActivityTranscriptRequestSchema)` to create a new message.
 */
declare const SetActivityTranscriptRequestSchema: GenMessage<SetActivityTranscriptRequest>;
/**
 * @generated from message avn.connect.v1.GetTranscriptResponse
 */
type GetTranscriptResponse = Message<"avn.connect.v1.GetTranscriptResponse"> & {
    /**
     * Set if the job succeeded and contains an AVNFS URL to a binary Transcript file
     *
     * @generated from field: optional string transcript_url = 1;
     */
    transcriptUrl?: string;
    /**
     * Populated if there were transcription errors
     *
     * @generated from field: repeated string errors = 2;
     */
    errors: string[];
    /**
     * Populated if there were transcription warnings
     *
     * @generated from field: repeated string warnings = 3;
     */
    warnings: string[];
};
/**
 * Describes the message avn.connect.v1.GetTranscriptResponse.
 * Use `create(GetTranscriptResponseSchema)` to create a new message.
 */
declare const GetTranscriptResponseSchema: GenMessage<GetTranscriptResponse>;
/**
 * @generated from message avn.connect.v1.Transcript
 */
type Transcript = Message<"avn.connect.v1.Transcript"> & {
    /**
     * File version
     *
     * @generated from field: int32 version = 1;
     */
    version: number;
    /**
     * All the speakers in the transcription
     *
     * @generated from field: repeated avn.connect.v1.Speaker speakers = 2;
     */
    speakers: Speaker[];
    /**
     * All the transcribed segments. Segments may be in different languages: each
     * carries its own language_id, so a single transcript can be multilingual.
     *
     * @generated from field: repeated avn.connect.v1.TranscriptSegment segments = 3;
     */
    segments: TranscriptSegment[];
};
/**
 * Describes the message avn.connect.v1.Transcript.
 * Use `create(TranscriptSchema)` to create a new message.
 */
declare const TranscriptSchema: GenMessage<Transcript>;
/**
 * @generated from message avn.connect.v1.TranscriptSegment
 */
type TranscriptSegment = Message<"avn.connect.v1.TranscriptSegment"> & {
    /**
     * Segment of transcribed speech
     *
     * @generated from field: string text = 1;
     */
    text: string;
    /**
     * ID of person speaking. Only unique within a given transcript.
     *
     * @generated from field: int32 speaker_id = 2;
     */
    speakerId: number;
    /**
     * Language of this segment's text (BCP 47). Segments in one transcript may differ.
     * On translated output this is the target language and differs from source_language_id.
     *
     * @generated from field: string language_id = 3;
     */
    languageId: string;
    /**
     * Time the speech starts
     *
     * @generated from field: float start_time_seconds = 4;
     */
    startTimeSeconds: number;
    /**
     * Time the speech ends
     *
     * @generated from field: float end_time_seconds = 5;
     */
    endTimeSeconds: number;
    /**
     * Metadata about the speech segment
     *
     * @generated from field: repeated avn.connect.v1.SpeechFlag speech_flags = 6;
     */
    speechFlags: SpeechFlag[];
    /**
     * Original language this segment was translated from (BCP 47); only set on translated output
     *
     * @generated from field: string source_language_id = 8;
     */
    sourceLanguageId: string;
    /**
     * ID of the stored translation for this segment (links to the translation store); only set on translated output
     *
     * @generated from field: string translation_id = 7;
     */
    translationId: string;
};
/**
 * Describes the message avn.connect.v1.TranscriptSegment.
 * Use `create(TranscriptSegmentSchema)` to create a new message.
 */
declare const TranscriptSegmentSchema: GenMessage<TranscriptSegment>;
/**
 * @generated from service avn.connect.v1.TranscriptionService
 */
declare const TranscriptionService: GenService<{
    /**
     * Get the transcript from a video or audio file, transcribing it if one does not
     * already exist. A transcript may contain segments in several languages (each
     * segment carries its own language_id).
     * Pass `translate` with a target language_id to translate every
     * segment on demand; leave it unset to return the transcript unchanged.
     *
     * @generated from rpc avn.connect.v1.TranscriptionService.GetMediaTranscript
     */
    getMediaTranscript: {
        methodKind: "unary";
        input: typeof GetMediaTranscriptRequestSchema;
        output: typeof GetTranscriptResponseSchema;
    };
    /**
     * Get the transcript for an activity's source file (or the override set via
     * SetActivityTranscript, if one exists). A transcript's language(s) are held
     * per-segment and are independent of the activity's own language_id.
     * Pass `translate` with a target language_id to
     * translate every segment on demand; leave it unset to return the original.
     *
     * @generated from rpc avn.connect.v1.TranscriptionService.GetActivityTranscript
     */
    getActivityTranscript: {
        methodKind: "unary";
        input: typeof GetActivityTranscriptRequestSchema;
        output: typeof GetTranscriptResponseSchema;
    };
    /**
     * Set a transcript override for an activity, replacing the auto-generated
     * transcript of its source file. Provide the transcript in its original
     * language(s): GetActivityTranscript translates on read, so there is no need to
     * store a separate copy per language. (Because segment languages are independent
     * of the activity's language_id, an override is safe to copy verbatim when an
     * activity is duplicated.)
     *
     * @generated from rpc avn.connect.v1.TranscriptionService.SetActivityTranscript
     */
    setActivityTranscript: {
        methodKind: "unary";
        input: typeof SetActivityTranscriptRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/users.proto.
 */
declare const file_avn_connect_v1_users: GenFile;
/**
 * @generated from message avn.connect.v1.GetCurrentUserRequest
 */
type GetCurrentUserRequest = Message<"avn.connect.v1.GetCurrentUserRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
};
/**
 * Describes the message avn.connect.v1.GetCurrentUserRequest.
 * Use `create(GetCurrentUserRequestSchema)` to create a new message.
 */
declare const GetCurrentUserRequestSchema: GenMessage<GetCurrentUserRequest>;
/**
 * @generated from message avn.connect.v1.GetOrganizationMembershipRequest
 */
type GetOrganizationMembershipRequest = Message<"avn.connect.v1.GetOrganizationMembershipRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * User to request membership details for
     *
     * @generated from field: int32 user_id = 2;
     */
    userId: number;
    /**
     * Maximum number of results to return. Defaults to 30 when unset or 0, and is clamped to a
     * maximum of 256. Negative values are rejected.
     *
     * @generated from field: optional int32 page_size = 3;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search. Must be a token returned as next_page_token by an
     * earlier call; malformed tokens are rejected rather than returning an empty page.
     *
     * @generated from field: optional string page_token = 4;
     */
    pageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetOrganizationMembershipRequest.
 * Use `create(GetOrganizationMembershipRequestSchema)` to create a new message.
 */
declare const GetOrganizationMembershipRequestSchema: GenMessage<GetOrganizationMembershipRequest>;
/**
 * @generated from message avn.connect.v1.GetOrganizationMembershipResponse
 */
type GetOrganizationMembershipResponse = Message<"avn.connect.v1.GetOrganizationMembershipResponse"> & {
    /**
     * Organizations that the user belongs to
     *
     * @generated from field: repeated avn.connect.v1.OrganizationMembership memberships = 1;
     */
    memberships: OrganizationMembership[];
    /**
     * Token to use to get more pages of results or unset if no more results are available
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetOrganizationMembershipResponse.
 * Use `create(GetOrganizationMembershipResponseSchema)` to create a new message.
 */
declare const GetOrganizationMembershipResponseSchema: GenMessage<GetOrganizationMembershipResponse>;
/**
 * @generated from message avn.connect.v1.SearchMemberOrganizationsRequest
 */
type SearchMemberOrganizationsRequest = Message<"avn.connect.v1.SearchMemberOrganizationsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Text to search organizations for using strict matching an % for wildcards
     *
     * @generated from field: optional string search_text = 2;
     */
    searchText?: string;
    /**
     * Maximum number of results to return. Defaults to 30 when unset or 0, and is clamped to a
     * maximum of 256. Negative values are rejected. There is no unpaged mode: an account whose
     * defaultOrganizations reach spans the tree can match tens of thousands of organizations, so
     * callers needing the whole set must follow next_page_token.
     *
     * @generated from field: optional int32 page_size = 3;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search. Must be a token returned as next_page_token by an
     * earlier call; malformed tokens are rejected rather than returning an empty page.
     *
     * @generated from field: optional string page_token = 4;
     */
    pageToken?: string;
};
/**
 * Describes the message avn.connect.v1.SearchMemberOrganizationsRequest.
 * Use `create(SearchMemberOrganizationsRequestSchema)` to create a new message.
 */
declare const SearchMemberOrganizationsRequestSchema: GenMessage<SearchMemberOrganizationsRequest>;
/**
 * @generated from message avn.connect.v1.SearchMemberOrganizationsResponse
 */
type SearchMemberOrganizationsResponse = Message<"avn.connect.v1.SearchMemberOrganizationsResponse"> & {
    /**
     * Matching membership information
     *
     * @generated from field: repeated avn.connect.v1.OrganizationInfo results = 1;
     */
    results: OrganizationInfo[];
    /**
     * Token to use to access more paged results
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.SearchMemberOrganizationsResponse.
 * Use `create(SearchMemberOrganizationsResponseSchema)` to create a new message.
 */
declare const SearchMemberOrganizationsResponseSchema: GenMessage<SearchMemberOrganizationsResponse>;
/**
 * @generated from message avn.connect.v1.GetRecentOrganizationsRequest
 */
type GetRecentOrganizationsRequest = Message<"avn.connect.v1.GetRecentOrganizationsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * User to request recent organizations for
     *
     * @generated from field: int32 user_id = 2;
     */
    userId: number;
};
/**
 * Describes the message avn.connect.v1.GetRecentOrganizationsRequest.
 * Use `create(GetRecentOrganizationsRequestSchema)` to create a new message.
 */
declare const GetRecentOrganizationsRequestSchema: GenMessage<GetRecentOrganizationsRequest>;
/**
 * @generated from message avn.connect.v1.GetRecentOrganizationsResponse
 */
type GetRecentOrganizationsResponse = Message<"avn.connect.v1.GetRecentOrganizationsResponse"> & {
    /**
     * Organizations that the user has recently used
     *
     * @generated from field: repeated avn.connect.v1.OrganizationInfo results = 1;
     */
    results: OrganizationInfo[];
};
/**
 * Describes the message avn.connect.v1.GetRecentOrganizationsResponse.
 * Use `create(GetRecentOrganizationsResponseSchema)` to create a new message.
 */
declare const GetRecentOrganizationsResponseSchema: GenMessage<GetRecentOrganizationsResponse>;
/**
 * Eduverse user management services
 *
 * @generated from service avn.connect.v1.UserService
 */
declare const UserService: GenService<{
    /**
     * Get the currently authenticated user (resolved from the request's auth credentials)
     *
     * @generated from rpc avn.connect.v1.UserService.GetCurrentUser
     */
    getCurrentUser: {
        methodKind: "unary";
        input: typeof GetCurrentUserRequestSchema;
        output: typeof UserSchema;
    };
    /**
     * Get user by ID
     *
     * @generated from rpc avn.connect.v1.UserService.GetUser
     */
    getUser: {
        methodKind: "unary";
        input: typeof GetEntityRequestSchema;
        output: typeof UserSchema;
    };
    /**
     * Get the organizations which the user directly belongs to. Users (and support users) see their own full list; other callers see only the memberships in organizations where they hold the `viewUsers` permission
     *
     * @generated from rpc avn.connect.v1.UserService.GetOrganizationMembership
     */
    getOrganizationMembership: {
        methodKind: "unary";
        input: typeof GetOrganizationMembershipRequestSchema;
        output: typeof GetOrganizationMembershipResponseSchema;
    };
    /**
     * Search organizations the user belongs to directly and by inheritence
     *
     * @generated from rpc avn.connect.v1.UserService.SearchMemberOrganizations
     */
    searchMemberOrganizations: {
        methodKind: "unary";
        input: typeof SearchMemberOrganizationsRequestSchema;
        output: typeof SearchMemberOrganizationsResponseSchema;
    };
    /**
     * Requires the deleteUsers permission
     *
     * @generated from rpc avn.connect.v1.UserService.DeleteUser
     */
    deleteUser: {
        methodKind: "unary";
        input: typeof DeleteEntityRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * A list of organizations recently used by this user
     *
     * @generated from rpc avn.connect.v1.UserService.GetRecentOrganizations
     */
    getRecentOrganizations: {
        methodKind: "unary";
        input: typeof GetRecentOrganizationsRequestSchema;
        output: typeof GetRecentOrganizationsResponseSchema;
    };
}>;

/**
 * The build published on one channel of a product stream
 *
 * @generated from message avn.connect.v1.ProductStreamChannel
 */
type ProductStreamChannel = Message<"avn.connect.v1.ProductStreamChannel"> & {
    /**
     * @generated from field: avn.connect.v1.ReleaseChannel channel = 1;
     */
    channel: ReleaseChannel;
    /**
     * Lowest build accepted as current. Equal to version_max except on a PRODUCTION rollout range
     *
     * @generated from field: int32 version_min = 2;
     */
    versionMin: number;
    /**
     * Highest build accepted as current, and the build devices are steered to
     *
     * @generated from field: int32 version_max = 3;
     */
    versionMax: number;
    /**
     * When the build was published to the channel
     *
     * @generated from field: google.protobuf.Timestamp published = 4;
     */
    published?: Timestamp;
};
/**
 * @generated from message avn.connect.v1.ProductStream
 */
type ProductStream = Message<"avn.connect.v1.ProductStream"> & {
    /**
     * Product stream ID
     *
     * @generated from field: int32 entity_id = 1;
     */
    entityId: number;
    /**
     * Device product the stream steers, as devices report it (e.g. "CVR255")
     *
     * @generated from field: string product = 2;
     */
    product: string;
    /**
     * Free-text notes
     *
     * @generated from field: optional string notes = 3;
     */
    notes?: string;
    /**
     * Channels with a published build. A channel that is absent has nothing published and does
     * not steer devices
     *
     * @generated from field: repeated avn.connect.v1.ProductStreamChannel channels = 4;
     */
    channels: ProductStreamChannel[];
};
/**
 * Describes the message avn.connect.v1.ProductStream.
 * Use `create(ProductStreamSchema)` to create a new message.
 */
declare const ProductStreamSchema: GenMessage<ProductStream>;
/**
 * @generated from message avn.connect.v1.GetProductStreamsRequest
 */
type GetProductStreamsRequest = Message<"avn.connect.v1.GetProductStreamsRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
};
/**
 * Describes the message avn.connect.v1.GetProductStreamsRequest.
 * Use `create(GetProductStreamsRequestSchema)` to create a new message.
 */
declare const GetProductStreamsRequestSchema: GenMessage<GetProductStreamsRequest>;
/**
 * @generated from message avn.connect.v1.GetProductStreamsResponse
 */
type GetProductStreamsResponse = Message<"avn.connect.v1.GetProductStreamsResponse"> & {
    /**
     * @generated from field: repeated avn.connect.v1.ProductStream product_streams = 1;
     */
    productStreams: ProductStream[];
};
/**
 * Describes the message avn.connect.v1.GetProductStreamsResponse.
 * Use `create(GetProductStreamsResponseSchema)` to create a new message.
 */
declare const GetProductStreamsResponseSchema: GenMessage<GetProductStreamsResponse>;
/**
 * @generated from message avn.connect.v1.GetProductStreamRequest
 */
type GetProductStreamRequest = Message<"avn.connect.v1.GetProductStreamRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: int32 product_stream_id = 2;
     */
    productStreamId: number;
};
/**
 * Describes the message avn.connect.v1.GetProductStreamRequest.
 * Use `create(GetProductStreamRequestSchema)` to create a new message.
 */
declare const GetProductStreamRequestSchema: GenMessage<GetProductStreamRequest>;
/**
 * @generated from message avn.connect.v1.CreateProductStreamRequest
 */
type CreateProductStreamRequest = Message<"avn.connect.v1.CreateProductStreamRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: string product = 2;
     */
    product: string;
};
/**
 * Describes the message avn.connect.v1.CreateProductStreamRequest.
 * Use `create(CreateProductStreamRequestSchema)` to create a new message.
 */
declare const CreateProductStreamRequestSchema: GenMessage<CreateProductStreamRequest>;
/**
 * @generated from message avn.connect.v1.CreateProductStreamResponse
 */
type CreateProductStreamResponse = Message<"avn.connect.v1.CreateProductStreamResponse"> & {
    /**
     * @generated from field: int32 product_stream_id = 1;
     */
    productStreamId: number;
};
/**
 * Describes the message avn.connect.v1.CreateProductStreamResponse.
 * Use `create(CreateProductStreamResponseSchema)` to create a new message.
 */
declare const CreateProductStreamResponseSchema: GenMessage<CreateProductStreamResponse>;
/**
 * @generated from message avn.connect.v1.DeleteProductStreamRequest
 */
type DeleteProductStreamRequest = Message<"avn.connect.v1.DeleteProductStreamRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: int32 product_stream_id = 2;
     */
    productStreamId: number;
};
/**
 * Describes the message avn.connect.v1.DeleteProductStreamRequest.
 * Use `create(DeleteProductStreamRequestSchema)` to create a new message.
 */
declare const DeleteProductStreamRequestSchema: GenMessage<DeleteProductStreamRequest>;
/**
 * @generated from message avn.connect.v1.SetProductStreamChannelRequest
 */
type SetProductStreamChannelRequest = Message<"avn.connect.v1.SetProductStreamChannelRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: int32 product_stream_id = 2;
     */
    productStreamId: number;
    /**
     * @generated from field: avn.connect.v1.ReleaseChannel channel = 3;
     */
    channel: ReleaseChannel;
    /**
     * Build to publish; omit both versions to clear the channel
     *
     * @generated from field: optional int32 version_min = 4;
     */
    versionMin?: number;
    /**
     * Upper end of a PRODUCTION rollout range; defaults to version_min
     *
     * @generated from field: optional int32 version_max = 5;
     */
    versionMax?: number;
};
/**
 * Describes the message avn.connect.v1.SetProductStreamChannelRequest.
 * Use `create(SetProductStreamChannelRequestSchema)` to create a new message.
 */
declare const SetProductStreamChannelRequestSchema: GenMessage<SetProductStreamChannelRequest>;
/**
 * Adoption of one published channel. Devices in the unenrolled holding organization are not counted
 *
 * @generated from message avn.connect.v1.ProductStreamChannelStatistics
 */
type ProductStreamChannelStatistics = Message<"avn.connect.v1.ProductStreamChannelStatistics"> & {
    /**
     * @generated from field: avn.connect.v1.ReleaseChannel channel = 1;
     */
    channel: ReleaseChannel;
    /**
     * @generated from field: int32 version_min = 2;
     */
    versionMin: number;
    /**
     * @generated from field: int32 version_max = 3;
     */
    versionMax: number;
    /**
     * @generated from field: google.protobuf.Timestamp published = 4;
     */
    published?: Timestamp;
    /**
     * Devices on the channel
     *
     * @generated from field: int32 devices = 5;
     */
    devices: number;
    /**
     * Devices on the channel whose reported build is within the expected range
     *
     * @generated from field: int32 devices_current = 6;
     */
    devicesCurrent: number;
    /**
     * Devices on the channel seen since the build was published
     *
     * @generated from field: int32 devices_recent = 7;
     */
    devicesRecent: number;
    /**
     * Devices seen since the build was published whose reported build is within the expected range
     *
     * @generated from field: int32 devices_recent_current = 8;
     */
    devicesRecentCurrent: number;
};
/**
 * @generated from message avn.connect.v1.ProductStreamStatistics
 */
type ProductStreamStatistics = Message<"avn.connect.v1.ProductStreamStatistics"> & {
    /**
     * @generated from field: int32 product_stream_id = 1;
     */
    productStreamId: number;
    /**
     * @generated from field: string product = 2;
     */
    product: string;
    /**
     * Devices reporting this product, on any channel
     *
     * @generated from field: int32 devices = 3;
     */
    devices: number;
    /**
     * Of those, devices seen within the last N months, keyed by N. The server chooses the
     * windows (currently 3 and 12)
     *
     * @generated from field: map<int32, int32> devices_active_within_months = 4;
     */
    devicesActiveWithinMonths: {
        [key: number]: number;
    };
    /**
     * One entry per published channel
     *
     * @generated from field: repeated avn.connect.v1.ProductStreamChannelStatistics channels = 5;
     */
    channels: ProductStreamChannelStatistics[];
    /**
     * When the fleet counts were computed; they are cached for up to ten minutes
     *
     * @generated from field: google.protobuf.Timestamp computed = 6;
     */
    computed?: Timestamp;
};
/**
 * @generated from message avn.connect.v1.GetProductStreamStatisticsRequest
 */
type GetProductStreamStatisticsRequest = Message<"avn.connect.v1.GetProductStreamStatisticsRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Streams to report on; empty means all
     *
     * @generated from field: repeated int32 product_stream_ids = 2;
     */
    productStreamIds: number[];
};
/**
 * Describes the message avn.connect.v1.GetProductStreamStatisticsRequest.
 * Use `create(GetProductStreamStatisticsRequestSchema)` to create a new message.
 */
declare const GetProductStreamStatisticsRequestSchema: GenMessage<GetProductStreamStatisticsRequest>;
/**
 * @generated from message avn.connect.v1.GetProductStreamStatisticsResponse
 */
type GetProductStreamStatisticsResponse = Message<"avn.connect.v1.GetProductStreamStatisticsResponse"> & {
    /**
     * @generated from field: repeated avn.connect.v1.ProductStreamStatistics statistics = 1;
     */
    statistics: ProductStreamStatistics[];
};
/**
 * Describes the message avn.connect.v1.GetProductStreamStatisticsResponse.
 * Use `create(GetProductStreamStatisticsResponseSchema)` to create a new message.
 */
declare const GetProductStreamStatisticsResponseSchema: GenMessage<GetProductStreamStatisticsResponse>;
/**
 * An organization with stale devices on a channel
 *
 * @generated from message avn.connect.v1.StaleOrganization
 */
type StaleOrganization = Message<"avn.connect.v1.StaleOrganization"> & {
    /**
     * @generated from field: int32 organization_id = 1;
     */
    organizationId: number;
    /**
     * @generated from field: string organization_name = 2;
     */
    organizationName: string;
    /**
     * Devices on the channel outside the expected build range, whether or not seen recently
     *
     * @generated from field: int32 stale_devices = 3;
     */
    staleDevices: number;
    /**
     * All devices the organization has on the channel
     *
     * @generated from field: int32 devices = 4;
     */
    devices: number;
    /**
     * Stale devices seen since the build was published, counted by how often they have checked
     * in since: the value under key N is the number with at least N check-ins, so the counts are
     * cumulative. The server chooses the tiers (currently 100, 10 and 1)
     *
     * @generated from field: map<int32, int32> stale_devices_by_min_checkins = 5;
     */
    staleDevicesByMinCheckins: {
        [key: number]: number;
    };
};
/**
 * @generated from message avn.connect.v1.GetProductStreamStaleOrganizationsRequest
 */
type GetProductStreamStaleOrganizationsRequest = Message<"avn.connect.v1.GetProductStreamStaleOrganizationsRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: int32 product_stream_id = 2;
     */
    productStreamId: number;
    /**
     * @generated from field: avn.connect.v1.ReleaseChannel channel = 3;
     */
    channel: ReleaseChannel;
};
/**
 * Describes the message avn.connect.v1.GetProductStreamStaleOrganizationsRequest.
 * Use `create(GetProductStreamStaleOrganizationsRequestSchema)` to create a new message.
 */
declare const GetProductStreamStaleOrganizationsRequestSchema: GenMessage<GetProductStreamStaleOrganizationsRequest>;
/**
 * @generated from message avn.connect.v1.GetProductStreamStaleOrganizationsResponse
 */
type GetProductStreamStaleOrganizationsResponse = Message<"avn.connect.v1.GetProductStreamStaleOrganizationsResponse"> & {
    /**
     * Ordered by the check-in tiers from the highest down, then stale devices, then devices, all descending
     *
     * @generated from field: repeated avn.connect.v1.StaleOrganization organizations = 1;
     */
    organizations: StaleOrganization[];
};
/**
 * Describes the message avn.connect.v1.GetProductStreamStaleOrganizationsResponse.
 * Use `create(GetProductStreamStaleOrganizationsResponseSchema)` to create a new message.
 */
declare const GetProductStreamStaleOrganizationsResponseSchema: GenMessage<GetProductStreamStaleOrganizationsResponse>;
/**
 * Product streams: the client build that each device product should run on each release channel
 * (legacy portal /manage/productstreams.cfm, lp_product_streams). A device adopts its channel's build
 * at its next check-in. The production channel spans a version range so that a phased rollout does
 * not flag devices at either end of it as out of date; alpha and beta target a single build.
 *
 * Publishing a build to a channel stamps the channel's published time and touches every device on
 * that product and channel so each one re-reads its configuration at its next check-in.
 * Implementations record avn.productstream events on create/delete/edit.
 *
 * @generated from service avn.connect.v1.ProductStreamService
 */
declare const ProductStreamService: GenService<{
    /**
     * All product streams, ordered by product. Any signed-in user
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.GetProductStreams
     */
    getProductStreams: {
        methodKind: "unary";
        input: typeof GetProductStreamsRequestSchema;
        output: typeof GetProductStreamsResponseSchema;
    };
    /**
     * One product stream. Any signed-in user
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.GetProductStream
     */
    getProductStream: {
        methodKind: "unary";
        input: typeof GetProductStreamRequestSchema;
        output: typeof ProductStreamSchema;
    };
    /**
     * Create a product stream for a device product (the value devices report as their product, e.g.
     * "CVR255"). Trimmed, must be non-empty, at most 64 characters and not already used by another
     * stream. Channels start empty. Requires the `manageSystemApps` (or `administerSite`) permission
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.CreateProductStream
     */
    createProductStream: {
        methodKind: "unary";
        input: typeof CreateProductStreamRequestSchema;
        output: typeof CreateProductStreamResponseSchema;
    };
    /**
     * Delete a product stream. Devices on the product keep the build they have and are no longer
     * steered. Requires the `manageSystemApps` (or `administerSite`) permission
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.DeleteProductStream
     */
    deleteProductStream: {
        methodKind: "unary";
        input: typeof DeleteProductStreamRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Publish a build to one channel of a stream, or clear the channel.
     * version_min is the build to publish. For PRODUCTION, version_max extends it to a rollout range
     * and defaults to version_min; for ALPHA and BETA it must be absent or equal to version_min.
     * Every version must be a registered client release. Omitting both versions clears the channel.
     * A request that repeats the channel's current state is a no-op: the published time is not reset
     * and devices are not touched, so the call is safe to retry. Otherwise the channel's published
     * time is set to now and every device on that product and channel is touched.
     * Returns the updated stream. Requires the `manageSystemApps` (or `administerSite`) permission
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.SetProductStreamChannel
     */
    setProductStreamChannel: {
        methodKind: "unary";
        input: typeof SetProductStreamChannelRequestSchema;
        output: typeof ProductStreamSchema;
    };
    /**
     * Get the properties of one or more product streams. entity_ids carry product stream IDs.
     * Supports PRODUCT and NOTES. Any signed-in user
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetEntityPropertiesRequestSchema;
        output: typeof GetEntityPropertiesResponseSchema;
    };
    /**
     * Set the properties of one or more product streams. entity_ids carry product stream IDs.
     * Supports PRODUCT (trimmed, non-empty, at most 64 characters, unique across streams) and NOTES
     * (trimmed, empty string clears). Requires the `manageSystemApps` (or `administerSite`) permission
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetEntityPropertiesRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Fleet statistics for product streams: how many devices each product has, how many have been
     * seen recently, and per published channel how many are on the expected build. Computed in one
     * pass over the fleet and cached for up to ten minutes; `computed` says when. Requires the
     * `supportSite` permission
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.GetProductStreamStatistics
     */
    getProductStreamStatistics: {
        methodKind: "unary";
        input: typeof GetProductStreamStatisticsRequestSchema;
        output: typeof GetProductStreamStatisticsResponseSchema;
    };
    /**
     * Organizations with devices on a channel that have reported in since the channel's build was
     * published and are still outside the expected range, ranked by how often those devices have
     * checked in since. Empty when the channel has nothing published. Requires the `supportSite`
     * permission
     *
     * @generated from rpc avn.connect.v1.ProductStreamService.GetProductStreamStaleOrganizations
     */
    getProductStreamStaleOrganizations: {
        methodKind: "unary";
        input: typeof GetProductStreamStaleOrganizationsRequestSchema;
        output: typeof GetProductStreamStaleOrganizationsResponseSchema;
    };
}>;

/**
 * @generated from message avn.connect.v1.SystemAppsRelease
 */
type SystemAppsRelease = Message<"avn.connect.v1.SystemAppsRelease"> & {
    /**
     * Build number of the ClassVR client APK (lp_learnpad_releases.id). Headsets report it as their
     * version and product streams publish it to channels
     *
     * @generated from field: int32 version = 1;
     */
    version: number;
    /**
     * AVNFS URL of the ClassVR client APK (column classvrpackageurl)
     *
     * @generated from field: string classvr_apk_url = 2;
     */
    classvrApkUrl: string;
    /**
     * AVNFS URL of the Config APK by signing key (see the service comment for the keys). A key that
     * is absent has no Config APK on this release. Legacy LearnPad keys are not reported
     *
     * @generated from field: map<string, string> config_packages = 3;
     */
    configPackages: {
        [key: string]: string;
    };
};
/**
 * Describes the message avn.connect.v1.SystemAppsRelease.
 * Use `create(SystemAppsReleaseSchema)` to create a new message.
 */
declare const SystemAppsReleaseSchema: GenMessage<SystemAppsRelease>;
/**
 * @generated from message avn.connect.v1.GetSystemAppsReleasesRequest
 */
type GetSystemAppsReleasesRequest = Message<"avn.connect.v1.GetSystemAppsReleasesRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Maximum number of results to return. Defaults to 30 when unset or 0, and is clamped to a
     * maximum of 256. Negative values are rejected.
     *
     * @generated from field: optional int32 page_size = 2;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search. Must be a token returned as next_page_token by an
     * earlier call; malformed tokens are rejected rather than returning an empty page.
     *
     * @generated from field: optional string page_token = 3;
     */
    pageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetSystemAppsReleasesRequest.
 * Use `create(GetSystemAppsReleasesRequestSchema)` to create a new message.
 */
declare const GetSystemAppsReleasesRequestSchema: GenMessage<GetSystemAppsReleasesRequest>;
/**
 * @generated from message avn.connect.v1.GetSystemAppsReleasesResponse
 */
type GetSystemAppsReleasesResponse = Message<"avn.connect.v1.GetSystemAppsReleasesResponse"> & {
    /**
     * Releases, newest build first
     *
     * @generated from field: repeated avn.connect.v1.SystemAppsRelease results = 1;
     */
    results: SystemAppsRelease[];
    /**
     * Token to use to get more pages of results or unset if no more results are available
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetSystemAppsReleasesResponse.
 * Use `create(GetSystemAppsReleasesResponseSchema)` to create a new message.
 */
declare const GetSystemAppsReleasesResponseSchema: GenMessage<GetSystemAppsReleasesResponse>;
/**
 * @generated from message avn.connect.v1.GetSystemAppsReleaseRequest
 */
type GetSystemAppsReleaseRequest = Message<"avn.connect.v1.GetSystemAppsReleaseRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: int32 version = 2;
     */
    version: number;
};
/**
 * Describes the message avn.connect.v1.GetSystemAppsReleaseRequest.
 * Use `create(GetSystemAppsReleaseRequestSchema)` to create a new message.
 */
declare const GetSystemAppsReleaseRequestSchema: GenMessage<GetSystemAppsReleaseRequest>;
/**
 * @generated from message avn.connect.v1.GetSystemAppsSourcesRequest
 */
type GetSystemAppsSourcesRequest = Message<"avn.connect.v1.GetSystemAppsSourcesRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
};
/**
 * Describes the message avn.connect.v1.GetSystemAppsSourcesRequest.
 * Use `create(GetSystemAppsSourcesRequestSchema)` to create a new message.
 */
declare const GetSystemAppsSourcesRequestSchema: GenMessage<GetSystemAppsSourcesRequest>;
/**
 * @generated from message avn.connect.v1.SystemAppsSources
 */
type SystemAppsSources = Message<"avn.connect.v1.SystemAppsSources"> & {
    /**
     * The release a mint would produce now. `version` is 0 when no build number can be read from
     * the client package file name
     *
     * @generated from field: avn.connect.v1.SystemAppsRelease candidate = 1;
     */
    candidate?: SystemAppsRelease;
    /**
     * Whether `candidate.version` is already registered, in which case a mint fails with ALREADY_EXISTS
     *
     * @generated from field: bool registered = 2;
     */
    registered: boolean;
    /**
     * APP activity whose package files supply the ClassVR client
     *
     * @generated from field: int32 classvr_activity_id = 3;
     */
    classvrActivityId: number;
    /**
     * APP activity whose package files supply each signing key's Config APK
     *
     * @generated from field: map<string, int32> config_activity_ids = 4;
     */
    configActivityIds: {
        [key: string]: number;
    };
};
/**
 * Describes the message avn.connect.v1.SystemAppsSources.
 * Use `create(SystemAppsSourcesSchema)` to create a new message.
 */
declare const SystemAppsSourcesSchema: GenMessage<SystemAppsSources>;
/**
 * @generated from message avn.connect.v1.CreateSystemAppsReleaseRequest
 */
type CreateSystemAppsReleaseRequest = Message<"avn.connect.v1.CreateSystemAppsReleaseRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Assemble and validate the release but do not store it. The response is the release that would
     * be minted, so a portal can show the build number and packages before committing. Every failure
     * of a real mint, including ALREADY_EXISTS, is reported the same way
     *
     * @generated from field: bool dry_run = 2;
     */
    dryRun: boolean;
};
/**
 * Describes the message avn.connect.v1.CreateSystemAppsReleaseRequest.
 * Use `create(CreateSystemAppsReleaseRequestSchema)` to create a new message.
 */
declare const CreateSystemAppsReleaseRequestSchema: GenMessage<CreateSystemAppsReleaseRequest>;
/**
 * @generated from message avn.connect.v1.DeleteSystemAppsReleaseRequest
 */
type DeleteSystemAppsReleaseRequest = Message<"avn.connect.v1.DeleteSystemAppsReleaseRequest"> & {
    /**
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * @generated from field: int32 version = 2;
     */
    version: number;
};
/**
 * Describes the message avn.connect.v1.DeleteSystemAppsReleaseRequest.
 * Use `create(DeleteSystemAppsReleaseRequestSchema)` to create a new message.
 */
declare const DeleteSystemAppsReleaseRequestSchema: GenMessage<DeleteSystemAppsReleaseRequest>;
/**
 * System apps releases: the APKs a ClassVR headset must have installed to run a given client build
 * (legacy portal /manage/admin/client-management.cfm, lp_learnpad_releases). A release is keyed by
 * the build number of the ClassVR client APK it carries; product streams publish these build numbers
 * to their channels (ProductStreamService) and a headset installs the release's packages at check-in.
 *
 * Each release carries the ClassVR client APK plus one Config APK per platform signing key. Android
 * only permits an app to be upgraded by an APK signed with the same key as the installed one, and
 * each headset platform signs the pre-installed Config app with its own key, so the same Config build
 * is registered once per key and the headset is served the variant matching the key it reports.
 *
 * Releases are not authored field by field. Every system app is an APP activity whose package files
 * are uploaded through the portal, and a release is minted from the newest package file of each of
 * those activities. The server owns the activity list: the ClassVR client, the four ClassVR Config
 * activities below, and the legacy LearnPad activities (client, browser and six further Config
 * signing keys) whose columns are still filled so the legacy row stays complete. The build number
 * is read from the ClassVR client APK itself (versionCode), never supplied by the caller.
 *
 * Signing keys are named by the first byte of the SHA-1 fingerprint of the signing certificate, as
 * the headset reports it (Device.platformKeys / configKeys) and as the legacy columns and Config
 * activities are named. The ClassVR keys, their platforms and their lp_learnpad_releases columns:
 *   "41"  41:79:1C:9B:8F:AF:15:E1:AC:D5:AA:F5:92:10:FD:42:46:7D:82:77  ClassVR 1 family (CVR155, CVR155A, CVR155A1), Rockchip. configpackageurl41
 *   "73"  73:7B:D0:4B:98:8D:87:FC:F2:19:DC:1E:1B:22:48:B0:42:E5:1C:F3  ClassVR 6 (CVR655128), Qualcomm Android 12L. configpackageurl73
 *   "93"  93:1C:15:ED:F3:16:29:30:6D:61:6F:8C:26:C3:31:83:F6:15:00:C8  ClassVR 2-64 (CVR25564), Qualcomm Android 8. configpackageurl93
 *   "BF"  BF:6A:A2:DE:0B:70:70:D0:11:96:74:F1:CD:CD:F9:BA:75:35:BF:66  ClassVR 2, 2-A and XR1 (CVR255, CVR255A, CVR355128), Qualcomm Android 8. configpackageurlBF
 *
 * Implementations record avn.systemapps events on create/delete.
 *
 * @generated from service avn.connect.v1.SystemAppsService
 */
declare const SystemAppsService: GenService<{
    /**
     * Releases ordered by build number descending, paged. Any signed-in user
     *
     * @generated from rpc avn.connect.v1.SystemAppsService.GetSystemAppsReleases
     */
    getSystemAppsReleases: {
        methodKind: "unary";
        input: typeof GetSystemAppsReleasesRequestSchema;
        output: typeof GetSystemAppsReleasesResponseSchema;
    };
    /**
     * One release from its build number. Any signed-in user
     *
     * @generated from rpc avn.connect.v1.SystemAppsService.GetSystemAppsRelease
     */
    getSystemAppsRelease: {
        methodKind: "unary";
        input: typeof GetSystemAppsReleaseRequestSchema;
        output: typeof SystemAppsReleaseSchema;
    };
    /**
     * The newest package file of every system app activity, shaped as the release a mint would
     * produce now, with the activities they came from so a portal can link to them. Fails with
     * FAILED_PRECONDITION when an activity has no package file. Any signed-in user
     *
     * @generated from rpc avn.connect.v1.SystemAppsService.GetSystemAppsSources
     */
    getSystemAppsSources: {
        methodKind: "unary";
        input: typeof GetSystemAppsSourcesRequestSchema;
        output: typeof SystemAppsSourcesSchema;
    };
    /**
     * Mint a release from the newest package file of every system app activity. The server downloads
     * the ClassVR client APK, reads its versionCode as the build number, and inserts the row with the
     * client URL and every Config URL (legacy columns included). Fails with ALREADY_EXISTS when a
     * release with that build number is already registered: the caller must not be left believing a
     * new build was made when nothing changed. Fails with FAILED_PRECONDITION when an activity has no
     * package file or no build number can be read from the client package. The build number is read
     * from the client package file name until APK analysis is available; that will also verify each
     * Config APK is signed with the key of the activity it was uploaded to. Returns the new release. Requires the `manageSystemApps` (or `administerSite`) permission
     *
     * @generated from rpc avn.connect.v1.SystemAppsService.CreateSystemAppsRelease
     */
    createSystemAppsRelease: {
        methodKind: "unary";
        input: typeof CreateSystemAppsReleaseRequestSchema;
        output: typeof SystemAppsReleaseSchema;
    };
    /**
     * Delete a release. Refused while any product stream channel publishes the build or any device
     * has it as a pending version, since either would strand headsets on an unregistered build.
     * A wrongly minted release is corrected by fixing the activity's package files, deleting the
     * release and minting again. Requires the `manageSystemApps` (or `administerSite`) permission
     *
     * @generated from rpc avn.connect.v1.SystemAppsService.DeleteSystemAppsRelease
     */
    deleteSystemAppsRelease: {
        methodKind: "unary";
        input: typeof DeleteSystemAppsReleaseRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/wifi_ap.proto.
 */
declare const file_avn_connect_v1_wifi_ap: GenFile;
/**
 * Full access point record, including credentials. Only returned to callers holding
 * `viewAccessPoints` for the owning organization
 *
 * @generated from message avn.connect.v1.WifiAccessPoint
 */
type WifiAccessPoint = Message<"avn.connect.v1.WifiAccessPoint"> & {
    /**
     * Access point ID
     *
     * @generated from field: int32 access_point_id = 1;
     */
    accessPointId: number;
    /**
     * Network SSID
     *
     * @generated from field: string ssid = 2;
     */
    ssid: string;
    /**
     * Organization owner
     *
     * @generated from field: int32 organization_id = 3;
     */
    organizationId: number;
    /**
     * Encryption scheme
     *
     * @generated from field: avn.connect.v1.WifiEncryption encryption = 4;
     */
    encryption: WifiEncryption;
    /**
     * EAP identity. Only meaningful for WPA_EAP_PEAP and WPA_EAP_TLS
     *
     * @generated from field: optional string username = 5;
     */
    username?: string;
    /**
     * Network password / pre-shared key. Unset for NOPASS networks
     *
     * @generated from field: optional string password = 6;
     */
    password?: string;
    /**
     * Is the SSID hidden (not broadcast)? Clients must probe for it
     *
     * @generated from field: bool hidden = 7;
     */
    hidden: boolean;
    /**
     * Connection priority. Higher values are preferred. Range 0-99999
     *
     * @generated from field: int32 priority = 8;
     */
    priority: number;
    /**
     * Should this access point be pushed to devices in the owning organization and its descendants?
     *
     * @generated from field: bool deploy = 9;
     */
    deploy: boolean;
    /**
     * When the access point was created
     *
     * @generated from field: google.protobuf.Timestamp created = 10;
     */
    created?: Timestamp;
    /**
     * When the access point was last edited
     *
     * @generated from field: google.protobuf.Timestamp updated = 11;
     */
    updated?: Timestamp;
    /**
     * AVNFS URL of one or more concatenated PEM CA certificates forming the trust anchor for
     * 802.1X server validation. Only meaningful for WPA_EAP_PEAP and WPA_EAP_TLS
     *
     * @generated from field: optional string certificate_url = 12;
     */
    certificateUrl?: string;
    /**
     * Server certificate domain suffix match for 802.1X validation (WifiEnterpriseConfig
     * setDomainSuffixMatch on devices). Only meaningful with a certificate_url
     *
     * @generated from field: optional string domain = 13;
     */
    domain?: string;
    /**
     * How EAP-TLS client credentials are provisioned. Only meaningful for WPA_EAP_TLS
     *
     * @generated from field: avn.connect.v1.WifiClientCredential client_credential = 14;
     */
    clientCredential: WifiClientCredential;
    /**
     * PKCS12 method: AVNFS URL of the shared PKCS#12 client bundle
     *
     * @generated from field: optional string client_certificate_url = 15;
     */
    clientCertificateUrl?: string;
    /**
     * PKCS12 method: password protecting the PKCS#12 bundle
     *
     * @generated from field: optional string client_certificate_password = 16;
     */
    clientCertificatePassword?: string;
    /**
     * SCEP method: enrollment endpoint URL (e.g. an Aruba ClearPass Onboard SCEP URL)
     *
     * @generated from field: optional string enroll_url = 17;
     */
    enrollUrl?: string;
    /**
     * SCEP method: static challenge password, if the endpoint requires one
     *
     * @generated from field: optional string enroll_challenge = 18;
     */
    enrollChallenge?: string;
    /**
     * SCEP method: optional subject/CN template. Devices default to CN=<device serial>
     *
     * @generated from field: optional string enroll_subject = 19;
     */
    enrollSubject?: string;
    /**
     * TTLS inner authentication method. Only meaningful for WPA_EAP_TTLS; UNSPECIFIED
     * means the device default (MSCHAPv2)
     *
     * @generated from field: avn.connect.v1.WifiPhase2 phase2 = 20;
     */
    phase2: WifiPhase2;
    /**
     * Join with the device's factory-fixed MAC address instead of a per-network randomised
     * one (Android's "Use device MAC"), for networks that admit only registered MAC
     * addresses. The stored-AP form of the WiFi QR MR:false flag: it reaches devices as the
     * check-in JSON key `usedevicemac` and rides an AP's QR code as MR:false. Default false
     * = the platform's randomised MAC. Honoured by Client 3.2+ / Config 5.7+; older clients
     * ignore the field and join randomised
     *
     * @generated from field: bool use_device_mac = 21;
     */
    useDeviceMac: boolean;
};
/**
 * Describes the message avn.connect.v1.WifiAccessPoint.
 * Use `create(WifiAccessPointSchema)` to create a new message.
 */
declare const WifiAccessPointSchema: GenMessage<WifiAccessPoint>;
/**
 * Access point summary for listings. Fetch further detail through GetProperties
 *
 * @generated from message avn.connect.v1.WifiAccessPointInfo
 */
type WifiAccessPointInfo = Message<"avn.connect.v1.WifiAccessPointInfo"> & {
    /**
     * Access point ID
     *
     * @generated from field: int32 access_point_id = 1;
     */
    accessPointId: number;
    /**
     * Network SSID
     *
     * @generated from field: string ssid = 2;
     */
    ssid: string;
    /**
     * Organization owner. Lists that include ancestors group results by this field
     *
     * @generated from field: int32 organization_id = 3;
     */
    organizationId: number;
    /**
     * When the access point was last edited
     *
     * @generated from field: google.protobuf.Timestamp updated = 4;
     */
    updated?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.WifiAccessPointInfo.
 * Use `create(WifiAccessPointInfoSchema)` to create a new message.
 */
declare const WifiAccessPointInfoSchema: GenMessage<WifiAccessPointInfo>;
/**
 * @generated from message avn.connect.v1.GetAccessPointRequest
 */
type GetAccessPointRequest = Message<"avn.connect.v1.GetAccessPointRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Access point ID
     *
     * @generated from field: int32 access_point_id = 2;
     */
    accessPointId: number;
};
/**
 * Describes the message avn.connect.v1.GetAccessPointRequest.
 * Use `create(GetAccessPointRequestSchema)` to create a new message.
 */
declare const GetAccessPointRequestSchema: GenMessage<GetAccessPointRequest>;
/**
 * @generated from message avn.connect.v1.GetOrganizationAccessPointsRequest
 */
type GetOrganizationAccessPointsRequest = Message<"avn.connect.v1.GetOrganizationAccessPointsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Organization to list access points for
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
    /**
     * Also include access points owned by ancestor organizations, as the legacy
     * portal listing does. Defaults to false (requested organization only)
     *
     * @generated from field: optional bool include_ancestors = 3;
     */
    includeAncestors?: boolean;
    /**
     * Maximum number of results to return. Defaults to 30 when unset or 0, and is clamped to a
     * maximum of 256. Negative values are rejected.
     *
     * @generated from field: optional int32 page_size = 4;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search. Must be a token returned as next_page_token by an
     * earlier call; malformed tokens are rejected rather than returning an empty page.
     *
     * @generated from field: optional string page_token = 5;
     */
    pageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetOrganizationAccessPointsRequest.
 * Use `create(GetOrganizationAccessPointsRequestSchema)` to create a new message.
 */
declare const GetOrganizationAccessPointsRequestSchema: GenMessage<GetOrganizationAccessPointsRequest>;
/**
 * @generated from message avn.connect.v1.GetOrganizationAccessPointsResponse
 */
type GetOrganizationAccessPointsResponse = Message<"avn.connect.v1.GetOrganizationAccessPointsResponse"> & {
    /**
     * Access points ordered by SSID, without credentials
     *
     * @generated from field: repeated avn.connect.v1.WifiAccessPointInfo results = 1;
     */
    results: WifiAccessPointInfo[];
    /**
     * Token to use to get more pages of results or unset if no more results are available
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetOrganizationAccessPointsResponse.
 * Use `create(GetOrganizationAccessPointsResponseSchema)` to create a new message.
 */
declare const GetOrganizationAccessPointsResponseSchema: GenMessage<GetOrganizationAccessPointsResponse>;
/**
 * @generated from message avn.connect.v1.CreateAccessPointRequest
 */
type CreateAccessPointRequest = Message<"avn.connect.v1.CreateAccessPointRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Organization that will own the access point
     *
     * @generated from field: int32 organization_id = 2;
     */
    organizationId: number;
    /**
     * Network SSID. Trimmed; must be non-empty after trimming
     *
     * @generated from field: string ssid = 3;
     */
    ssid: string;
};
/**
 * Describes the message avn.connect.v1.CreateAccessPointRequest.
 * Use `create(CreateAccessPointRequestSchema)` to create a new message.
 */
declare const CreateAccessPointRequestSchema: GenMessage<CreateAccessPointRequest>;
/**
 * @generated from message avn.connect.v1.CreateAccessPointResponse
 */
type CreateAccessPointResponse = Message<"avn.connect.v1.CreateAccessPointResponse"> & {
    /**
     * ID of the new access point
     *
     * @generated from field: int32 access_point_id = 1;
     */
    accessPointId: number;
};
/**
 * Describes the message avn.connect.v1.CreateAccessPointResponse.
 * Use `create(CreateAccessPointResponseSchema)` to create a new message.
 */
declare const CreateAccessPointResponseSchema: GenMessage<CreateAccessPointResponse>;
/**
 * @generated from message avn.connect.v1.DeleteAccessPointRequest
 */
type DeleteAccessPointRequest = Message<"avn.connect.v1.DeleteAccessPointRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Access point to delete
     *
     * @generated from field: int32 access_point_id = 2;
     */
    accessPointId: number;
};
/**
 * Describes the message avn.connect.v1.DeleteAccessPointRequest.
 * Use `create(DeleteAccessPointRequestSchema)` to create a new message.
 */
declare const DeleteAccessPointRequestSchema: GenMessage<DeleteAccessPointRequest>;
/**
 * WiFi encryption schemes supported by clients. Stored values map 1:1 onto the legacy
 * lp_wifi_ap.encryption strings (nopass, WPA, SAE, WEP, WPA-EAP-PEAP, WPA-EAP-TTLS,
 * WPA-EAP-TLS).
 *
 * @generated from enum avn.connect.v1.WifiEncryption
 */
declare enum WifiEncryption {
    /**
     * @generated from enum value: WIFI_ENCRYPTION_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Open network, no credentials
     *
     * @generated from enum value: WIFI_ENCRYPTION_NOPASS = 1;
     */
    NOPASS = 1,
    /**
     * WPA/WPA2 pre-shared key
     *
     * @generated from enum value: WIFI_ENCRYPTION_WPA = 2;
     */
    WPA = 2,
    /**
     * Legacy WEP. Deprecated: retained for existing rows only, clients no longer support it
     *
     * @generated from enum value: WIFI_ENCRYPTION_WEP = 3;
     */
    WEP = 3,
    /**
     * WPA2-Enterprise with PEAP (username + password; the inner method is always MSCHAPv2)
     *
     * @generated from enum value: WIFI_ENCRYPTION_WPA_EAP_PEAP = 4;
     */
    WPA_EAP_PEAP = 4,
    /**
     * WPA2-Enterprise with TLS (username + password)
     *
     * @generated from enum value: WIFI_ENCRYPTION_WPA_EAP_TLS = 5;
     */
    WPA_EAP_TLS = 5,
    /**
     * WPA3-Personal (SAE). Xcelerate (CVR6) only: earlier generations run Android 8.1,
     * which has no SAE support, and access points are pushed to every model without
     * filtering, so those devices skip a network of this type rather than failing to join
     *
     * @generated from enum value: WIFI_ENCRYPTION_SAE = 6;
     */
    SAE = 6,
    /**
     * WPA2-Enterprise with TTLS (username + password; the inner method comes from phase2).
     * Requires Client 3.2+ / Config 5.7+ on devices; the Mono 2.7 client's enum parser
     * throws on unknown encryption values and one such access point breaks that device's
     * whole check-in, so define TTLS networks only in organizations whose fleet has updated
     *
     * @generated from enum value: WIFI_ENCRYPTION_WPA_EAP_TTLS = 7;
     */
    WPA_EAP_TTLS = 7
}
/**
 * Describes the enum avn.connect.v1.WifiEncryption.
 */
declare const WifiEncryptionSchema: GenEnum<WifiEncryption>;
/**
 * TTLS inner (phase-2) authentication method. Stored values map onto the legacy
 * lp_wifi_ap.phase2 strings (pap, mschapv2, gtc); unset/NULL means MSCHAPv2, with the
 * default living on the device so it can evolve without portal writes. Only meaningful
 * for WPA_EAP_TTLS: TTLS exists mostly for TTLS/PAP against directory-backed RADIUS
 * servers that store no NT hashes and therefore cannot verify MSCHAPv2
 *
 * @generated from enum avn.connect.v1.WifiPhase2
 */
declare enum WifiPhase2 {
    /**
     * @generated from enum value: WIFI_PHASE2_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Plain username/password inside the TLS tunnel (RADIUS PAP)
     *
     * @generated from enum value: WIFI_PHASE2_PAP = 1;
     */
    PAP = 1,
    /**
     * MSCHAPv2 inside the tunnel — the same inner method PEAP always uses
     *
     * @generated from enum value: WIFI_PHASE2_MSCHAPV2 = 2;
     */
    MSCHAPV2 = 2,
    /**
     * Generic Token Card, for one-time-password backends
     *
     * @generated from enum value: WIFI_PHASE2_GTC = 3;
     */
    GTC = 3
}
/**
 * Describes the enum avn.connect.v1.WifiPhase2.
 */
declare const WifiPhase2Schema: GenEnum<WifiPhase2>;
/**
 * How EAP-TLS client credentials are provisioned for an access point. Stored values map
 * onto the legacy lp_wifi_ap.clientcredential strings (pkcs12, scep); unset/NULL means no
 * method is configured and clients fall back to the legacy device-record client certificate
 *
 * @generated from enum avn.connect.v1.WifiClientCredential
 */
declare enum WifiClientCredential {
    /**
     * @generated from enum value: WIFI_CLIENT_CREDENTIAL_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Shared fleet identity: a PKCS#12 bundle delivered by AVNFS URL. One bundle, one CN,
     * presented by every device joining the network
     *
     * @generated from enum value: WIFI_CLIENT_CREDENTIAL_PKCS12 = 1;
     */
    PKCS12 = 1,
    /**
     * Per-device identity enrolled over SCEP from the endpoint in enroll_url. The device
     * generates its keypair locally and only the CSR crosses the network
     *
     * @generated from enum value: WIFI_CLIENT_CREDENTIAL_SCEP = 2;
     */
    SCEP = 2
}
/**
 * Describes the enum avn.connect.v1.WifiClientCredential.
 */
declare const WifiClientCredentialSchema: GenEnum<WifiClientCredential>;
/**
 * WiFi access point management (legacy portal: /manage/accesspoints.cfm, lp_wifi_ap).
 * Implementations record avn.accesspoint events on create/delete/edit; the password
 * edit event must not include the password value.
 *
 * @generated from service avn.connect.v1.WifiAccessPointService
 */
declare const WifiAccessPointService: GenService<{
    /**
     * Get a single access point, including credentials. Requires the `viewAccessPoints` permission for the owning organization
     *
     * @generated from rpc avn.connect.v1.WifiAccessPointService.GetAccessPoint
     */
    getAccessPoint: {
        methodKind: "unary";
        input: typeof GetAccessPointRequestSchema;
        output: typeof WifiAccessPointSchema;
    };
    /**
     * Get the access points owned by an organization, optionally including those inherited
     * from ancestor organizations. Results contain no credentials and are ordered by SSID.
     * Requires the `viewAccessPoints` permission for the requested organization; ancestor
     * organizations that fail the check are skipped rather than failing the request
     *
     * @generated from rpc avn.connect.v1.WifiAccessPointService.GetOrganizationAccessPoints
     */
    getOrganizationAccessPoints: {
        methodKind: "unary";
        input: typeof GetOrganizationAccessPointsRequestSchema;
        output: typeof GetOrganizationAccessPointsResponseSchema;
    };
    /**
     * Create an access point. SSID is trimmed and must be non-empty; all other fields take
     * the legacy defaults (encryption WPA, not hidden, priority 0, deploy false) and are
     * configured through SetProperties. Requires the `createAccessPoints` permission for the organization
     *
     * @generated from rpc avn.connect.v1.WifiAccessPointService.CreateAccessPoint
     */
    createAccessPoint: {
        methodKind: "unary";
        input: typeof CreateAccessPointRequestSchema;
        output: typeof CreateAccessPointResponseSchema;
    };
    /**
     * Delete an access point. Requires the `deleteAccessPoints` permission for the owning organization
     *
     * @generated from rpc avn.connect.v1.WifiAccessPointService.DeleteAccessPoint
     */
    deleteAccessPoint: {
        methodKind: "unary";
        input: typeof DeleteAccessPointRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get the properties of one or more access points. entity_ids carry access point IDs.
     * Supports SSID, ENCRYPTION, USERNAME, PASSWORD, HIDDEN, PRIORITY, DEPLOY, ORGANIZATION_ID,
     * CREATED, UPDATED, CERTIFICATE_URL, DOMAIN, CLIENT_CREDENTIAL, CLIENT_CERTIFICATE_URL,
     * CLIENT_CERTIFICATE_PASSWORD, ENROLL_URL, ENROLL_CHALLENGE, ENROLL_SUBJECT, PHASE2,
     * USE_DEVICE_MAC.
     * Requires the `viewAccessPoints` permission for each access point's owning organization
     *
     * @generated from rpc avn.connect.v1.WifiAccessPointService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetEntityPropertiesRequestSchema;
        output: typeof GetEntityPropertiesResponseSchema;
    };
    /**
     * Set the properties of one or more access points. entity_ids carry access point IDs.
     * Supports SSID (trimmed, rejected if empty), ENCRYPTION (WifiEncryption enum name as a string),
     * USERNAME, PASSWORD (empty string clears either), HIDDEN, PRIORITY (rejected outside 0-99999), DEPLOY,
     * USE_DEVICE_MAC (bool), CERTIFICATE_URL (AVNFS URL, empty string clears), DOMAIN (empty string clears),
     * CLIENT_CREDENTIAL (WifiClientCredential enum name as a string, empty string clears),
     * CLIENT_CERTIFICATE_URL / CLIENT_CERTIFICATE_PASSWORD / ENROLL_URL / ENROLL_CHALLENGE /
     * ENROLL_SUBJECT (empty string clears each), PHASE2 (WifiPhase2 enum name as a string,
     * empty string clears — meaning the device default, MSCHAPv2).
     * Requires the `editAccessPoints` permission for each access point's owning organization
     *
     * @generated from rpc avn.connect.v1.WifiAccessPointService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetEntityPropertiesRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Supplies a fresh user access JWT. Called only when a request carries a userJwt that is about to expire
 * (or has expired), or after the server rejected one as Unauthenticated.
 */
type UserJwtProvider = () => Promise<string>;
/** Refresh when this little lifetime remains, allowing for clock skew and request latency */
declare const UserJwtRefreshMarginSeconds = 120;
/** The `exp` claim of a JWT in seconds since the epoch (as issued), or undefined if the token cannot be decoded (no signature check) */
declare function jwtExpiry(jwt: string): number | undefined;
/** True when the token has less than the refresh margin left, cannot be decoded, or has no expiry */
declare function jwtNeedsRefresh(jwt: string, nowSeconds?: number): boolean;
/**
 * Keeps the user JWT on outgoing requests fresh, so long-lived pages (device monitors, players) work after the token's
 * lifetime and after the machine has been asleep. Requests whose `auth.userJwt` is near expiry get a new token from
 * the provider before being sent; a request the server still rejects as Unauthenticated is retried once with a new
 * token. Concurrent refreshes share one provider call.
 */
declare function createUserJwtInterceptor(provider: UserJwtProvider): Interceptor;

declare const GwebUrl = "https://gweb.avncloud.com";
declare const GwebAlphaUrl = "https://gweb-alpha.avncloud.com";
interface ConnectServicesOptions {
    /** Supplies a fresh user access JWT; when set, requests carrying an expiring userJwt are refreshed before sending */
    userJwtProvider?: UserJwtProvider;
}
declare class ConnectServices {
    readonly gwebUrl: string;
    constructor(gwebUrl?: string, options?: ConnectServicesOptions);
    private transport;
    Activities: Client<typeof ActivityService>;
    Avnfs: Client<typeof AvnfsService>;
    Blockade: Client<typeof BlockadeService>;
    Categories: Client<typeof CategoryService>;
    Certificates: Client<typeof CertificateService>;
    Channels: Client<typeof ChannelService>;
    Clients: Client<typeof ClientService>;
    Cloud: Client<typeof CloudService>;
    Content: Client<typeof ContentService>;
    Countries: Client<typeof CountryService>;
    Delightex: Client<typeof DelightexService>;
    Dimensions: Client<typeof DimensionService>;
    Geo: Client<typeof GeoService>;
    Health: Client<typeof Health>;
    Info: Client<typeof InfoService>;
    Ktx: Client<typeof KtxService>;
    Languages: Client<typeof LanguageService>;
    Grants: Client<typeof GrantService>;
    Media: Client<typeof MediaService>;
    Neighbors: Client<typeof NeighborService>;
    Organizations: Client<typeof OrganizationService>;
    Passes: Client<typeof PassService>;
    Permissions: Client<typeof PermissionService>;
    Profiles: Client<typeof ProfileService>;
    Roles: Client<typeof RoleService>;
    Rooms: Client<typeof RoomService>;
    Speech: Client<typeof SpeechService>;
    Tags: Client<typeof TagService>;
    ThreeSixtyCities: Client<typeof ThreeSixtyCitiesService>;
    Transcriptions: Client<typeof TranscriptionService>;
    Translations: Client<typeof TranslationService>;
    Users: Client<typeof UserService>;
    AndroidPackages: Client<typeof AndroidPackageService>;
    ProductStreams: Client<typeof ProductStreamService>;
    SystemApps: Client<typeof SystemAppsService>;
    WifiAccessPoints: Client<typeof WifiAccessPointService>;
}

/**
 * Describes the file avn/connect/v1/command.proto.
 */
declare const file_avn_connect_v1_command: GenFile;
/**
 * @generated from message avn.connect.v1.CommandRequest
 */
type CommandRequest = Message<"avn.connect.v1.CommandRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Command to execute
     *
     * @generated from field: string command = 2;
     */
    command: string;
    /**
     * Escape output filenames with angle brackets, e.g. <output.txt>
     *
     * @generated from field: repeated string arguments = 3;
     */
    arguments: string[];
};
/**
 * Describes the message avn.connect.v1.CommandRequest.
 * Use `create(CommandRequestSchema)` to create a new message.
 */
declare const CommandRequestSchema: GenMessage<CommandRequest>;
/**
 * @generated from message avn.connect.v1.CommandResponse
 */
type CommandResponse = Message<"avn.connect.v1.CommandResponse"> & {
    /**
     * Exit code for the command
     *
     * @generated from field: int32 code = 1;
     */
    code: number;
    /**
     * Command output
     *
     * @generated from field: string stdout = 2;
     */
    stdout: string;
    /**
     * Error output
     *
     * @generated from field: string stderr = 3;
     */
    stderr: string;
    /**
     * Optional output files
     *
     * @generated from field: repeated string output_file_urls = 4;
     */
    outputFileUrls: string[];
};
/**
 * Describes the message avn.connect.v1.CommandResponse.
 * Use `create(CommandResponseSchema)` to create a new message.
 */
declare const CommandResponseSchema: GenMessage<CommandResponse>;

/**
 * Describes the file avn/connect/v1/devices.proto.
 */
declare const file_avn_connect_v1_devices: GenFile;
/**
 * @generated from message avn.connect.v1.DeviceInfo
 */
type DeviceInfo = Message<"avn.connect.v1.DeviceInfo"> & {
    /**
     * Device ID
     *
     * @generated from field: string device_id = 1;
     */
    deviceId: string;
    /**
     * Device name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Organization owner
     *
     * @generated from field: int32 organization_id = 3;
     */
    organizationId: number;
    /**
     * When device properties were last edited. NOT a check-in timestamp - use last_access for that.
     *
     * @generated from field: google.protobuf.Timestamp updated = 4;
     */
    updated?: Timestamp;
    /**
     * When device last reported in (most recent check-in)
     *
     * @generated from field: google.protobuf.Timestamp last_access = 5;
     */
    lastAccess?: Timestamp;
};
/**
 * Describes the message avn.connect.v1.DeviceInfo.
 * Use `create(DeviceInfoSchema)` to create a new message.
 */
declare const DeviceInfoSchema: GenMessage<DeviceInfo>;
/**
 * @generated from message avn.connect.v1.Device
 */
type Device = Message<"avn.connect.v1.Device"> & {
    /**
     * Device ID
     *
     * @generated from field: string device_id = 1;
     */
    deviceId: string;
    /**
     * Device name
     *
     * @generated from field: string name = 2;
     */
    name: string;
    /**
     * Device MAC address
     *
     * @generated from field: string mac_address = 3;
     */
    macAddress: string;
    /**
     * Device serial identifier
     *
     * @generated from field: string serial = 4;
     */
    serial: string;
    /**
     * Device model code
     *
     * @generated from field: string model = 5;
     */
    model: string;
    /**
     * Device product code
     *
     * @generated from field: string product = 6;
     */
    product: string;
    /**
     * Organization owner
     *
     * @generated from field: int32 organization_id = 7;
     */
    organizationId: number;
    /**
     * When device last reported in (most recent check-in)
     *
     * @generated from field: google.protobuf.Timestamp last_access = 8;
     */
    lastAccess?: Timestamp;
    /**
     * When device properties were last edited. NOT a check-in timestamp - use last_access for that.
     *
     * @generated from field: google.protobuf.Timestamp updated = 9;
     */
    updated?: Timestamp;
    /**
     * Firmware build identifier reported by the device (raw build string)
     *
     * @generated from field: string firmware = 10;
     */
    firmware: string;
    /**
     * Release channel the device is tracking for updates
     *
     * @generated from field: avn.connect.v1.ReleaseChannel channel = 11;
     */
    channel: ReleaseChannel;
    /**
     * Installed client app version
     *
     * @generated from field: int32 client_version = 12;
     */
    clientVersion: number;
    /**
     * Installed config version
     *
     * @generated from field: int32 config_version = 13;
     */
    configVersion: number;
};
/**
 * Describes the message avn.connect.v1.Device.
 * Use `create(DeviceSchema)` to create a new message.
 */
declare const DeviceSchema: GenMessage<Device>;
/**
 * @generated from message avn.connect.v1.GetDeviceRequest
 */
type GetDeviceRequest = Message<"avn.connect.v1.GetDeviceRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Device ID
     *
     * @generated from field: string device_id = 2;
     */
    deviceId: string;
};
/**
 * Describes the message avn.connect.v1.GetDeviceRequest.
 * Use `create(GetDeviceRequestSchema)` to create a new message.
 */
declare const GetDeviceRequestSchema: GenMessage<GetDeviceRequest>;
/**
 * @generated from message avn.connect.v1.GetDevicesForOrganizationRequest
 */
type GetDevicesForOrganizationRequest = Message<"avn.connect.v1.GetDevicesForOrganizationRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * IDs of owner organizations to search
     *
     * @generated from field: repeated int32 organization_ids = 2;
     */
    organizationIds: number[];
    /**
     * Maximum number of results to return. Defaults to 30 when unset or 0, and is clamped to a
     * maximum of 256. Negative values are rejected.
     *
     * @generated from field: optional int32 page_size = 8;
     */
    pageSize?: number;
    /**
     * Start point from a previous paged search. Must be a token returned as next_page_token by an
     * earlier call; malformed tokens are rejected rather than returning an empty page.
     *
     * @generated from field: optional string page_token = 9;
     */
    pageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetDevicesForOrganizationRequest.
 * Use `create(GetDevicesForOrganizationRequestSchema)` to create a new message.
 */
declare const GetDevicesForOrganizationRequestSchema: GenMessage<GetDevicesForOrganizationRequest>;
/**
 * @generated from message avn.connect.v1.GetDevicesForOrganizationResponse
 */
type GetDevicesForOrganizationResponse = Message<"avn.connect.v1.GetDevicesForOrganizationResponse"> & {
    /**
     * Search results
     *
     * @generated from field: repeated avn.connect.v1.DeviceInfo results = 1;
     */
    results: DeviceInfo[];
    /**
     * Token to use to get more pages of results or unset if no more results are available
     *
     * @generated from field: optional string next_page_token = 2;
     */
    nextPageToken?: string;
};
/**
 * Describes the message avn.connect.v1.GetDevicesForOrganizationResponse.
 * Use `create(GetDevicesForOrganizationResponseSchema)` to create a new message.
 */
declare const GetDevicesForOrganizationResponseSchema: GenMessage<GetDevicesForOrganizationResponse>;
/**
 * Simple device credentials
 *
 * @generated from message avn.connect.v1.DeviceCredentials
 */
type DeviceCredentials = Message<"avn.connect.v1.DeviceCredentials"> & {
    /**
     * Device ID
     *
     * @generated from field: string device_id = 1;
     */
    deviceId: string;
    /**
     * Device secret
     *
     * @generated from field: string device_secret = 2;
     */
    deviceSecret: string;
};
/**
 * Describes the message avn.connect.v1.DeviceCredentials.
 * Use `create(DeviceCredentialsSchema)` to create a new message.
 */
declare const DeviceCredentialsSchema: GenMessage<DeviceCredentials>;
/**
 * @generated from message avn.connect.v1.AuthorizeDeviceRequest
 */
type AuthorizeDeviceRequest = Message<"avn.connect.v1.AuthorizeDeviceRequest"> & {
    /**
     * The device that is making the request
     *
     * @generated from field: avn.connect.v1.DeviceCredentials device = 1;
     */
    device?: DeviceCredentials;
};
/**
 * Describes the message avn.connect.v1.AuthorizeDeviceRequest.
 * Use `create(AuthorizeDeviceRequestSchema)` to create a new message.
 */
declare const AuthorizeDeviceRequestSchema: GenMessage<AuthorizeDeviceRequest>;
/**
 * @generated from message avn.connect.v1.AuthorizeDeviceResponse
 */
type AuthorizeDeviceResponse = Message<"avn.connect.v1.AuthorizeDeviceResponse"> & {
    /**
     * JWT a device can use to authorize future service calls
     *
     * @generated from field: string device_jwt = 1;
     */
    deviceJwt: string;
};
/**
 * Describes the message avn.connect.v1.AuthorizeDeviceResponse.
 * Use `create(AuthorizeDeviceResponseSchema)` to create a new message.
 */
declare const AuthorizeDeviceResponseSchema: GenMessage<AuthorizeDeviceResponse>;
/**
 * @generated from message avn.connect.v1.DeleteDeviceRequest
 */
type DeleteDeviceRequest = Message<"avn.connect.v1.DeleteDeviceRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Device ID
     *
     * @generated from field: string device_id = 2;
     */
    deviceId: string;
};
/**
 * Describes the message avn.connect.v1.DeleteDeviceRequest.
 * Use `create(DeleteDeviceRequestSchema)` to create a new message.
 */
declare const DeleteDeviceRequestSchema: GenMessage<DeleteDeviceRequest>;
/**
 * @generated from message avn.connect.v1.RecordLogRequest
 */
type RecordLogRequest = Message<"avn.connect.v1.RecordLogRequest"> & {
    /**
     * Authorization for the request. Must be a device JWT - the log is recorded against that device
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Log AVNFS URL
     *
     * @generated from field: string log_url = 2;
     */
    logUrl: string;
    /**
     * Metadata labels
     *
     * @generated from field: repeated string labels = 3;
     */
    labels: string[];
};
/**
 * Describes the message avn.connect.v1.RecordLogRequest.
 * Use `create(RecordLogRequestSchema)` to create a new message.
 */
declare const RecordLogRequestSchema: GenMessage<RecordLogRequest>;
/**
 * @generated from message avn.connect.v1.DeviceLog
 */
type DeviceLog = Message<"avn.connect.v1.DeviceLog"> & {
    /**
     * Device ID
     *
     * @generated from field: string device_id = 1;
     */
    deviceId: string;
    /**
     * Log AVNFS URL
     *
     * @generated from field: string log_url = 2;
     */
    logUrl: string;
    /**
     * Log creation time
     *
     * @generated from field: google.protobuf.Timestamp create = 4;
     */
    create?: Timestamp;
    /**
     * Metadata labels
     *
     * @generated from field: repeated string labels = 5;
     */
    labels: string[];
};
/**
 * Describes the message avn.connect.v1.DeviceLog.
 * Use `create(DeviceLogSchema)` to create a new message.
 */
declare const DeviceLogSchema: GenMessage<DeviceLog>;
/**
 * @generated from message avn.connect.v1.GetDeviceLogsRequest
 */
type GetDeviceLogsRequest = Message<"avn.connect.v1.GetDeviceLogsRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Device IDs
     *
     * @generated from field: repeated string device_id = 2;
     */
    deviceId: string[];
};
/**
 * Describes the message avn.connect.v1.GetDeviceLogsRequest.
 * Use `create(GetDeviceLogsRequestSchema)` to create a new message.
 */
declare const GetDeviceLogsRequestSchema: GenMessage<GetDeviceLogsRequest>;
/**
 * @generated from message avn.connect.v1.GetDeviceLogsResponse
 */
type GetDeviceLogsResponse = Message<"avn.connect.v1.GetDeviceLogsResponse"> & {
    /**
     * Device logs
     *
     * @generated from field: repeated avn.connect.v1.DeviceLog results = 2;
     */
    results: DeviceLog[];
};
/**
 * Describes the message avn.connect.v1.GetDeviceLogsResponse.
 * Use `create(GetDeviceLogsResponseSchema)` to create a new message.
 */
declare const GetDeviceLogsResponseSchema: GenMessage<GetDeviceLogsResponse>;
/**
 * Properties of a single device. Mirrors the generic `EntityProperties` message for string-keyed device IDs.
 *
 * @generated from message avn.connect.v1.DeviceProperties
 */
type DeviceProperties = Message<"avn.connect.v1.DeviceProperties"> & {
    /**
     * Device ID
     *
     * @generated from field: string device_id = 1;
     */
    deviceId: string;
    /**
     * Properties of the device
     *
     * @generated from field: repeated avn.connect.v1.EntityPropertyState property_states = 2;
     */
    propertyStates: EntityPropertyState[];
};
/**
 * Describes the message avn.connect.v1.DeviceProperties.
 * Use `create(DevicePropertiesSchema)` to create a new message.
 */
declare const DevicePropertiesSchema: GenMessage<DeviceProperties>;
/**
 * Bulk property getter to return every requested property from every requested device
 *
 * @generated from message avn.connect.v1.GetDevicePropertiesRequest
 */
type GetDevicePropertiesRequest = Message<"avn.connect.v1.GetDevicePropertiesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Devices to inspect. A single request may reference at most 128 devices; larger
     * requests are rejected. Page through bigger sets in batches of 128 or fewer.
     *
     * @generated from field: repeated string device_ids = 2;
     */
    deviceIds: string[];
    /**
     * Properties to inspect
     *
     * @generated from field: repeated avn.connect.v1.EntityProperty properties = 3;
     */
    properties: EntityProperty[];
};
/**
 * Describes the message avn.connect.v1.GetDevicePropertiesRequest.
 * Use `create(GetDevicePropertiesRequestSchema)` to create a new message.
 */
declare const GetDevicePropertiesRequestSchema: GenMessage<GetDevicePropertiesRequest>;
/**
 * @generated from message avn.connect.v1.GetDevicePropertiesResponse
 */
type GetDevicePropertiesResponse = Message<"avn.connect.v1.GetDevicePropertiesResponse"> & {
    /**
     * Device properties read
     *
     * @generated from field: repeated avn.connect.v1.DeviceProperties results = 1;
     */
    results: DeviceProperties[];
};
/**
 * Describes the message avn.connect.v1.GetDevicePropertiesResponse.
 * Use `create(GetDevicePropertiesResponseSchema)` to create a new message.
 */
declare const GetDevicePropertiesResponseSchema: GenMessage<GetDevicePropertiesResponse>;
/**
 * @generated from message avn.connect.v1.SetDevicePropertiesRequest
 */
type SetDevicePropertiesRequest = Message<"avn.connect.v1.SetDevicePropertiesRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Device properties to update. A single request may modify at most 128 devices;
     * larger requests are rejected. Batch bigger updates in groups of 128 or fewer.
     *
     * @generated from field: repeated avn.connect.v1.DeviceProperties device_properties = 2;
     */
    deviceProperties: DeviceProperties[];
};
/**
 * Describes the message avn.connect.v1.SetDevicePropertiesRequest.
 * Use `create(SetDevicePropertiesRequestSchema)` to create a new message.
 */
declare const SetDevicePropertiesRequestSchema: GenMessage<SetDevicePropertiesRequest>;
/**
 * @generated from message avn.connect.v1.SetDeviceCommandRequest
 */
type SetDeviceCommandRequest = Message<"avn.connect.v1.SetDeviceCommandRequest"> & {
    /**
     * Authorization for the request
     *
     * @generated from field: avn.connect.v1.Authorization auth = 1;
     */
    auth?: Authorization;
    /**
     * Device IDs
     *
     * @generated from field: repeated string device_id = 2;
     */
    deviceId: string[];
    /**
     * Device command
     *
     * @generated from field: avn.connect.v1.DeviceCommand command = 3;
     */
    command?: DeviceCommand;
};
/**
 * Describes the message avn.connect.v1.SetDeviceCommandRequest.
 * Use `create(SetDeviceCommandRequestSchema)` to create a new message.
 */
declare const SetDeviceCommandRequestSchema: GenMessage<SetDeviceCommandRequest>;
/**
 * @generated from message avn.connect.v1.DeviceCommand
 */
type DeviceCommand = Message<"avn.connect.v1.DeviceCommand"> & {
    /**
     * What the device should do when it next checks in
     *
     * @generated from field: avn.connect.v1.DeviceCommandMethod method = 1;
     */
    method: DeviceCommandMethod;
    /**
     * Optional parameters keyed by name (e.g. `volume` for SET_VOLUME)
     *
     * @generated from field: google.protobuf.Struct parameters = 2;
     */
    parameters?: JsonObject;
};
/**
 * Describes the message avn.connect.v1.DeviceCommand.
 * Use `create(DeviceCommandSchema)` to create a new message.
 */
declare const DeviceCommandSchema: GenMessage<DeviceCommand>;
/**
 * Remote device commands. Each command requires a specific permission on the device's owning organization:
 *   BLANK                                             - editDevices (lowest device-write tier; clears any pending command)
 *   REBOOT, SHUTDOWN                                  - shutdownDevices
 *   WIPE, CLEAR_CACHE, FACTORY_RESET                  - adminDevices
 *   SET_VOLUME, SEND_LOGS                             - editDevices
 *
 * @generated from enum avn.connect.v1.DeviceCommandMethod
 */
declare enum DeviceCommandMethod {
    /**
     * @generated from enum value: DEVICE_COMMAND_METHOD_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * Clear any pending command without queuing a new one. Acts as undo for a previous SetDeviceCommand that the device hasn't yet picked up.
     *
     * @generated from enum value: DEVICE_COMMAND_METHOD_BLANK = 1;
     */
    BLANK = 1,
    /**
     * Reboot the device
     *
     * @generated from enum value: DEVICE_COMMAND_METHOD_REBOOT = 2;
     */
    REBOOT = 2,
    /**
     * Power off the device
     *
     * @generated from enum value: DEVICE_COMMAND_METHOD_SHUTDOWN = 3;
     */
    SHUTDOWN = 3,
    /**
     * Remote wipe (removes user content)
     *
     * @generated from enum value: DEVICE_COMMAND_METHOD_WIPE = 4;
     */
    WIPE = 4,
    /**
     * Clear the device's application cache
     *
     * @generated from enum value: DEVICE_COMMAND_METHOD_CLEAR_CACHE = 5;
     */
    CLEAR_CACHE = 5,
    /**
     * Factory reset; also invalidates the device secret so it must re-enrol
     *
     * @generated from enum value: DEVICE_COMMAND_METHOD_FACTORY_RESET = 6;
     */
    FACTORY_RESET = 6,
    /**
     * Set the device volume. Expects `volume` parameter (number or numeric string)
     *
     * @generated from enum value: DEVICE_COMMAND_METHOD_SET_VOLUME = 7;
     */
    SET_VOLUME = 7,
    /**
     * Ask the device to upload its diagnostic logs
     *
     * @generated from enum value: DEVICE_COMMAND_METHOD_SEND_LOGS = 8;
     */
    SEND_LOGS = 8
}
/**
 * Describes the enum avn.connect.v1.DeviceCommandMethod.
 */
declare const DeviceCommandMethodSchema: GenEnum<DeviceCommandMethod>;
/**
 * @generated from service avn.connect.v1.DeviceService
 */
declare const DeviceService: GenService<{
    /**
     * Get a device from an ID
     *
     * @generated from rpc avn.connect.v1.DeviceService.GetDevice
     */
    getDevice: {
        methodKind: "unary";
        input: typeof GetDeviceRequestSchema;
        output: typeof DeviceSchema;
    };
    /**
     * Get all the devices for an org
     *
     * @generated from rpc avn.connect.v1.DeviceService.GetDevicesForOrganization
     */
    getDevicesForOrganization: {
        methodKind: "unary";
        input: typeof GetDevicesForOrganizationRequestSchema;
        output: typeof GetDevicesForOrganizationResponseSchema;
    };
    /**
     * Authorize a device to access other services
     *
     * @generated from rpc avn.connect.v1.DeviceService.AuthorizeDevice
     */
    authorizeDevice: {
        methodKind: "unary";
        input: typeof AuthorizeDeviceRequestSchema;
        output: typeof AuthorizeDeviceResponseSchema;
    };
    /**
     * Delete the target device. Requires the `deleteDevices` permission for the device owner's organization
     *
     * @generated from rpc avn.connect.v1.DeviceService.DeleteDevice
     */
    deleteDevice: {
        methodKind: "unary";
        input: typeof DeleteDeviceRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Record a log file from a device
     *
     * @generated from rpc avn.connect.v1.DeviceService.RecordLog
     */
    recordLog: {
        methodKind: "unary";
        input: typeof RecordLogRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get logs for one or more devices
     *
     * @generated from rpc avn.connect.v1.DeviceService.GetDeviceLogs
     */
    getDeviceLogs: {
        methodKind: "unary";
        input: typeof GetDeviceLogsRequestSchema;
        output: typeof GetDeviceLogsResponseSchema;
    };
    /**
     * Set the pending command for one or more devices. Best-effort: the device picks it up at next check-in. Reversible: a later call overwrites; use method `BLANK` to clear without queuing a real command.
     *
     * @generated from rpc avn.connect.v1.DeviceService.SetDeviceCommand
     */
    setDeviceCommand: {
        methodKind: "unary";
        input: typeof SetDeviceCommandRequestSchema;
        output: typeof EmptySchema;
    };
    /**
     * Get the requested properties from every requested device. Requires the `viewDevices` permission for each device's owning organization
     *
     * @generated from rpc avn.connect.v1.DeviceService.GetProperties
     */
    getProperties: {
        methodKind: "unary";
        input: typeof GetDevicePropertiesRequestSchema;
        output: typeof GetDevicePropertiesResponseSchema;
    };
    /**
     * Set properties on one or more devices. Requires the `editDevices` permission for each device's owning organization
     *
     * @generated from rpc avn.connect.v1.DeviceService.SetProperties
     */
    setProperties: {
        methodKind: "unary";
        input: typeof SetDevicePropertiesRequestSchema;
        output: typeof EmptySchema;
    };
}>;

/**
 * Describes the file avn/connect/v1/embedding.proto.
 */
declare const file_avn_connect_v1_embedding: GenFile;
/**
 * @generated from message avn.connect.v1.EmbeddingTransform
 */
type EmbeddingTransform = Message<"avn.connect.v1.EmbeddingTransform"> & {
    /**
     * Unique embedding model ID
     *
     * @generated from field: string model_id = 1;
     */
    modelId: string;
    /**
     * Number of dimensions in transform
     *
     * @generated from field: int32 dimensions = 2;
     */
    dimensions: number;
};
/**
 * Describes the message avn.connect.v1.EmbeddingTransform.
 * Use `create(EmbeddingTransformSchema)` to create a new message.
 */
declare const EmbeddingTransformSchema: GenMessage<EmbeddingTransform>;
/**
 * @generated from message avn.connect.v1.EmbeddingTransformRequest
 */
type EmbeddingTransformRequest = Message<"avn.connect.v1.EmbeddingTransformRequest"> & {
    /**
     * Literal text or media URL
     *
     * @generated from field: string text = 1;
     */
    text: string;
    /**
     * Transform model to use
     *
     * @generated from field: avn.connect.v1.EmbeddingTransform transform = 2;
     */
    transform?: EmbeddingTransform;
};
/**
 * Describes the message avn.connect.v1.EmbeddingTransformRequest.
 * Use `create(EmbeddingTransformRequestSchema)` to create a new message.
 */
declare const EmbeddingTransformRequestSchema: GenMessage<EmbeddingTransformRequest>;
/**
 * @generated from message avn.connect.v1.EmbeddingTransformResponse
 */
type EmbeddingTransformResponse = Message<"avn.connect.v1.EmbeddingTransformResponse"> & {
    /**
     * Hash of input text to embedding model
     *
     * @generated from field: string hash = 1;
     */
    hash: string;
    /**
     * Transformed vector output
     *
     * @generated from field: repeated float vector = 2;
     */
    vector: number[];
};
/**
 * Describes the message avn.connect.v1.EmbeddingTransformResponse.
 * Use `create(EmbeddingTransformResponseSchema)` to create a new message.
 */
declare const EmbeddingTransformResponseSchema: GenMessage<EmbeddingTransformResponse>;

/**
 * Describes the file avn/connect/v1/thinglink.proto.
 */
declare const file_avn_connect_v1_thinglink: GenFile;
/**
 * @generated from message avn.connect.v1.TransformMediaRequest
 */
type TransformMediaRequest = Message<"avn.connect.v1.TransformMediaRequest"> & {
    /**
     * @generated from field: string url = 1;
     */
    url: string;
};
/**
 * Describes the message avn.connect.v1.TransformMediaRequest.
 * Use `create(TransformMediaRequestSchema)` to create a new message.
 */
declare const TransformMediaRequestSchema: GenMessage<TransformMediaRequest>;
/**
 * @generated from message avn.connect.v1.TransformMediaResponse
 */
type TransformMediaResponse = Message<"avn.connect.v1.TransformMediaResponse"> & {
    /**
     * @generated from field: string url = 1;
     */
    url: string;
};
/**
 * Describes the message avn.connect.v1.TransformMediaResponse.
 * Use `create(TransformMediaResponseSchema)` to create a new message.
 */
declare const TransformMediaResponseSchema: GenMessage<TransformMediaResponse>;
/**
 * @generated from service avn.connect.v1.ThingLinkService
 */
declare const ThingLinkService: GenService<{
    /**
     * @generated from rpc avn.connect.v1.ThingLinkService.TransformMedia
     */
    transformMedia: {
        methodKind: "unary";
        input: typeof TransformMediaRequestSchema;
        output: typeof TransformMediaResponseSchema;
    };
}>;

type pb_d_AccessLimits = AccessLimits;
declare const pb_d_AccessLimitsSchema: typeof AccessLimitsSchema;
type pb_d_Activity = Activity;
type pb_d_ActivityFileType = ActivityFileType;
declare const pb_d_ActivityFileType: typeof ActivityFileType;
declare const pb_d_ActivityFileTypeSchema: typeof ActivityFileTypeSchema;
declare const pb_d_ActivitySchema: typeof ActivitySchema;
declare const pb_d_ActivityService: typeof ActivityService;
type pb_d_ActivityType = ActivityType;
declare const pb_d_ActivityType: typeof ActivityType;
declare const pb_d_ActivityTypeSchema: typeof ActivityTypeSchema;
type pb_d_AddActivityFilesRequest = AddActivityFilesRequest;
declare const pb_d_AddActivityFilesRequestSchema: typeof AddActivityFilesRequestSchema;
type pb_d_AddChildrenRequest = AddChildrenRequest;
declare const pb_d_AddChildrenRequestSchema: typeof AddChildrenRequestSchema;
type pb_d_AddCloudFilesRequest = AddCloudFilesRequest;
declare const pb_d_AddCloudFilesRequestSchema: typeof AddCloudFilesRequestSchema;
type pb_d_AddCloudFilesResponse = AddCloudFilesResponse;
declare const pb_d_AddCloudFilesResponseSchema: typeof AddCloudFilesResponseSchema;
type pb_d_AddTagsRequest = AddTagsRequest;
declare const pb_d_AddTagsRequestSchema: typeof AddTagsRequestSchema;
type pb_d_AltServer = AltServer;
declare const pb_d_AltServerSchema: typeof AltServerSchema;
type pb_d_AltServerType = AltServerType;
declare const pb_d_AltServerType: typeof AltServerType;
declare const pb_d_AltServerTypeSchema: typeof AltServerTypeSchema;
type pb_d_AndroidPackage = AndroidPackage;
declare const pb_d_AndroidPackageSchema: typeof AndroidPackageSchema;
declare const pb_d_AndroidPackageService: typeof AndroidPackageService;
type pb_d_AuthOnlyRequest = AuthOnlyRequest;
declare const pb_d_AuthOnlyRequestSchema: typeof AuthOnlyRequestSchema;
type pb_d_Authorization = Authorization;
declare const pb_d_AuthorizationSchema: typeof AuthorizationSchema;
type pb_d_AuthorizeDeviceRequest = AuthorizeDeviceRequest;
declare const pb_d_AuthorizeDeviceRequestSchema: typeof AuthorizeDeviceRequestSchema;
type pb_d_AuthorizeDeviceResponse = AuthorizeDeviceResponse;
declare const pb_d_AuthorizeDeviceResponseSchema: typeof AuthorizeDeviceResponseSchema;
type pb_d_AvailableContent = AvailableContent;
declare const pb_d_AvailableContentSchema: typeof AvailableContentSchema;
declare const pb_d_AvnfsService: typeof AvnfsService;
type pb_d_AwsPlacesAddress = AwsPlacesAddress;
declare const pb_d_AwsPlacesAddressSchema: typeof AwsPlacesAddressSchema;
declare const pb_d_BlockadeService: typeof BlockadeService;
type pb_d_BlockadeSkyboxStyle = BlockadeSkyboxStyle;
type pb_d_BlockadeSkyboxStyleFamily = BlockadeSkyboxStyleFamily;
declare const pb_d_BlockadeSkyboxStyleFamilySchema: typeof BlockadeSkyboxStyleFamilySchema;
declare const pb_d_BlockadeSkyboxStyleSchema: typeof BlockadeSkyboxStyleSchema;
type pb_d_Category = Category;
declare const pb_d_CategorySchema: typeof CategorySchema;
declare const pb_d_CategoryService: typeof CategoryService;
type pb_d_Certificate = Certificate;
declare const pb_d_CertificateSchema: typeof CertificateSchema;
declare const pb_d_CertificateService: typeof CertificateService;
type pb_d_Channel = Channel;
declare const pb_d_ChannelSchema: typeof ChannelSchema;
declare const pb_d_ChannelService: typeof ChannelService;
type pb_d_CheckMediaCompatibilityRequest = CheckMediaCompatibilityRequest;
declare const pb_d_CheckMediaCompatibilityRequestSchema: typeof CheckMediaCompatibilityRequestSchema;
type pb_d_CheckMediaCompatibilityResponse = CheckMediaCompatibilityResponse;
declare const pb_d_CheckMediaCompatibilityResponseSchema: typeof CheckMediaCompatibilityResponseSchema;
type pb_d_ClientCredentials = ClientCredentials;
declare const pb_d_ClientCredentialsSchema: typeof ClientCredentialsSchema;
declare const pb_d_ClientService: typeof ClientService;
type pb_d_CloudFile = CloudFile;
declare const pb_d_CloudFileSchema: typeof CloudFileSchema;
declare const pb_d_CloudService: typeof CloudService;
type pb_d_CommandRequest = CommandRequest;
declare const pb_d_CommandRequestSchema: typeof CommandRequestSchema;
type pb_d_CommandResponse = CommandResponse;
declare const pb_d_CommandResponseSchema: typeof CommandResponseSchema;
type pb_d_ConnectionCredentials = ConnectionCredentials;
declare const pb_d_ConnectionCredentialsSchema: typeof ConnectionCredentialsSchema;
type pb_d_ConnectionInstance = ConnectionInstance;
declare const pb_d_ConnectionInstanceSchema: typeof ConnectionInstanceSchema;
type pb_d_ConnectionStatus = ConnectionStatus;
declare const pb_d_ConnectionStatus: typeof ConnectionStatus;
declare const pb_d_ConnectionStatusSchema: typeof ConnectionStatusSchema;
declare const pb_d_ContentService: typeof ContentService;
type pb_d_CopyEntityRequest = CopyEntityRequest;
declare const pb_d_CopyEntityRequestSchema: typeof CopyEntityRequestSchema;
type pb_d_Country = Country;
declare const pb_d_CountrySchema: typeof CountrySchema;
declare const pb_d_CountryService: typeof CountryService;
type pb_d_CreateAccessPointRequest = CreateAccessPointRequest;
declare const pb_d_CreateAccessPointRequestSchema: typeof CreateAccessPointRequestSchema;
type pb_d_CreateAccessPointResponse = CreateAccessPointResponse;
declare const pb_d_CreateAccessPointResponseSchema: typeof CreateAccessPointResponseSchema;
type pb_d_CreateActivityRequest = CreateActivityRequest;
declare const pb_d_CreateActivityRequestSchema: typeof CreateActivityRequestSchema;
type pb_d_CreateAndroidPackageRequest = CreateAndroidPackageRequest;
declare const pb_d_CreateAndroidPackageRequestSchema: typeof CreateAndroidPackageRequestSchema;
type pb_d_CreateAndroidPackageResponse = CreateAndroidPackageResponse;
declare const pb_d_CreateAndroidPackageResponseSchema: typeof CreateAndroidPackageResponseSchema;
type pb_d_CreateClientCredentialsRequest = CreateClientCredentialsRequest;
declare const pb_d_CreateClientCredentialsRequestSchema: typeof CreateClientCredentialsRequestSchema;
type pb_d_CreateClientCredentialsResponse = CreateClientCredentialsResponse;
declare const pb_d_CreateClientCredentialsResponseSchema: typeof CreateClientCredentialsResponseSchema;
type pb_d_CreateDimensionRequest = CreateDimensionRequest;
declare const pb_d_CreateDimensionRequestSchema: typeof CreateDimensionRequestSchema;
type pb_d_CreateDimensionResponse = CreateDimensionResponse;
declare const pb_d_CreateDimensionResponseSchema: typeof CreateDimensionResponseSchema;
type pb_d_CreateEntityRequest = CreateEntityRequest;
declare const pb_d_CreateEntityRequestSchema: typeof CreateEntityRequestSchema;
type pb_d_CreateEntityResponse = CreateEntityResponse;
declare const pb_d_CreateEntityResponseSchema: typeof CreateEntityResponseSchema;
type pb_d_CreateOrganizationRequest = CreateOrganizationRequest;
declare const pb_d_CreateOrganizationRequestSchema: typeof CreateOrganizationRequestSchema;
type pb_d_CreateOrganizationResponse = CreateOrganizationResponse;
declare const pb_d_CreateOrganizationResponseSchema: typeof CreateOrganizationResponseSchema;
type pb_d_CreatePassRequest = CreatePassRequest;
declare const pb_d_CreatePassRequestSchema: typeof CreatePassRequestSchema;
type pb_d_CreatePassResponse = CreatePassResponse;
declare const pb_d_CreatePassResponseSchema: typeof CreatePassResponseSchema;
type pb_d_DeleteAccessPointRequest = DeleteAccessPointRequest;
declare const pb_d_DeleteAccessPointRequestSchema: typeof DeleteAccessPointRequestSchema;
type pb_d_DeleteAndroidPackageRequest = DeleteAndroidPackageRequest;
declare const pb_d_DeleteAndroidPackageRequestSchema: typeof DeleteAndroidPackageRequestSchema;
type pb_d_DeleteDeviceRequest = DeleteDeviceRequest;
declare const pb_d_DeleteDeviceRequestSchema: typeof DeleteDeviceRequestSchema;
type pb_d_DeleteEntityRequest = DeleteEntityRequest;
declare const pb_d_DeleteEntityRequestSchema: typeof DeleteEntityRequestSchema;
type pb_d_DeletePassRequest = DeletePassRequest;
declare const pb_d_DeletePassRequestSchema: typeof DeletePassRequestSchema;
type pb_d_DelightexCreateLoginLinkRequest = DelightexCreateLoginLinkRequest;
declare const pb_d_DelightexCreateLoginLinkRequestSchema: typeof DelightexCreateLoginLinkRequestSchema;
type pb_d_DelightexCreateLoginLinkResponse = DelightexCreateLoginLinkResponse;
declare const pb_d_DelightexCreateLoginLinkResponseSchema: typeof DelightexCreateLoginLinkResponseSchema;
type pb_d_DelightexGetStatusRequest = DelightexGetStatusRequest;
declare const pb_d_DelightexGetStatusRequestSchema: typeof DelightexGetStatusRequestSchema;
type pb_d_DelightexLicenseState = DelightexLicenseState;
declare const pb_d_DelightexLicenseState: typeof DelightexLicenseState;
declare const pb_d_DelightexLicenseStateSchema: typeof DelightexLicenseStateSchema;
type pb_d_DelightexProvisionSchoolRequest = DelightexProvisionSchoolRequest;
declare const pb_d_DelightexProvisionSchoolRequestSchema: typeof DelightexProvisionSchoolRequestSchema;
type pb_d_DelightexProvisionUserRequest = DelightexProvisionUserRequest;
declare const pb_d_DelightexProvisionUserRequestSchema: typeof DelightexProvisionUserRequestSchema;
type pb_d_DelightexResolveShareLinkRequest = DelightexResolveShareLinkRequest;
declare const pb_d_DelightexResolveShareLinkRequestSchema: typeof DelightexResolveShareLinkRequestSchema;
type pb_d_DelightexResolveShareLinkResponse = DelightexResolveShareLinkResponse;
declare const pb_d_DelightexResolveShareLinkResponseSchema: typeof DelightexResolveShareLinkResponseSchema;
type pb_d_DelightexSchoolInfo = DelightexSchoolInfo;
declare const pb_d_DelightexSchoolInfoSchema: typeof DelightexSchoolInfoSchema;
type pb_d_DelightexSchoolState = DelightexSchoolState;
declare const pb_d_DelightexSchoolState: typeof DelightexSchoolState;
declare const pb_d_DelightexSchoolStateSchema: typeof DelightexSchoolStateSchema;
declare const pb_d_DelightexService: typeof DelightexService;
type pb_d_DelightexStatus = DelightexStatus;
declare const pb_d_DelightexStatusSchema: typeof DelightexStatusSchema;
type pb_d_DelightexUserState = DelightexUserState;
declare const pb_d_DelightexUserState: typeof DelightexUserState;
declare const pb_d_DelightexUserStateSchema: typeof DelightexUserStateSchema;
type pb_d_Device = Device;
type pb_d_DeviceCommand = DeviceCommand;
type pb_d_DeviceCommandMethod = DeviceCommandMethod;
declare const pb_d_DeviceCommandMethod: typeof DeviceCommandMethod;
declare const pb_d_DeviceCommandMethodSchema: typeof DeviceCommandMethodSchema;
declare const pb_d_DeviceCommandSchema: typeof DeviceCommandSchema;
type pb_d_DeviceCredentials = DeviceCredentials;
declare const pb_d_DeviceCredentialsSchema: typeof DeviceCredentialsSchema;
type pb_d_DeviceInfo = DeviceInfo;
declare const pb_d_DeviceInfoSchema: typeof DeviceInfoSchema;
type pb_d_DeviceLog = DeviceLog;
declare const pb_d_DeviceLogSchema: typeof DeviceLogSchema;
type pb_d_DeviceProperties = DeviceProperties;
declare const pb_d_DevicePropertiesSchema: typeof DevicePropertiesSchema;
declare const pb_d_DeviceSchema: typeof DeviceSchema;
declare const pb_d_DeviceService: typeof DeviceService;
type pb_d_DimensionBroadcast = DimensionBroadcast;
declare const pb_d_DimensionBroadcastSchema: typeof DimensionBroadcastSchema;
type pb_d_DimensionEvent = DimensionEvent;
declare const pb_d_DimensionEventSchema: typeof DimensionEventSchema;
type pb_d_DimensionInfo = DimensionInfo;
declare const pb_d_DimensionInfoSchema: typeof DimensionInfoSchema;
type pb_d_DimensionInstance = DimensionInstance;
declare const pb_d_DimensionInstanceSchema: typeof DimensionInstanceSchema;
type pb_d_DimensionOrigin = DimensionOrigin;
declare const pb_d_DimensionOriginSchema: typeof DimensionOriginSchema;
declare const pb_d_DimensionService: typeof DimensionService;
type pb_d_DimensionStatus = DimensionStatus;
declare const pb_d_DimensionStatusSchema: typeof DimensionStatusSchema;
type pb_d_EmbeddingTransform = EmbeddingTransform;
type pb_d_EmbeddingTransformRequest = EmbeddingTransformRequest;
declare const pb_d_EmbeddingTransformRequestSchema: typeof EmbeddingTransformRequestSchema;
type pb_d_EmbeddingTransformResponse = EmbeddingTransformResponse;
declare const pb_d_EmbeddingTransformResponseSchema: typeof EmbeddingTransformResponseSchema;
declare const pb_d_EmbeddingTransformSchema: typeof EmbeddingTransformSchema;
type pb_d_EnterRoomRequest = EnterRoomRequest;
declare const pb_d_EnterRoomRequestSchema: typeof EnterRoomRequestSchema;
type pb_d_EnterRoomResponse = EnterRoomResponse;
declare const pb_d_EnterRoomResponseSchema: typeof EnterRoomResponseSchema;
type pb_d_EntityInfo = EntityInfo;
type pb_d_EntityInfoListRequest = EntityInfoListRequest;
declare const pb_d_EntityInfoListRequestSchema: typeof EntityInfoListRequestSchema;
type pb_d_EntityInfoListResponse = EntityInfoListResponse;
declare const pb_d_EntityInfoListResponseSchema: typeof EntityInfoListResponseSchema;
declare const pb_d_EntityInfoSchema: typeof EntityInfoSchema;
type pb_d_EntityMetadata = EntityMetadata;
declare const pb_d_EntityMetadataSchema: typeof EntityMetadataSchema;
type pb_d_EntityProperties = EntityProperties;
declare const pb_d_EntityPropertiesSchema: typeof EntityPropertiesSchema;
type pb_d_EntityProperty = EntityProperty;
declare const pb_d_EntityProperty: typeof EntityProperty;
declare const pb_d_EntityPropertySchema: typeof EntityPropertySchema;
type pb_d_EntityPropertyState = EntityPropertyState;
declare const pb_d_EntityPropertyStateSchema: typeof EntityPropertyStateSchema;
type pb_d_EntityType = EntityType;
declare const pb_d_EntityType: typeof EntityType;
declare const pb_d_EntityTypeSchema: typeof EntityTypeSchema;
type pb_d_ExpiryStrategy = ExpiryStrategy;
declare const pb_d_ExpiryStrategy: typeof ExpiryStrategy;
declare const pb_d_ExpiryStrategySchema: typeof ExpiryStrategySchema;
type pb_d_GenerateSkyboxRequest = GenerateSkyboxRequest;
declare const pb_d_GenerateSkyboxRequestSchema: typeof GenerateSkyboxRequestSchema;
type pb_d_GenerateSkyboxResponse = GenerateSkyboxResponse;
declare const pb_d_GenerateSkyboxResponseSchema: typeof GenerateSkyboxResponseSchema;
type pb_d_GenerateSkyboxTask = GenerateSkyboxTask;
declare const pb_d_GenerateSkyboxTaskSchema: typeof GenerateSkyboxTaskSchema;
type pb_d_GeoAddress = GeoAddress;
declare const pb_d_GeoAddressSchema: typeof GeoAddressSchema;
type pb_d_GeoBounds = GeoBounds;
declare const pb_d_GeoBoundsSchema: typeof GeoBoundsSchema;
type pb_d_GeoContact = GeoContact;
declare const pb_d_GeoContactSchema: typeof GeoContactSchema;
type pb_d_GeoFeedCell = GeoFeedCell;
declare const pb_d_GeoFeedCellSchema: typeof GeoFeedCellSchema;
type pb_d_GeoLocation = GeoLocation;
declare const pb_d_GeoLocationSchema: typeof GeoLocationSchema;
type pb_d_GeoPlace = GeoPlace;
declare const pb_d_GeoPlaceSchema: typeof GeoPlaceSchema;
type pb_d_GeoPlaceType = GeoPlaceType;
declare const pb_d_GeoPlaceType: typeof GeoPlaceType;
declare const pb_d_GeoPlaceTypeSchema: typeof GeoPlaceTypeSchema;
declare const pb_d_GeoService: typeof GeoService;
type pb_d_GeoSuggestRequest = GeoSuggestRequest;
declare const pb_d_GeoSuggestRequestSchema: typeof GeoSuggestRequestSchema;
type pb_d_GeoSuggestResponse = GeoSuggestResponse;
declare const pb_d_GeoSuggestResponseSchema: typeof GeoSuggestResponseSchema;
type pb_d_GetAccessPointRequest = GetAccessPointRequest;
declare const pb_d_GetAccessPointRequestSchema: typeof GetAccessPointRequestSchema;
type pb_d_GetActivityTranscriptRequest = GetActivityTranscriptRequest;
declare const pb_d_GetActivityTranscriptRequestSchema: typeof GetActivityTranscriptRequestSchema;
type pb_d_GetAltServersRequest = GetAltServersRequest;
declare const pb_d_GetAltServersRequestSchema: typeof GetAltServersRequestSchema;
type pb_d_GetAltServersResponse = GetAltServersResponse;
declare const pb_d_GetAltServersResponseSchema: typeof GetAltServersResponseSchema;
type pb_d_GetAndroidPackageRequest = GetAndroidPackageRequest;
declare const pb_d_GetAndroidPackageRequestSchema: typeof GetAndroidPackageRequestSchema;
type pb_d_GetCapabilitiesRequest = GetCapabilitiesRequest;
declare const pb_d_GetCapabilitiesRequestSchema: typeof GetCapabilitiesRequestSchema;
type pb_d_GetCapabilitiesResponse = GetCapabilitiesResponse;
declare const pb_d_GetCapabilitiesResponseSchema: typeof GetCapabilitiesResponseSchema;
type pb_d_GetCloudFilesRequest = GetCloudFilesRequest;
declare const pb_d_GetCloudFilesRequestSchema: typeof GetCloudFilesRequestSchema;
type pb_d_GetCloudFilesResponse = GetCloudFilesResponse;
declare const pb_d_GetCloudFilesResponseSchema: typeof GetCloudFilesResponseSchema;
type pb_d_GetCloudSummaryRequest = GetCloudSummaryRequest;
declare const pb_d_GetCloudSummaryRequestSchema: typeof GetCloudSummaryRequestSchema;
type pb_d_GetCloudSummaryResponse = GetCloudSummaryResponse;
declare const pb_d_GetCloudSummaryResponseSchema: typeof GetCloudSummaryResponseSchema;
type pb_d_GetCountriesRequest = GetCountriesRequest;
declare const pb_d_GetCountriesRequestSchema: typeof GetCountriesRequestSchema;
type pb_d_GetCountriesResponse = GetCountriesResponse;
declare const pb_d_GetCountriesResponseSchema: typeof GetCountriesResponseSchema;
type pb_d_GetCountryRequest = GetCountryRequest;
declare const pb_d_GetCountryRequestSchema: typeof GetCountryRequestSchema;
type pb_d_GetCurrentUserRequest = GetCurrentUserRequest;
declare const pb_d_GetCurrentUserRequestSchema: typeof GetCurrentUserRequestSchema;
type pb_d_GetDeviceLogsRequest = GetDeviceLogsRequest;
declare const pb_d_GetDeviceLogsRequestSchema: typeof GetDeviceLogsRequestSchema;
type pb_d_GetDeviceLogsResponse = GetDeviceLogsResponse;
declare const pb_d_GetDeviceLogsResponseSchema: typeof GetDeviceLogsResponseSchema;
type pb_d_GetDevicePropertiesRequest = GetDevicePropertiesRequest;
declare const pb_d_GetDevicePropertiesRequestSchema: typeof GetDevicePropertiesRequestSchema;
type pb_d_GetDevicePropertiesResponse = GetDevicePropertiesResponse;
declare const pb_d_GetDevicePropertiesResponseSchema: typeof GetDevicePropertiesResponseSchema;
type pb_d_GetDeviceRequest = GetDeviceRequest;
declare const pb_d_GetDeviceRequestSchema: typeof GetDeviceRequestSchema;
type pb_d_GetDevicesForOrganizationRequest = GetDevicesForOrganizationRequest;
declare const pb_d_GetDevicesForOrganizationRequestSchema: typeof GetDevicesForOrganizationRequestSchema;
type pb_d_GetDevicesForOrganizationResponse = GetDevicesForOrganizationResponse;
declare const pb_d_GetDevicesForOrganizationResponseSchema: typeof GetDevicesForOrganizationResponseSchema;
type pb_d_GetDimensionRequest = GetDimensionRequest;
declare const pb_d_GetDimensionRequestSchema: typeof GetDimensionRequestSchema;
type pb_d_GetEntityPropertiesRequest = GetEntityPropertiesRequest;
declare const pb_d_GetEntityPropertiesRequestSchema: typeof GetEntityPropertiesRequestSchema;
type pb_d_GetEntityPropertiesResponse = GetEntityPropertiesResponse;
declare const pb_d_GetEntityPropertiesResponseSchema: typeof GetEntityPropertiesResponseSchema;
type pb_d_GetEntityRequest = GetEntityRequest;
declare const pb_d_GetEntityRequestSchema: typeof GetEntityRequestSchema;
type pb_d_GetFileUrlRequest = GetFileUrlRequest;
declare const pb_d_GetFileUrlRequestSchema: typeof GetFileUrlRequestSchema;
type pb_d_GetFileUrlResponse = GetFileUrlResponse;
declare const pb_d_GetFileUrlResponseSchema: typeof GetFileUrlResponseSchema;
type pb_d_GetGeoFeedRequest = GetGeoFeedRequest;
declare const pb_d_GetGeoFeedRequestSchema: typeof GetGeoFeedRequestSchema;
type pb_d_GetGeoFeedResponse = GetGeoFeedResponse;
declare const pb_d_GetGeoFeedResponseSchema: typeof GetGeoFeedResponseSchema;
type pb_d_GetGeoPlaceRequest = GetGeoPlaceRequest;
declare const pb_d_GetGeoPlaceRequestSchema: typeof GetGeoPlaceRequestSchema;
type pb_d_GetGeoPlaceResponse = GetGeoPlaceResponse;
declare const pb_d_GetGeoPlaceResponseSchema: typeof GetGeoPlaceResponseSchema;
type pb_d_GetGrantsResponse = GetGrantsResponse;
declare const pb_d_GetGrantsResponseSchema: typeof GetGrantsResponseSchema;
type pb_d_GetHostnameCertificatesRequest = GetHostnameCertificatesRequest;
declare const pb_d_GetHostnameCertificatesRequestSchema: typeof GetHostnameCertificatesRequestSchema;
type pb_d_GetImageMetadataResponse = GetImageMetadataResponse;
declare const pb_d_GetImageMetadataResponseSchema: typeof GetImageMetadataResponseSchema;
type pb_d_GetLanguagesRequest = GetLanguagesRequest;
declare const pb_d_GetLanguagesRequestSchema: typeof GetLanguagesRequestSchema;
type pb_d_GetLanguagesResponse = GetLanguagesResponse;
declare const pb_d_GetLanguagesResponseSchema: typeof GetLanguagesResponseSchema;
type pb_d_GetLighthouseServersRequest = GetLighthouseServersRequest;
declare const pb_d_GetLighthouseServersRequestSchema: typeof GetLighthouseServersRequestSchema;
type pb_d_GetLighthouseServersResponse = GetLighthouseServersResponse;
declare const pb_d_GetLighthouseServersResponseSchema: typeof GetLighthouseServersResponseSchema;
type pb_d_GetManifestRequest = GetManifestRequest;
declare const pb_d_GetManifestRequestSchema: typeof GetManifestRequestSchema;
type pb_d_GetMediaDeviceSpecsRequest = GetMediaDeviceSpecsRequest;
declare const pb_d_GetMediaDeviceSpecsRequestSchema: typeof GetMediaDeviceSpecsRequestSchema;
type pb_d_GetMediaDeviceSpecsResponse = GetMediaDeviceSpecsResponse;
declare const pb_d_GetMediaDeviceSpecsResponseSchema: typeof GetMediaDeviceSpecsResponseSchema;
type pb_d_GetMediaSpectrumRequest = GetMediaSpectrumRequest;
declare const pb_d_GetMediaSpectrumRequestSchema: typeof GetMediaSpectrumRequestSchema;
type pb_d_GetMediaSpectrumResponse = GetMediaSpectrumResponse;
declare const pb_d_GetMediaSpectrumResponseSchema: typeof GetMediaSpectrumResponseSchema;
type pb_d_GetMediaTranscriptRequest = GetMediaTranscriptRequest;
declare const pb_d_GetMediaTranscriptRequestSchema: typeof GetMediaTranscriptRequestSchema;
type pb_d_GetMediaTypeExtensionMapRequest = GetMediaTypeExtensionMapRequest;
declare const pb_d_GetMediaTypeExtensionMapRequestSchema: typeof GetMediaTypeExtensionMapRequestSchema;
type pb_d_GetMediaTypeExtensionMapResponse = GetMediaTypeExtensionMapResponse;
declare const pb_d_GetMediaTypeExtensionMapResponseSchema: typeof GetMediaTypeExtensionMapResponseSchema;
type pb_d_GetMetadataRequest = GetMetadataRequest;
declare const pb_d_GetMetadataRequestSchema: typeof GetMetadataRequestSchema;
type pb_d_GetMetadataResponse = GetMetadataResponse;
declare const pb_d_GetMetadataResponseSchema: typeof GetMetadataResponseSchema;
type pb_d_GetNewsRequest = GetNewsRequest;
declare const pb_d_GetNewsRequestSchema: typeof GetNewsRequestSchema;
type pb_d_GetNewsResponse = GetNewsResponse;
declare const pb_d_GetNewsResponseSchema: typeof GetNewsResponseSchema;
type pb_d_GetOrganizationAccessPointsRequest = GetOrganizationAccessPointsRequest;
declare const pb_d_GetOrganizationAccessPointsRequestSchema: typeof GetOrganizationAccessPointsRequestSchema;
type pb_d_GetOrganizationAccessPointsResponse = GetOrganizationAccessPointsResponse;
declare const pb_d_GetOrganizationAccessPointsResponseSchema: typeof GetOrganizationAccessPointsResponseSchema;
type pb_d_GetOrganizationGrantsRequest = GetOrganizationGrantsRequest;
declare const pb_d_GetOrganizationGrantsRequestSchema: typeof GetOrganizationGrantsRequestSchema;
type pb_d_GetOrganizationMembershipRequest = GetOrganizationMembershipRequest;
declare const pb_d_GetOrganizationMembershipRequestSchema: typeof GetOrganizationMembershipRequestSchema;
type pb_d_GetOrganizationMembershipResponse = GetOrganizationMembershipResponse;
declare const pb_d_GetOrganizationMembershipResponseSchema: typeof GetOrganizationMembershipResponseSchema;
type pb_d_GetOrganizationUsersRequest = GetOrganizationUsersRequest;
declare const pb_d_GetOrganizationUsersRequestSchema: typeof GetOrganizationUsersRequestSchema;
type pb_d_GetOrganizationUsersResponse = GetOrganizationUsersResponse;
declare const pb_d_GetOrganizationUsersResponseSchema: typeof GetOrganizationUsersResponseSchema;
type pb_d_GetPassRequest = GetPassRequest;
declare const pb_d_GetPassRequestSchema: typeof GetPassRequestSchema;
type pb_d_GetPassResponse = GetPassResponse;
declare const pb_d_GetPassResponseSchema: typeof GetPassResponseSchema;
type pb_d_GetPermissionsRequest = GetPermissionsRequest;
declare const pb_d_GetPermissionsRequestSchema: typeof GetPermissionsRequestSchema;
type pb_d_GetPermissionsResponse = GetPermissionsResponse;
declare const pb_d_GetPermissionsResponseSchema: typeof GetPermissionsResponseSchema;
type pb_d_GetPreviewImageRequest = GetPreviewImageRequest;
declare const pb_d_GetPreviewImageRequestSchema: typeof GetPreviewImageRequestSchema;
type pb_d_GetPreviewImageResponse = GetPreviewImageResponse;
declare const pb_d_GetPreviewImageResponseSchema: typeof GetPreviewImageResponseSchema;
type pb_d_GetRecentOrganizationsRequest = GetRecentOrganizationsRequest;
declare const pb_d_GetRecentOrganizationsRequestSchema: typeof GetRecentOrganizationsRequestSchema;
type pb_d_GetRecentOrganizationsResponse = GetRecentOrganizationsResponse;
declare const pb_d_GetRecentOrganizationsResponseSchema: typeof GetRecentOrganizationsResponseSchema;
type pb_d_GetRolesRequest = GetRolesRequest;
declare const pb_d_GetRolesRequestSchema: typeof GetRolesRequestSchema;
type pb_d_GetRolesResponse = GetRolesResponse;
declare const pb_d_GetRolesResponseSchema: typeof GetRolesResponseSchema;
type pb_d_GetRoomRequest = GetRoomRequest;
declare const pb_d_GetRoomRequestSchema: typeof GetRoomRequestSchema;
type pb_d_GetRoomResponse = GetRoomResponse;
declare const pb_d_GetRoomResponseSchema: typeof GetRoomResponseSchema;
type pb_d_GetSkyboxStyleFamiliesRequest = GetSkyboxStyleFamiliesRequest;
declare const pb_d_GetSkyboxStyleFamiliesRequestSchema: typeof GetSkyboxStyleFamiliesRequestSchema;
type pb_d_GetSkyboxStyleFamiliesResponse = GetSkyboxStyleFamiliesResponse;
declare const pb_d_GetSkyboxStyleFamiliesResponseSchema: typeof GetSkyboxStyleFamiliesResponseSchema;
type pb_d_GetSubordinateOrganizationsRequest = GetSubordinateOrganizationsRequest;
declare const pb_d_GetSubordinateOrganizationsRequestSchema: typeof GetSubordinateOrganizationsRequestSchema;
type pb_d_GetSubordinateOrganizationsResponse = GetSubordinateOrganizationsResponse;
declare const pb_d_GetSubordinateOrganizationsResponseSchema: typeof GetSubordinateOrganizationsResponseSchema;
type pb_d_GetTagGroupRequest = GetTagGroupRequest;
declare const pb_d_GetTagGroupRequestSchema: typeof GetTagGroupRequestSchema;
type pb_d_GetTagGroupResponse = GetTagGroupResponse;
declare const pb_d_GetTagGroupResponseSchema: typeof GetTagGroupResponseSchema;
type pb_d_GetTagsRequest = GetTagsRequest;
declare const pb_d_GetTagsRequestSchema: typeof GetTagsRequestSchema;
type pb_d_GetTagsResponse = GetTagsResponse;
declare const pb_d_GetTagsResponseSchema: typeof GetTagsResponseSchema;
type pb_d_GetTranscriptResponse = GetTranscriptResponse;
declare const pb_d_GetTranscriptResponseSchema: typeof GetTranscriptResponseSchema;
type pb_d_GetUserGrantsRequest = GetUserGrantsRequest;
declare const pb_d_GetUserGrantsRequestSchema: typeof GetUserGrantsRequestSchema;
type pb_d_GetVideoMetadataResponse = GetVideoMetadataResponse;
declare const pb_d_GetVideoMetadataResponseSchema: typeof GetVideoMetadataResponseSchema;
type pb_d_GrantInfo = GrantInfo;
declare const pb_d_GrantInfoSchema: typeof GrantInfoSchema;
declare const pb_d_GrantService: typeof GrantService;
type pb_d_GrantType = GrantType;
declare const pb_d_GrantType: typeof GrantType;
declare const pb_d_GrantTypeSchema: typeof GrantTypeSchema;
type pb_d_HeaderField = HeaderField;
declare const pb_d_HeaderFieldSchema: typeof HeaderFieldSchema;
declare const pb_d_Health: typeof Health;
type pb_d_HealthCheckRequest = HealthCheckRequest;
declare const pb_d_HealthCheckRequestSchema: typeof HealthCheckRequestSchema;
type pb_d_HealthCheckResponse = HealthCheckResponse;
declare const pb_d_HealthCheckResponseSchema: typeof HealthCheckResponseSchema;
type pb_d_HealthCheckResponse_ServingStatus = HealthCheckResponse_ServingStatus;
declare const pb_d_HealthCheckResponse_ServingStatus: typeof HealthCheckResponse_ServingStatus;
declare const pb_d_HealthCheckResponse_ServingStatusSchema: typeof HealthCheckResponse_ServingStatusSchema;
type pb_d_Hyperlink = Hyperlink;
declare const pb_d_HyperlinkSchema: typeof HyperlinkSchema;
type pb_d_IdentityProvider = IdentityProvider;
declare const pb_d_IdentityProvider: typeof IdentityProvider;
declare const pb_d_IdentityProviderSchema: typeof IdentityProviderSchema;
type pb_d_ImportUrlRequest = ImportUrlRequest;
declare const pb_d_ImportUrlRequestSchema: typeof ImportUrlRequestSchema;
type pb_d_ImportUrlResponse = ImportUrlResponse;
declare const pb_d_ImportUrlResponseSchema: typeof ImportUrlResponseSchema;
declare const pb_d_InfoService: typeof InfoService;
type pb_d_InteractionPermissions = InteractionPermissions;
declare const pb_d_InteractionPermissionsSchema: typeof InteractionPermissionsSchema;
type pb_d_IsPermittedRequest = IsPermittedRequest;
declare const pb_d_IsPermittedRequestSchema: typeof IsPermittedRequestSchema;
type pb_d_IsPermittedResponse = IsPermittedResponse;
declare const pb_d_IsPermittedResponseSchema: typeof IsPermittedResponseSchema;
type pb_d_Job = Job;
declare const pb_d_JobSchema: typeof JobSchema;
type pb_d_JoinDimensionRequest = JoinDimensionRequest;
declare const pb_d_JoinDimensionRequestSchema: typeof JoinDimensionRequestSchema;
type pb_d_JoinOrganizationRequest = JoinOrganizationRequest;
declare const pb_d_JoinOrganizationRequestSchema: typeof JoinOrganizationRequestSchema;
type pb_d_JoinOrganizationResponse = JoinOrganizationResponse;
declare const pb_d_JoinOrganizationResponseSchema: typeof JoinOrganizationResponseSchema;
declare const pb_d_KtxService: typeof KtxService;
type pb_d_Language = Language;
declare const pb_d_LanguageSchema: typeof LanguageSchema;
declare const pb_d_LanguageService: typeof LanguageService;
type pb_d_LessonContext = LessonContext;
declare const pb_d_LessonContextSchema: typeof LessonContextSchema;
type pb_d_LessonFocus = LessonFocus;
declare const pb_d_LessonFocusSchema: typeof LessonFocusSchema;
type pb_d_LighthouseServer = LighthouseServer;
declare const pb_d_LighthouseServerSchema: typeof LighthouseServerSchema;
type pb_d_MatchActivityFromCloudRequest = MatchActivityFromCloudRequest;
declare const pb_d_MatchActivityFromCloudRequestSchema: typeof MatchActivityFromCloudRequestSchema;
type pb_d_MatchActivityFromFilesRequest = MatchActivityFromFilesRequest;
declare const pb_d_MatchActivityFromFilesRequestSchema: typeof MatchActivityFromFilesRequestSchema;
type pb_d_MatchActivityFromUrlRequest = MatchActivityFromUrlRequest;
declare const pb_d_MatchActivityFromUrlRequestSchema: typeof MatchActivityFromUrlRequestSchema;
type pb_d_MatchActivityResponse = MatchActivityResponse;
declare const pb_d_MatchActivityResponseSchema: typeof MatchActivityResponseSchema;
type pb_d_MediaCompatibilityArea = MediaCompatibilityArea;
declare const pb_d_MediaCompatibilityArea: typeof MediaCompatibilityArea;
declare const pb_d_MediaCompatibilityAreaSchema: typeof MediaCompatibilityAreaSchema;
type pb_d_MediaCompatibilityIssue = MediaCompatibilityIssue;
declare const pb_d_MediaCompatibilityIssueSchema: typeof MediaCompatibilityIssueSchema;
type pb_d_MediaCompatibilityReason = MediaCompatibilityReason;
declare const pb_d_MediaCompatibilityReason: typeof MediaCompatibilityReason;
declare const pb_d_MediaCompatibilityReasonSchema: typeof MediaCompatibilityReasonSchema;
type pb_d_MediaDeviceSpec = MediaDeviceSpec;
declare const pb_d_MediaDeviceSpecSchema: typeof MediaDeviceSpecSchema;
type pb_d_MediaFormatMetadata = MediaFormatMetadata;
declare const pb_d_MediaFormatMetadataSchema: typeof MediaFormatMetadataSchema;
type pb_d_MediaFormatSpec = MediaFormatSpec;
declare const pb_d_MediaFormatSpecSchema: typeof MediaFormatSpecSchema;
type pb_d_MediaRational = MediaRational;
declare const pb_d_MediaRationalSchema: typeof MediaRationalSchema;
declare const pb_d_MediaService: typeof MediaService;
type pb_d_MediaSpectrum = MediaSpectrum;
declare const pb_d_MediaSpectrumSchema: typeof MediaSpectrumSchema;
type pb_d_MediaStreamMetadata = MediaStreamMetadata;
declare const pb_d_MediaStreamMetadataSchema: typeof MediaStreamMetadataSchema;
type pb_d_MediaStreamType = MediaStreamType;
declare const pb_d_MediaStreamType: typeof MediaStreamType;
declare const pb_d_MediaStreamTypeSchema: typeof MediaStreamTypeSchema;
type pb_d_MediaTypeExtension = MediaTypeExtension;
declare const pb_d_MediaTypeExtensionSchema: typeof MediaTypeExtensionSchema;
type pb_d_MetadataFilter = MetadataFilter;
type pb_d_MetadataFilterCondition = MetadataFilterCondition;
declare const pb_d_MetadataFilterCondition: typeof MetadataFilterCondition;
declare const pb_d_MetadataFilterConditionSchema: typeof MetadataFilterConditionSchema;
declare const pb_d_MetadataFilterSchema: typeof MetadataFilterSchema;
type pb_d_MetadataRequest = MetadataRequest;
declare const pb_d_MetadataRequestSchema: typeof MetadataRequestSchema;
type pb_d_NeighborServer = NeighborServer;
declare const pb_d_NeighborServerSchema: typeof NeighborServerSchema;
declare const pb_d_NeighborService: typeof NeighborService;
type pb_d_OpenRoomRequest = OpenRoomRequest;
declare const pb_d_OpenRoomRequestSchema: typeof OpenRoomRequestSchema;
type pb_d_OpenRoomResponse = OpenRoomResponse;
declare const pb_d_OpenRoomResponseSchema: typeof OpenRoomResponseSchema;
type pb_d_OperationState = OperationState;
declare const pb_d_OperationState: typeof OperationState;
declare const pb_d_OperationStateSchema: typeof OperationStateSchema;
type pb_d_OrderClause = OrderClause;
declare const pb_d_OrderClauseSchema: typeof OrderClauseSchema;
type pb_d_Organization = Organization;
type pb_d_OrganizationInfo = OrganizationInfo;
declare const pb_d_OrganizationInfoSchema: typeof OrganizationInfoSchema;
type pb_d_OrganizationMembership = OrganizationMembership;
declare const pb_d_OrganizationMembershipSchema: typeof OrganizationMembershipSchema;
declare const pb_d_OrganizationSchema: typeof OrganizationSchema;
declare const pb_d_OrganizationService: typeof OrganizationService;
type pb_d_OrganizationSpec = OrganizationSpec;
declare const pb_d_OrganizationSpecSchema: typeof OrganizationSpecSchema;
type pb_d_OrganizationUser = OrganizationUser;
declare const pb_d_OrganizationUserSchema: typeof OrganizationUserSchema;
type pb_d_PartnerSession = PartnerSession;
declare const pb_d_PartnerSessionSchema: typeof PartnerSessionSchema;
type pb_d_Pass = Pass;
declare const pb_d_PassSchema: typeof PassSchema;
declare const pb_d_PassService: typeof PassService;
type pb_d_Permission = Permission;
declare const pb_d_PermissionSchema: typeof PermissionSchema;
type pb_d_PermissionScope = PermissionScope;
declare const pb_d_PermissionScope: typeof PermissionScope;
declare const pb_d_PermissionScopeSchema: typeof PermissionScopeSchema;
declare const pb_d_PermissionService: typeof PermissionService;
type pb_d_PhonemeDetail = PhonemeDetail;
declare const pb_d_PhonemeDetailSchema: typeof PhonemeDetailSchema;
type pb_d_PresenceInfo = PresenceInfo;
declare const pb_d_PresenceInfoSchema: typeof PresenceInfoSchema;
type pb_d_PresenceState = PresenceState;
declare const pb_d_PresenceState: typeof PresenceState;
declare const pb_d_PresenceStateSchema: typeof PresenceStateSchema;
type pb_d_PresenceUpdate = PresenceUpdate;
declare const pb_d_PresenceUpdateSchema: typeof PresenceUpdateSchema;
type pb_d_Profile = Profile;
declare const pb_d_ProfileSchema: typeof ProfileSchema;
declare const pb_d_ProfileService: typeof ProfileService;
type pb_d_PronunciationAnalysisRequest = PronunciationAnalysisRequest;
declare const pb_d_PronunciationAnalysisRequestSchema: typeof PronunciationAnalysisRequestSchema;
type pb_d_PronunciationAnalysisResponse = PronunciationAnalysisResponse;
declare const pb_d_PronunciationAnalysisResponseSchema: typeof PronunciationAnalysisResponseSchema;
type pb_d_Quaternion = Quaternion;
declare const pb_d_QuaternionSchema: typeof QuaternionSchema;
type pb_d_RecordActionRequest = RecordActionRequest;
declare const pb_d_RecordActionRequestSchema: typeof RecordActionRequestSchema;
type pb_d_RecordFeedbackRequest = RecordFeedbackRequest;
declare const pb_d_RecordFeedbackRequestSchema: typeof RecordFeedbackRequestSchema;
type pb_d_RecordLogRequest = RecordLogRequest;
declare const pb_d_RecordLogRequestSchema: typeof RecordLogRequestSchema;
type pb_d_RegisterLighthouseServerRequest = RegisterLighthouseServerRequest;
declare const pb_d_RegisterLighthouseServerRequestSchema: typeof RegisterLighthouseServerRequestSchema;
type pb_d_RegisterLighthouseServerResponse = RegisterLighthouseServerResponse;
declare const pb_d_RegisterLighthouseServerResponseSchema: typeof RegisterLighthouseServerResponseSchema;
type pb_d_RegisterNeighborServerRequest = RegisterNeighborServerRequest;
declare const pb_d_RegisterNeighborServerRequestSchema: typeof RegisterNeighborServerRequestSchema;
type pb_d_RegisterNeighborServerResponse = RegisterNeighborServerResponse;
declare const pb_d_RegisterNeighborServerResponseSchema: typeof RegisterNeighborServerResponseSchema;
type pb_d_ReleaseChannel = ReleaseChannel;
declare const pb_d_ReleaseChannel: typeof ReleaseChannel;
declare const pb_d_ReleaseChannelSchema: typeof ReleaseChannelSchema;
type pb_d_RemoveActivityFilesRequest = RemoveActivityFilesRequest;
declare const pb_d_RemoveActivityFilesRequestSchema: typeof RemoveActivityFilesRequestSchema;
type pb_d_RemoveChildrenRequest = RemoveChildrenRequest;
declare const pb_d_RemoveChildrenRequestSchema: typeof RemoveChildrenRequestSchema;
type pb_d_RemoveCloudFilesRequest = RemoveCloudFilesRequest;
declare const pb_d_RemoveCloudFilesRequestSchema: typeof RemoveCloudFilesRequestSchema;
type pb_d_RemoveOrganizationUserRequest = RemoveOrganizationUserRequest;
declare const pb_d_RemoveOrganizationUserRequestSchema: typeof RemoveOrganizationUserRequestSchema;
type pb_d_RemoveTagsRequest = RemoveTagsRequest;
declare const pb_d_RemoveTagsRequestSchema: typeof RemoveTagsRequestSchema;
type pb_d_ResolveAssetRequest = ResolveAssetRequest;
declare const pb_d_ResolveAssetRequestSchema: typeof ResolveAssetRequestSchema;
type pb_d_ResolveMediaRequest = ResolveMediaRequest;
declare const pb_d_ResolveMediaRequestSchema: typeof ResolveMediaRequestSchema;
type pb_d_ResolveMediaResponse = ResolveMediaResponse;
declare const pb_d_ResolveMediaResponseSchema: typeof ResolveMediaResponseSchema;
type pb_d_Role = Role;
declare const pb_d_RoleSchema: typeof RoleSchema;
declare const pb_d_RoleService: typeof RoleService;
type pb_d_RoomInfo = RoomInfo;
declare const pb_d_RoomInfoSchema: typeof RoomInfoSchema;
declare const pb_d_RoomService: typeof RoomService;
type pb_d_SearchCloudFilesRequest = SearchCloudFilesRequest;
declare const pb_d_SearchCloudFilesRequestSchema: typeof SearchCloudFilesRequestSchema;
type pb_d_SearchCloudFilesResponse = SearchCloudFilesResponse;
declare const pb_d_SearchCloudFilesResponseSchema: typeof SearchCloudFilesResponseSchema;
type pb_d_SearchFlags = SearchFlags;
declare const pb_d_SearchFlags: typeof SearchFlags;
declare const pb_d_SearchFlagsSchema: typeof SearchFlagsSchema;
type pb_d_SearchImagesRequest = SearchImagesRequest;
declare const pb_d_SearchImagesRequestSchema: typeof SearchImagesRequestSchema;
type pb_d_SearchImagesResponse = SearchImagesResponse;
declare const pb_d_SearchImagesResponseSchema: typeof SearchImagesResponseSchema;
type pb_d_SearchMemberOrganizationsRequest = SearchMemberOrganizationsRequest;
declare const pb_d_SearchMemberOrganizationsRequestSchema: typeof SearchMemberOrganizationsRequestSchema;
type pb_d_SearchMemberOrganizationsResponse = SearchMemberOrganizationsResponse;
declare const pb_d_SearchMemberOrganizationsResponseSchema: typeof SearchMemberOrganizationsResponseSchema;
type pb_d_SetActivityTranscriptRequest = SetActivityTranscriptRequest;
declare const pb_d_SetActivityTranscriptRequestSchema: typeof SetActivityTranscriptRequestSchema;
type pb_d_SetDeviceCommandRequest = SetDeviceCommandRequest;
declare const pb_d_SetDeviceCommandRequestSchema: typeof SetDeviceCommandRequestSchema;
type pb_d_SetDevicePropertiesRequest = SetDevicePropertiesRequest;
declare const pb_d_SetDevicePropertiesRequestSchema: typeof SetDevicePropertiesRequestSchema;
type pb_d_SetEntityPropertiesRequest = SetEntityPropertiesRequest;
declare const pb_d_SetEntityPropertiesRequestSchema: typeof SetEntityPropertiesRequestSchema;
type pb_d_SetLessonContextRequest = SetLessonContextRequest;
declare const pb_d_SetLessonContextRequestSchema: typeof SetLessonContextRequestSchema;
type pb_d_SetLessonContextResponse = SetLessonContextResponse;
declare const pb_d_SetLessonContextResponseSchema: typeof SetLessonContextResponseSchema;
type pb_d_SetOrganizationMembershipRequest = SetOrganizationMembershipRequest;
declare const pb_d_SetOrganizationMembershipRequestSchema: typeof SetOrganizationMembershipRequestSchema;
type pb_d_SortOrder = SortOrder;
declare const pb_d_SortOrder: typeof SortOrder;
declare const pb_d_SortOrderSchema: typeof SortOrderSchema;
type pb_d_Speaker = Speaker;
type pb_d_SpeakerGender = SpeakerGender;
declare const pb_d_SpeakerGender: typeof SpeakerGender;
declare const pb_d_SpeakerGenderSchema: typeof SpeakerGenderSchema;
declare const pb_d_SpeakerSchema: typeof SpeakerSchema;
type pb_d_Speech = Speech;
type pb_d_SpeechFileFormat = SpeechFileFormat;
declare const pb_d_SpeechFileFormat: typeof SpeechFileFormat;
declare const pb_d_SpeechFileFormatSchema: typeof SpeechFileFormatSchema;
type pb_d_SpeechFileSpec = SpeechFileSpec;
declare const pb_d_SpeechFileSpecSchema: typeof SpeechFileSpecSchema;
type pb_d_SpeechFlag = SpeechFlag;
declare const pb_d_SpeechFlag: typeof SpeechFlag;
declare const pb_d_SpeechFlagSchema: typeof SpeechFlagSchema;
type pb_d_SpeechMark = SpeechMark;
declare const pb_d_SpeechMarkSchema: typeof SpeechMarkSchema;
type pb_d_SpeechMarkType = SpeechMarkType;
declare const pb_d_SpeechMarkType: typeof SpeechMarkType;
declare const pb_d_SpeechMarkTypeSchema: typeof SpeechMarkTypeSchema;
type pb_d_SpeechMarks = SpeechMarks;
declare const pb_d_SpeechMarksSchema: typeof SpeechMarksSchema;
declare const pb_d_SpeechSchema: typeof SpeechSchema;
type pb_d_SpeechSegment = SpeechSegment;
declare const pb_d_SpeechSegmentSchema: typeof SpeechSegmentSchema;
declare const pb_d_SpeechService: typeof SpeechService;
type pb_d_SubmitCommunityCategoryRequest = SubmitCommunityCategoryRequest;
declare const pb_d_SubmitCommunityCategoryRequestSchema: typeof SubmitCommunityCategoryRequestSchema;
type pb_d_SynthesizeSpeechRequest = SynthesizeSpeechRequest;
declare const pb_d_SynthesizeSpeechRequestSchema: typeof SynthesizeSpeechRequestSchema;
type pb_d_SynthesizeSpeechResponse = SynthesizeSpeechResponse;
declare const pb_d_SynthesizeSpeechResponseSchema: typeof SynthesizeSpeechResponseSchema;
type pb_d_SynthesizeTranscriptRequest = SynthesizeTranscriptRequest;
declare const pb_d_SynthesizeTranscriptRequestSchema: typeof SynthesizeTranscriptRequestSchema;
type pb_d_SynthesizeTranscriptResponse = SynthesizeTranscriptResponse;
declare const pb_d_SynthesizeTranscriptResponseSchema: typeof SynthesizeTranscriptResponseSchema;
type pb_d_Tag = Tag;
type pb_d_TagFilter = TagFilter;
type pb_d_TagFilterCondition = TagFilterCondition;
declare const pb_d_TagFilterCondition: typeof TagFilterCondition;
declare const pb_d_TagFilterConditionSchema: typeof TagFilterConditionSchema;
declare const pb_d_TagFilterSchema: typeof TagFilterSchema;
type pb_d_TagGroup = TagGroup;
type pb_d_TagGroupId = TagGroupId;
declare const pb_d_TagGroupId: typeof TagGroupId;
declare const pb_d_TagGroupIdSchema: typeof TagGroupIdSchema;
declare const pb_d_TagGroupSchema: typeof TagGroupSchema;
type pb_d_TagId = TagId;
declare const pb_d_TagId: typeof TagId;
declare const pb_d_TagIdSchema: typeof TagIdSchema;
declare const pb_d_TagSchema: typeof TagSchema;
declare const pb_d_TagService: typeof TagService;
type pb_d_TextDirection = TextDirection;
declare const pb_d_TextDirection: typeof TextDirection;
declare const pb_d_TextDirectionSchema: typeof TextDirectionSchema;
type pb_d_TextSearch = TextSearch;
declare const pb_d_TextSearchSchema: typeof TextSearchSchema;
declare const pb_d_ThingLinkService: typeof ThingLinkService;
declare const pb_d_ThreeSixtyCitiesService: typeof ThreeSixtyCitiesService;
type pb_d_ToKtxParameters = ToKtxParameters;
declare const pb_d_ToKtxParametersSchema: typeof ToKtxParametersSchema;
type pb_d_ToKtxRequest = ToKtxRequest;
declare const pb_d_ToKtxRequestSchema: typeof ToKtxRequestSchema;
type pb_d_ToKtxResponse = ToKtxResponse;
declare const pb_d_ToKtxResponseSchema: typeof ToKtxResponseSchema;
type pb_d_TranscodeImageRequest = TranscodeImageRequest;
declare const pb_d_TranscodeImageRequestSchema: typeof TranscodeImageRequestSchema;
type pb_d_TranscodeImageResponse = TranscodeImageResponse;
declare const pb_d_TranscodeImageResponseSchema: typeof TranscodeImageResponseSchema;
type pb_d_TranscodeImageSpec = TranscodeImageSpec;
declare const pb_d_TranscodeImageSpecSchema: typeof TranscodeImageSpecSchema;
type pb_d_TranscodeVideoRequest = TranscodeVideoRequest;
declare const pb_d_TranscodeVideoRequestSchema: typeof TranscodeVideoRequestSchema;
type pb_d_TranscodeVideoResponse = TranscodeVideoResponse;
declare const pb_d_TranscodeVideoResponseSchema: typeof TranscodeVideoResponseSchema;
type pb_d_TranscodeVideoResult = TranscodeVideoResult;
declare const pb_d_TranscodeVideoResultSchema: typeof TranscodeVideoResultSchema;
type pb_d_TranscodeVideoTask = TranscodeVideoTask;
declare const pb_d_TranscodeVideoTaskSchema: typeof TranscodeVideoTaskSchema;
type pb_d_Transcript = Transcript;
declare const pb_d_TranscriptSchema: typeof TranscriptSchema;
type pb_d_TranscriptSegment = TranscriptSegment;
declare const pb_d_TranscriptSegmentSchema: typeof TranscriptSegmentSchema;
declare const pb_d_TranscriptionService: typeof TranscriptionService;
type pb_d_TransformMediaRequest = TransformMediaRequest;
declare const pb_d_TransformMediaRequestSchema: typeof TransformMediaRequestSchema;
type pb_d_TransformMediaResponse = TransformMediaResponse;
declare const pb_d_TransformMediaResponseSchema: typeof TransformMediaResponseSchema;
type pb_d_TranslationFlag = TranslationFlag;
declare const pb_d_TranslationFlag: typeof TranslationFlag;
declare const pb_d_TranslationFlagSchema: typeof TranslationFlagSchema;
type pb_d_TranslationFormat = TranslationFormat;
declare const pb_d_TranslationFormat: typeof TranslationFormat;
declare const pb_d_TranslationFormatSchema: typeof TranslationFormatSchema;
type pb_d_TranslationLookupRequest = TranslationLookupRequest;
declare const pb_d_TranslationLookupRequestSchema: typeof TranslationLookupRequestSchema;
type pb_d_TranslationLookupResponse = TranslationLookupResponse;
declare const pb_d_TranslationLookupResponseSchema: typeof TranslationLookupResponseSchema;
type pb_d_TranslationOrigin = TranslationOrigin;
declare const pb_d_TranslationOrigin: typeof TranslationOrigin;
declare const pb_d_TranslationOriginSchema: typeof TranslationOriginSchema;
type pb_d_TranslationRequest = TranslationRequest;
declare const pb_d_TranslationRequestSchema: typeof TranslationRequestSchema;
type pb_d_TranslationResponse = TranslationResponse;
declare const pb_d_TranslationResponseSchema: typeof TranslationResponseSchema;
declare const pb_d_TranslationService: typeof TranslationService;
type pb_d_TranslationSpec = TranslationSpec;
declare const pb_d_TranslationSpecSchema: typeof TranslationSpecSchema;
type pb_d_TranslationUpdateRequest = TranslationUpdateRequest;
declare const pb_d_TranslationUpdateRequestSchema: typeof TranslationUpdateRequestSchema;
type pb_d_UploadManifest = UploadManifest;
declare const pb_d_UploadManifestSchema: typeof UploadManifestSchema;
type pb_d_User = User;
type pb_d_UserInterfaceFeatures = UserInterfaceFeatures;
declare const pb_d_UserInterfaceFeaturesSchema: typeof UserInterfaceFeaturesSchema;
declare const pb_d_UserSchema: typeof UserSchema;
declare const pb_d_UserService: typeof UserService;
type pb_d_Vector3 = Vector3;
declare const pb_d_Vector3Schema: typeof Vector3Schema;
type pb_d_WifiAccessPoint = WifiAccessPoint;
type pb_d_WifiAccessPointInfo = WifiAccessPointInfo;
declare const pb_d_WifiAccessPointInfoSchema: typeof WifiAccessPointInfoSchema;
declare const pb_d_WifiAccessPointSchema: typeof WifiAccessPointSchema;
declare const pb_d_WifiAccessPointService: typeof WifiAccessPointService;
type pb_d_WifiClientCredential = WifiClientCredential;
declare const pb_d_WifiClientCredential: typeof WifiClientCredential;
declare const pb_d_WifiClientCredentialSchema: typeof WifiClientCredentialSchema;
type pb_d_WifiEncryption = WifiEncryption;
declare const pb_d_WifiEncryption: typeof WifiEncryption;
declare const pb_d_WifiEncryptionSchema: typeof WifiEncryptionSchema;
type pb_d_WifiPhase2 = WifiPhase2;
declare const pb_d_WifiPhase2: typeof WifiPhase2;
declare const pb_d_WifiPhase2Schema: typeof WifiPhase2Schema;
declare const pb_d_file_avn_connect_v1_activities: typeof file_avn_connect_v1_activities;
declare const pb_d_file_avn_connect_v1_authorization: typeof file_avn_connect_v1_authorization;
declare const pb_d_file_avn_connect_v1_avnfs: typeof file_avn_connect_v1_avnfs;
declare const pb_d_file_avn_connect_v1_blockade: typeof file_avn_connect_v1_blockade;
declare const pb_d_file_avn_connect_v1_categories: typeof file_avn_connect_v1_categories;
declare const pb_d_file_avn_connect_v1_certificates: typeof file_avn_connect_v1_certificates;
declare const pb_d_file_avn_connect_v1_channels: typeof file_avn_connect_v1_channels;
declare const pb_d_file_avn_connect_v1_clients: typeof file_avn_connect_v1_clients;
declare const pb_d_file_avn_connect_v1_cloud: typeof file_avn_connect_v1_cloud;
declare const pb_d_file_avn_connect_v1_command: typeof file_avn_connect_v1_command;
declare const pb_d_file_avn_connect_v1_content: typeof file_avn_connect_v1_content;
declare const pb_d_file_avn_connect_v1_countries: typeof file_avn_connect_v1_countries;
declare const pb_d_file_avn_connect_v1_credentials: typeof file_avn_connect_v1_credentials;
declare const pb_d_file_avn_connect_v1_delightex: typeof file_avn_connect_v1_delightex;
declare const pb_d_file_avn_connect_v1_devices: typeof file_avn_connect_v1_devices;
declare const pb_d_file_avn_connect_v1_dimensions: typeof file_avn_connect_v1_dimensions;
declare const pb_d_file_avn_connect_v1_embedding: typeof file_avn_connect_v1_embedding;
declare const pb_d_file_avn_connect_v1_entities: typeof file_avn_connect_v1_entities;
declare const pb_d_file_avn_connect_v1_features: typeof file_avn_connect_v1_features;
declare const pb_d_file_avn_connect_v1_geo: typeof file_avn_connect_v1_geo;
declare const pb_d_file_avn_connect_v1_geometry: typeof file_avn_connect_v1_geometry;
declare const pb_d_file_avn_connect_v1_grants: typeof file_avn_connect_v1_grants;
declare const pb_d_file_avn_connect_v1_http: typeof file_avn_connect_v1_http;
declare const pb_d_file_avn_connect_v1_info: typeof file_avn_connect_v1_info;
declare const pb_d_file_avn_connect_v1_interaction_permissions: typeof file_avn_connect_v1_interaction_permissions;
declare const pb_d_file_avn_connect_v1_ktx: typeof file_avn_connect_v1_ktx;
declare const pb_d_file_avn_connect_v1_languages: typeof file_avn_connect_v1_languages;
declare const pb_d_file_avn_connect_v1_lesson_context: typeof file_avn_connect_v1_lesson_context;
declare const pb_d_file_avn_connect_v1_media: typeof file_avn_connect_v1_media;
declare const pb_d_file_avn_connect_v1_metadata: typeof file_avn_connect_v1_metadata;
declare const pb_d_file_avn_connect_v1_neighbors: typeof file_avn_connect_v1_neighbors;
declare const pb_d_file_avn_connect_v1_operations: typeof file_avn_connect_v1_operations;
declare const pb_d_file_avn_connect_v1_organization_membership: typeof file_avn_connect_v1_organization_membership;
declare const pb_d_file_avn_connect_v1_organizations: typeof file_avn_connect_v1_organizations;
declare const pb_d_file_avn_connect_v1_packages: typeof file_avn_connect_v1_packages;
declare const pb_d_file_avn_connect_v1_partners: typeof file_avn_connect_v1_partners;
declare const pb_d_file_avn_connect_v1_passes: typeof file_avn_connect_v1_passes;
declare const pb_d_file_avn_connect_v1_permissions: typeof file_avn_connect_v1_permissions;
declare const pb_d_file_avn_connect_v1_presence: typeof file_avn_connect_v1_presence;
declare const pb_d_file_avn_connect_v1_profiles: typeof file_avn_connect_v1_profiles;
declare const pb_d_file_avn_connect_v1_properties: typeof file_avn_connect_v1_properties;
declare const pb_d_file_avn_connect_v1_roles: typeof file_avn_connect_v1_roles;
declare const pb_d_file_avn_connect_v1_rooms: typeof file_avn_connect_v1_rooms;
declare const pb_d_file_avn_connect_v1_search: typeof file_avn_connect_v1_search;
declare const pb_d_file_avn_connect_v1_speech: typeof file_avn_connect_v1_speech;
declare const pb_d_file_avn_connect_v1_tags: typeof file_avn_connect_v1_tags;
declare const pb_d_file_avn_connect_v1_thinglink: typeof file_avn_connect_v1_thinglink;
declare const pb_d_file_avn_connect_v1_three_sixty_cities: typeof file_avn_connect_v1_three_sixty_cities;
declare const pb_d_file_avn_connect_v1_transcriptions: typeof file_avn_connect_v1_transcriptions;
declare const pb_d_file_avn_connect_v1_translations: typeof file_avn_connect_v1_translations;
declare const pb_d_file_avn_connect_v1_user: typeof file_avn_connect_v1_user;
declare const pb_d_file_avn_connect_v1_users: typeof file_avn_connect_v1_users;
declare const pb_d_file_avn_connect_v1_wifi_ap: typeof file_avn_connect_v1_wifi_ap;
declare const pb_d_file_grpc_health_v1_healthcheck: typeof file_grpc_health_v1_healthcheck;
declare const pb_d_translatable: typeof translatable;
declare namespace pb_d {
  export { pb_d_AccessLimitsSchema as AccessLimitsSchema, pb_d_ActivityFileType as ActivityFileType, pb_d_ActivityFileTypeSchema as ActivityFileTypeSchema, pb_d_ActivitySchema as ActivitySchema, pb_d_ActivityService as ActivityService, pb_d_ActivityType as ActivityType, pb_d_ActivityTypeSchema as ActivityTypeSchema, pb_d_AddActivityFilesRequestSchema as AddActivityFilesRequestSchema, pb_d_AddChildrenRequestSchema as AddChildrenRequestSchema, pb_d_AddCloudFilesRequestSchema as AddCloudFilesRequestSchema, pb_d_AddCloudFilesResponseSchema as AddCloudFilesResponseSchema, pb_d_AddTagsRequestSchema as AddTagsRequestSchema, pb_d_AltServerSchema as AltServerSchema, pb_d_AltServerType as AltServerType, pb_d_AltServerTypeSchema as AltServerTypeSchema, pb_d_AndroidPackageSchema as AndroidPackageSchema, pb_d_AndroidPackageService as AndroidPackageService, pb_d_AuthOnlyRequestSchema as AuthOnlyRequestSchema, pb_d_AuthorizationSchema as AuthorizationSchema, pb_d_AuthorizeDeviceRequestSchema as AuthorizeDeviceRequestSchema, pb_d_AuthorizeDeviceResponseSchema as AuthorizeDeviceResponseSchema, pb_d_AvailableContentSchema as AvailableContentSchema, pb_d_AvnfsService as AvnfsService, pb_d_AwsPlacesAddressSchema as AwsPlacesAddressSchema, pb_d_BlockadeService as BlockadeService, pb_d_BlockadeSkyboxStyleFamilySchema as BlockadeSkyboxStyleFamilySchema, pb_d_BlockadeSkyboxStyleSchema as BlockadeSkyboxStyleSchema, pb_d_CategorySchema as CategorySchema, pb_d_CategoryService as CategoryService, pb_d_CertificateSchema as CertificateSchema, pb_d_CertificateService as CertificateService, pb_d_ChannelSchema as ChannelSchema, pb_d_ChannelService as ChannelService, pb_d_CheckMediaCompatibilityRequestSchema as CheckMediaCompatibilityRequestSchema, pb_d_CheckMediaCompatibilityResponseSchema as CheckMediaCompatibilityResponseSchema, pb_d_ClientCredentialsSchema as ClientCredentialsSchema, pb_d_ClientService as ClientService, pb_d_CloudFileSchema as CloudFileSchema, pb_d_CloudService as CloudService, pb_d_CommandRequestSchema as CommandRequestSchema, pb_d_CommandResponseSchema as CommandResponseSchema, pb_d_ConnectionCredentialsSchema as ConnectionCredentialsSchema, pb_d_ConnectionInstanceSchema as ConnectionInstanceSchema, pb_d_ConnectionStatus as ConnectionStatus, pb_d_ConnectionStatusSchema as ConnectionStatusSchema, pb_d_ContentService as ContentService, pb_d_CopyEntityRequestSchema as CopyEntityRequestSchema, pb_d_CountrySchema as CountrySchema, pb_d_CountryService as CountryService, pb_d_CreateAccessPointRequestSchema as CreateAccessPointRequestSchema, pb_d_CreateAccessPointResponseSchema as CreateAccessPointResponseSchema, pb_d_CreateActivityRequestSchema as CreateActivityRequestSchema, pb_d_CreateAndroidPackageRequestSchema as CreateAndroidPackageRequestSchema, pb_d_CreateAndroidPackageResponseSchema as CreateAndroidPackageResponseSchema, pb_d_CreateClientCredentialsRequestSchema as CreateClientCredentialsRequestSchema, pb_d_CreateClientCredentialsResponseSchema as CreateClientCredentialsResponseSchema, pb_d_CreateDimensionRequestSchema as CreateDimensionRequestSchema, pb_d_CreateDimensionResponseSchema as CreateDimensionResponseSchema, pb_d_CreateEntityRequestSchema as CreateEntityRequestSchema, pb_d_CreateEntityResponseSchema as CreateEntityResponseSchema, pb_d_CreateOrganizationRequestSchema as CreateOrganizationRequestSchema, pb_d_CreateOrganizationResponseSchema as CreateOrganizationResponseSchema, pb_d_CreatePassRequestSchema as CreatePassRequestSchema, pb_d_CreatePassResponseSchema as CreatePassResponseSchema, pb_d_DeleteAccessPointRequestSchema as DeleteAccessPointRequestSchema, pb_d_DeleteAndroidPackageRequestSchema as DeleteAndroidPackageRequestSchema, pb_d_DeleteDeviceRequestSchema as DeleteDeviceRequestSchema, pb_d_DeleteEntityRequestSchema as DeleteEntityRequestSchema, pb_d_DeletePassRequestSchema as DeletePassRequestSchema, pb_d_DelightexCreateLoginLinkRequestSchema as DelightexCreateLoginLinkRequestSchema, pb_d_DelightexCreateLoginLinkResponseSchema as DelightexCreateLoginLinkResponseSchema, pb_d_DelightexGetStatusRequestSchema as DelightexGetStatusRequestSchema, pb_d_DelightexLicenseState as DelightexLicenseState, pb_d_DelightexLicenseStateSchema as DelightexLicenseStateSchema, pb_d_DelightexProvisionSchoolRequestSchema as DelightexProvisionSchoolRequestSchema, pb_d_DelightexProvisionUserRequestSchema as DelightexProvisionUserRequestSchema, pb_d_DelightexResolveShareLinkRequestSchema as DelightexResolveShareLinkRequestSchema, pb_d_DelightexResolveShareLinkResponseSchema as DelightexResolveShareLinkResponseSchema, pb_d_DelightexSchoolInfoSchema as DelightexSchoolInfoSchema, pb_d_DelightexSchoolState as DelightexSchoolState, pb_d_DelightexSchoolStateSchema as DelightexSchoolStateSchema, pb_d_DelightexService as DelightexService, pb_d_DelightexStatusSchema as DelightexStatusSchema, pb_d_DelightexUserState as DelightexUserState, pb_d_DelightexUserStateSchema as DelightexUserStateSchema, pb_d_DeviceCommandMethod as DeviceCommandMethod, pb_d_DeviceCommandMethodSchema as DeviceCommandMethodSchema, pb_d_DeviceCommandSchema as DeviceCommandSchema, pb_d_DeviceCredentialsSchema as DeviceCredentialsSchema, pb_d_DeviceInfoSchema as DeviceInfoSchema, pb_d_DeviceLogSchema as DeviceLogSchema, pb_d_DevicePropertiesSchema as DevicePropertiesSchema, pb_d_DeviceSchema as DeviceSchema, pb_d_DeviceService as DeviceService, pb_d_DimensionBroadcastSchema as DimensionBroadcastSchema, pb_d_DimensionEventSchema as DimensionEventSchema, pb_d_DimensionInfoSchema as DimensionInfoSchema, pb_d_DimensionInstanceSchema as DimensionInstanceSchema, pb_d_DimensionOriginSchema as DimensionOriginSchema, pb_d_DimensionService as DimensionService, pb_d_DimensionStatusSchema as DimensionStatusSchema, pb_d_EmbeddingTransformRequestSchema as EmbeddingTransformRequestSchema, pb_d_EmbeddingTransformResponseSchema as EmbeddingTransformResponseSchema, pb_d_EmbeddingTransformSchema as EmbeddingTransformSchema, pb_d_EnterRoomRequestSchema as EnterRoomRequestSchema, pb_d_EnterRoomResponseSchema as EnterRoomResponseSchema, pb_d_EntityInfoListRequestSchema as EntityInfoListRequestSchema, pb_d_EntityInfoListResponseSchema as EntityInfoListResponseSchema, pb_d_EntityInfoSchema as EntityInfoSchema, pb_d_EntityMetadataSchema as EntityMetadataSchema, pb_d_EntityPropertiesSchema as EntityPropertiesSchema, pb_d_EntityProperty as EntityProperty, pb_d_EntityPropertySchema as EntityPropertySchema, pb_d_EntityPropertyStateSchema as EntityPropertyStateSchema, pb_d_EntityType as EntityType, pb_d_EntityTypeSchema as EntityTypeSchema, pb_d_ExpiryStrategy as ExpiryStrategy, pb_d_ExpiryStrategySchema as ExpiryStrategySchema, pb_d_GenerateSkyboxRequestSchema as GenerateSkyboxRequestSchema, pb_d_GenerateSkyboxResponseSchema as GenerateSkyboxResponseSchema, pb_d_GenerateSkyboxTaskSchema as GenerateSkyboxTaskSchema, pb_d_GeoAddressSchema as GeoAddressSchema, pb_d_GeoBoundsSchema as GeoBoundsSchema, pb_d_GeoContactSchema as GeoContactSchema, pb_d_GeoFeedCellSchema as GeoFeedCellSchema, pb_d_GeoLocationSchema as GeoLocationSchema, pb_d_GeoPlaceSchema as GeoPlaceSchema, pb_d_GeoPlaceType as GeoPlaceType, pb_d_GeoPlaceTypeSchema as GeoPlaceTypeSchema, pb_d_GeoService as GeoService, pb_d_GeoSuggestRequestSchema as GeoSuggestRequestSchema, pb_d_GeoSuggestResponseSchema as GeoSuggestResponseSchema, pb_d_GetAccessPointRequestSchema as GetAccessPointRequestSchema, pb_d_GetActivityTranscriptRequestSchema as GetActivityTranscriptRequestSchema, pb_d_GetAltServersRequestSchema as GetAltServersRequestSchema, pb_d_GetAltServersResponseSchema as GetAltServersResponseSchema, pb_d_GetAndroidPackageRequestSchema as GetAndroidPackageRequestSchema, pb_d_GetCapabilitiesRequestSchema as GetCapabilitiesRequestSchema, pb_d_GetCapabilitiesResponseSchema as GetCapabilitiesResponseSchema, pb_d_GetCloudFilesRequestSchema as GetCloudFilesRequestSchema, pb_d_GetCloudFilesResponseSchema as GetCloudFilesResponseSchema, pb_d_GetCloudSummaryRequestSchema as GetCloudSummaryRequestSchema, pb_d_GetCloudSummaryResponseSchema as GetCloudSummaryResponseSchema, pb_d_GetCountriesRequestSchema as GetCountriesRequestSchema, pb_d_GetCountriesResponseSchema as GetCountriesResponseSchema, pb_d_GetCountryRequestSchema as GetCountryRequestSchema, pb_d_GetCurrentUserRequestSchema as GetCurrentUserRequestSchema, pb_d_GetDeviceLogsRequestSchema as GetDeviceLogsRequestSchema, pb_d_GetDeviceLogsResponseSchema as GetDeviceLogsResponseSchema, pb_d_GetDevicePropertiesRequestSchema as GetDevicePropertiesRequestSchema, pb_d_GetDevicePropertiesResponseSchema as GetDevicePropertiesResponseSchema, pb_d_GetDeviceRequestSchema as GetDeviceRequestSchema, pb_d_GetDevicesForOrganizationRequestSchema as GetDevicesForOrganizationRequestSchema, pb_d_GetDevicesForOrganizationResponseSchema as GetDevicesForOrganizationResponseSchema, pb_d_GetDimensionRequestSchema as GetDimensionRequestSchema, pb_d_GetEntityPropertiesRequestSchema as GetEntityPropertiesRequestSchema, pb_d_GetEntityPropertiesResponseSchema as GetEntityPropertiesResponseSchema, pb_d_GetEntityRequestSchema as GetEntityRequestSchema, pb_d_GetFileUrlRequestSchema as GetFileUrlRequestSchema, pb_d_GetFileUrlResponseSchema as GetFileUrlResponseSchema, pb_d_GetGeoFeedRequestSchema as GetGeoFeedRequestSchema, pb_d_GetGeoFeedResponseSchema as GetGeoFeedResponseSchema, pb_d_GetGeoPlaceRequestSchema as GetGeoPlaceRequestSchema, pb_d_GetGeoPlaceResponseSchema as GetGeoPlaceResponseSchema, pb_d_GetGrantsResponseSchema as GetGrantsResponseSchema, pb_d_GetHostnameCertificatesRequestSchema as GetHostnameCertificatesRequestSchema, pb_d_GetImageMetadataResponseSchema as GetImageMetadataResponseSchema, pb_d_GetLanguagesRequestSchema as GetLanguagesRequestSchema, pb_d_GetLanguagesResponseSchema as GetLanguagesResponseSchema, pb_d_GetLighthouseServersRequestSchema as GetLighthouseServersRequestSchema, pb_d_GetLighthouseServersResponseSchema as GetLighthouseServersResponseSchema, pb_d_GetManifestRequestSchema as GetManifestRequestSchema, pb_d_GetMediaDeviceSpecsRequestSchema as GetMediaDeviceSpecsRequestSchema, pb_d_GetMediaDeviceSpecsResponseSchema as GetMediaDeviceSpecsResponseSchema, pb_d_GetMediaSpectrumRequestSchema as GetMediaSpectrumRequestSchema, pb_d_GetMediaSpectrumResponseSchema as GetMediaSpectrumResponseSchema, pb_d_GetMediaTranscriptRequestSchema as GetMediaTranscriptRequestSchema, pb_d_GetMediaTypeExtensionMapRequestSchema as GetMediaTypeExtensionMapRequestSchema, pb_d_GetMediaTypeExtensionMapResponseSchema as GetMediaTypeExtensionMapResponseSchema, pb_d_GetMetadataRequestSchema as GetMetadataRequestSchema, pb_d_GetMetadataResponseSchema as GetMetadataResponseSchema, pb_d_GetNewsRequestSchema as GetNewsRequestSchema, pb_d_GetNewsResponseSchema as GetNewsResponseSchema, pb_d_GetOrganizationAccessPointsRequestSchema as GetOrganizationAccessPointsRequestSchema, pb_d_GetOrganizationAccessPointsResponseSchema as GetOrganizationAccessPointsResponseSchema, pb_d_GetOrganizationGrantsRequestSchema as GetOrganizationGrantsRequestSchema, pb_d_GetOrganizationMembershipRequestSchema as GetOrganizationMembershipRequestSchema, pb_d_GetOrganizationMembershipResponseSchema as GetOrganizationMembershipResponseSchema, pb_d_GetOrganizationUsersRequestSchema as GetOrganizationUsersRequestSchema, pb_d_GetOrganizationUsersResponseSchema as GetOrganizationUsersResponseSchema, pb_d_GetPassRequestSchema as GetPassRequestSchema, pb_d_GetPassResponseSchema as GetPassResponseSchema, pb_d_GetPermissionsRequestSchema as GetPermissionsRequestSchema, pb_d_GetPermissionsResponseSchema as GetPermissionsResponseSchema, pb_d_GetPreviewImageRequestSchema as GetPreviewImageRequestSchema, pb_d_GetPreviewImageResponseSchema as GetPreviewImageResponseSchema, pb_d_GetRecentOrganizationsRequestSchema as GetRecentOrganizationsRequestSchema, pb_d_GetRecentOrganizationsResponseSchema as GetRecentOrganizationsResponseSchema, pb_d_GetRolesRequestSchema as GetRolesRequestSchema, pb_d_GetRolesResponseSchema as GetRolesResponseSchema, pb_d_GetRoomRequestSchema as GetRoomRequestSchema, pb_d_GetRoomResponseSchema as GetRoomResponseSchema, pb_d_GetSkyboxStyleFamiliesRequestSchema as GetSkyboxStyleFamiliesRequestSchema, pb_d_GetSkyboxStyleFamiliesResponseSchema as GetSkyboxStyleFamiliesResponseSchema, pb_d_GetSubordinateOrganizationsRequestSchema as GetSubordinateOrganizationsRequestSchema, pb_d_GetSubordinateOrganizationsResponseSchema as GetSubordinateOrganizationsResponseSchema, pb_d_GetTagGroupRequestSchema as GetTagGroupRequestSchema, pb_d_GetTagGroupResponseSchema as GetTagGroupResponseSchema, pb_d_GetTagsRequestSchema as GetTagsRequestSchema, pb_d_GetTagsResponseSchema as GetTagsResponseSchema, pb_d_GetTranscriptResponseSchema as GetTranscriptResponseSchema, pb_d_GetUserGrantsRequestSchema as GetUserGrantsRequestSchema, pb_d_GetVideoMetadataResponseSchema as GetVideoMetadataResponseSchema, pb_d_GrantInfoSchema as GrantInfoSchema, pb_d_GrantService as GrantService, pb_d_GrantType as GrantType, pb_d_GrantTypeSchema as GrantTypeSchema, pb_d_HeaderFieldSchema as HeaderFieldSchema, pb_d_Health as Health, pb_d_HealthCheckRequestSchema as HealthCheckRequestSchema, pb_d_HealthCheckResponseSchema as HealthCheckResponseSchema, pb_d_HealthCheckResponse_ServingStatus as HealthCheckResponse_ServingStatus, pb_d_HealthCheckResponse_ServingStatusSchema as HealthCheckResponse_ServingStatusSchema, pb_d_HyperlinkSchema as HyperlinkSchema, pb_d_IdentityProvider as IdentityProvider, pb_d_IdentityProviderSchema as IdentityProviderSchema, pb_d_ImportUrlRequestSchema as ImportUrlRequestSchema, pb_d_ImportUrlResponseSchema as ImportUrlResponseSchema, pb_d_InfoService as InfoService, pb_d_InteractionPermissionsSchema as InteractionPermissionsSchema, pb_d_IsPermittedRequestSchema as IsPermittedRequestSchema, pb_d_IsPermittedResponseSchema as IsPermittedResponseSchema, pb_d_JobSchema as JobSchema, pb_d_JoinDimensionRequestSchema as JoinDimensionRequestSchema, pb_d_JoinOrganizationRequestSchema as JoinOrganizationRequestSchema, pb_d_JoinOrganizationResponseSchema as JoinOrganizationResponseSchema, pb_d_KtxService as KtxService, pb_d_LanguageSchema as LanguageSchema, pb_d_LanguageService as LanguageService, pb_d_LessonContextSchema as LessonContextSchema, pb_d_LessonFocusSchema as LessonFocusSchema, pb_d_LighthouseServerSchema as LighthouseServerSchema, pb_d_MatchActivityFromCloudRequestSchema as MatchActivityFromCloudRequestSchema, pb_d_MatchActivityFromFilesRequestSchema as MatchActivityFromFilesRequestSchema, pb_d_MatchActivityFromUrlRequestSchema as MatchActivityFromUrlRequestSchema, pb_d_MatchActivityResponseSchema as MatchActivityResponseSchema, pb_d_MediaCompatibilityArea as MediaCompatibilityArea, pb_d_MediaCompatibilityAreaSchema as MediaCompatibilityAreaSchema, pb_d_MediaCompatibilityIssueSchema as MediaCompatibilityIssueSchema, pb_d_MediaCompatibilityReason as MediaCompatibilityReason, pb_d_MediaCompatibilityReasonSchema as MediaCompatibilityReasonSchema, pb_d_MediaDeviceSpecSchema as MediaDeviceSpecSchema, pb_d_MediaFormatMetadataSchema as MediaFormatMetadataSchema, pb_d_MediaFormatSpecSchema as MediaFormatSpecSchema, pb_d_MediaRationalSchema as MediaRationalSchema, pb_d_MediaService as MediaService, pb_d_MediaSpectrumSchema as MediaSpectrumSchema, pb_d_MediaStreamMetadataSchema as MediaStreamMetadataSchema, pb_d_MediaStreamType as MediaStreamType, pb_d_MediaStreamTypeSchema as MediaStreamTypeSchema, pb_d_MediaTypeExtensionSchema as MediaTypeExtensionSchema, pb_d_MetadataFilterCondition as MetadataFilterCondition, pb_d_MetadataFilterConditionSchema as MetadataFilterConditionSchema, pb_d_MetadataFilterSchema as MetadataFilterSchema, pb_d_MetadataRequestSchema as MetadataRequestSchema, pb_d_NeighborServerSchema as NeighborServerSchema, pb_d_NeighborService as NeighborService, pb_d_OpenRoomRequestSchema as OpenRoomRequestSchema, pb_d_OpenRoomResponseSchema as OpenRoomResponseSchema, pb_d_OperationState as OperationState, pb_d_OperationStateSchema as OperationStateSchema, pb_d_OrderClauseSchema as OrderClauseSchema, pb_d_OrganizationInfoSchema as OrganizationInfoSchema, pb_d_OrganizationMembershipSchema as OrganizationMembershipSchema, pb_d_OrganizationSchema as OrganizationSchema, pb_d_OrganizationService as OrganizationService, pb_d_OrganizationSpecSchema as OrganizationSpecSchema, pb_d_OrganizationUserSchema as OrganizationUserSchema, pb_d_PartnerSessionSchema as PartnerSessionSchema, pb_d_PassSchema as PassSchema, pb_d_PassService as PassService, pb_d_PermissionSchema as PermissionSchema, pb_d_PermissionScope as PermissionScope, pb_d_PermissionScopeSchema as PermissionScopeSchema, pb_d_PermissionService as PermissionService, pb_d_PhonemeDetailSchema as PhonemeDetailSchema, pb_d_PresenceInfoSchema as PresenceInfoSchema, pb_d_PresenceState as PresenceState, pb_d_PresenceStateSchema as PresenceStateSchema, pb_d_PresenceUpdateSchema as PresenceUpdateSchema, pb_d_ProfileSchema as ProfileSchema, pb_d_ProfileService as ProfileService, pb_d_PronunciationAnalysisRequestSchema as PronunciationAnalysisRequestSchema, pb_d_PronunciationAnalysisResponseSchema as PronunciationAnalysisResponseSchema, pb_d_QuaternionSchema as QuaternionSchema, pb_d_RecordActionRequestSchema as RecordActionRequestSchema, pb_d_RecordFeedbackRequestSchema as RecordFeedbackRequestSchema, pb_d_RecordLogRequestSchema as RecordLogRequestSchema, pb_d_RegisterLighthouseServerRequestSchema as RegisterLighthouseServerRequestSchema, pb_d_RegisterLighthouseServerResponseSchema as RegisterLighthouseServerResponseSchema, pb_d_RegisterNeighborServerRequestSchema as RegisterNeighborServerRequestSchema, pb_d_RegisterNeighborServerResponseSchema as RegisterNeighborServerResponseSchema, pb_d_ReleaseChannel as ReleaseChannel, pb_d_ReleaseChannelSchema as ReleaseChannelSchema, pb_d_RemoveActivityFilesRequestSchema as RemoveActivityFilesRequestSchema, pb_d_RemoveChildrenRequestSchema as RemoveChildrenRequestSchema, pb_d_RemoveCloudFilesRequestSchema as RemoveCloudFilesRequestSchema, pb_d_RemoveOrganizationUserRequestSchema as RemoveOrganizationUserRequestSchema, pb_d_RemoveTagsRequestSchema as RemoveTagsRequestSchema, pb_d_ResolveAssetRequestSchema as ResolveAssetRequestSchema, pb_d_ResolveMediaRequestSchema as ResolveMediaRequestSchema, pb_d_ResolveMediaResponseSchema as ResolveMediaResponseSchema, pb_d_RoleSchema as RoleSchema, pb_d_RoleService as RoleService, pb_d_RoomInfoSchema as RoomInfoSchema, pb_d_RoomService as RoomService, pb_d_SearchCloudFilesRequestSchema as SearchCloudFilesRequestSchema, pb_d_SearchCloudFilesResponseSchema as SearchCloudFilesResponseSchema, pb_d_SearchFlags as SearchFlags, pb_d_SearchFlagsSchema as SearchFlagsSchema, pb_d_SearchImagesRequestSchema as SearchImagesRequestSchema, pb_d_SearchImagesResponseSchema as SearchImagesResponseSchema, pb_d_SearchMemberOrganizationsRequestSchema as SearchMemberOrganizationsRequestSchema, pb_d_SearchMemberOrganizationsResponseSchema as SearchMemberOrganizationsResponseSchema, pb_d_SetActivityTranscriptRequestSchema as SetActivityTranscriptRequestSchema, pb_d_SetDeviceCommandRequestSchema as SetDeviceCommandRequestSchema, pb_d_SetDevicePropertiesRequestSchema as SetDevicePropertiesRequestSchema, pb_d_SetEntityPropertiesRequestSchema as SetEntityPropertiesRequestSchema, pb_d_SetLessonContextRequestSchema as SetLessonContextRequestSchema, pb_d_SetLessonContextResponseSchema as SetLessonContextResponseSchema, pb_d_SetOrganizationMembershipRequestSchema as SetOrganizationMembershipRequestSchema, pb_d_SortOrder as SortOrder, pb_d_SortOrderSchema as SortOrderSchema, pb_d_SpeakerGender as SpeakerGender, pb_d_SpeakerGenderSchema as SpeakerGenderSchema, pb_d_SpeakerSchema as SpeakerSchema, pb_d_SpeechFileFormat as SpeechFileFormat, pb_d_SpeechFileFormatSchema as SpeechFileFormatSchema, pb_d_SpeechFileSpecSchema as SpeechFileSpecSchema, pb_d_SpeechFlag as SpeechFlag, pb_d_SpeechFlagSchema as SpeechFlagSchema, pb_d_SpeechMarkSchema as SpeechMarkSchema, pb_d_SpeechMarkType as SpeechMarkType, pb_d_SpeechMarkTypeSchema as SpeechMarkTypeSchema, pb_d_SpeechMarksSchema as SpeechMarksSchema, pb_d_SpeechSchema as SpeechSchema, pb_d_SpeechSegmentSchema as SpeechSegmentSchema, pb_d_SpeechService as SpeechService, pb_d_SubmitCommunityCategoryRequestSchema as SubmitCommunityCategoryRequestSchema, pb_d_SynthesizeSpeechRequestSchema as SynthesizeSpeechRequestSchema, pb_d_SynthesizeSpeechResponseSchema as SynthesizeSpeechResponseSchema, pb_d_SynthesizeTranscriptRequestSchema as SynthesizeTranscriptRequestSchema, pb_d_SynthesizeTranscriptResponseSchema as SynthesizeTranscriptResponseSchema, pb_d_TagFilterCondition as TagFilterCondition, pb_d_TagFilterConditionSchema as TagFilterConditionSchema, pb_d_TagFilterSchema as TagFilterSchema, pb_d_TagGroupId as TagGroupId, pb_d_TagGroupIdSchema as TagGroupIdSchema, pb_d_TagGroupSchema as TagGroupSchema, pb_d_TagId as TagId, pb_d_TagIdSchema as TagIdSchema, pb_d_TagSchema as TagSchema, pb_d_TagService as TagService, pb_d_TextDirection as TextDirection, pb_d_TextDirectionSchema as TextDirectionSchema, pb_d_TextSearchSchema as TextSearchSchema, pb_d_ThingLinkService as ThingLinkService, pb_d_ThreeSixtyCitiesService as ThreeSixtyCitiesService, pb_d_ToKtxParametersSchema as ToKtxParametersSchema, pb_d_ToKtxRequestSchema as ToKtxRequestSchema, pb_d_ToKtxResponseSchema as ToKtxResponseSchema, pb_d_TranscodeImageRequestSchema as TranscodeImageRequestSchema, pb_d_TranscodeImageResponseSchema as TranscodeImageResponseSchema, pb_d_TranscodeImageSpecSchema as TranscodeImageSpecSchema, pb_d_TranscodeVideoRequestSchema as TranscodeVideoRequestSchema, pb_d_TranscodeVideoResponseSchema as TranscodeVideoResponseSchema, pb_d_TranscodeVideoResultSchema as TranscodeVideoResultSchema, pb_d_TranscodeVideoTaskSchema as TranscodeVideoTaskSchema, pb_d_TranscriptSchema as TranscriptSchema, pb_d_TranscriptSegmentSchema as TranscriptSegmentSchema, pb_d_TranscriptionService as TranscriptionService, pb_d_TransformMediaRequestSchema as TransformMediaRequestSchema, pb_d_TransformMediaResponseSchema as TransformMediaResponseSchema, pb_d_TranslationFlag as TranslationFlag, pb_d_TranslationFlagSchema as TranslationFlagSchema, pb_d_TranslationFormat as TranslationFormat, pb_d_TranslationFormatSchema as TranslationFormatSchema, pb_d_TranslationLookupRequestSchema as TranslationLookupRequestSchema, pb_d_TranslationLookupResponseSchema as TranslationLookupResponseSchema, pb_d_TranslationOrigin as TranslationOrigin, pb_d_TranslationOriginSchema as TranslationOriginSchema, pb_d_TranslationRequestSchema as TranslationRequestSchema, pb_d_TranslationResponseSchema as TranslationResponseSchema, pb_d_TranslationService as TranslationService, pb_d_TranslationSpecSchema as TranslationSpecSchema, pb_d_TranslationUpdateRequestSchema as TranslationUpdateRequestSchema, pb_d_UploadManifestSchema as UploadManifestSchema, pb_d_UserInterfaceFeaturesSchema as UserInterfaceFeaturesSchema, pb_d_UserSchema as UserSchema, pb_d_UserService as UserService, pb_d_Vector3Schema as Vector3Schema, pb_d_WifiAccessPointInfoSchema as WifiAccessPointInfoSchema, pb_d_WifiAccessPointSchema as WifiAccessPointSchema, pb_d_WifiAccessPointService as WifiAccessPointService, pb_d_WifiClientCredential as WifiClientCredential, pb_d_WifiClientCredentialSchema as WifiClientCredentialSchema, pb_d_WifiEncryption as WifiEncryption, pb_d_WifiEncryptionSchema as WifiEncryptionSchema, pb_d_WifiPhase2 as WifiPhase2, pb_d_WifiPhase2Schema as WifiPhase2Schema, pb_d_file_avn_connect_v1_activities as file_avn_connect_v1_activities, pb_d_file_avn_connect_v1_authorization as file_avn_connect_v1_authorization, pb_d_file_avn_connect_v1_avnfs as file_avn_connect_v1_avnfs, pb_d_file_avn_connect_v1_blockade as file_avn_connect_v1_blockade, pb_d_file_avn_connect_v1_categories as file_avn_connect_v1_categories, pb_d_file_avn_connect_v1_certificates as file_avn_connect_v1_certificates, pb_d_file_avn_connect_v1_channels as file_avn_connect_v1_channels, pb_d_file_avn_connect_v1_clients as file_avn_connect_v1_clients, pb_d_file_avn_connect_v1_cloud as file_avn_connect_v1_cloud, pb_d_file_avn_connect_v1_command as file_avn_connect_v1_command, pb_d_file_avn_connect_v1_content as file_avn_connect_v1_content, pb_d_file_avn_connect_v1_countries as file_avn_connect_v1_countries, pb_d_file_avn_connect_v1_credentials as file_avn_connect_v1_credentials, pb_d_file_avn_connect_v1_delightex as file_avn_connect_v1_delightex, pb_d_file_avn_connect_v1_devices as file_avn_connect_v1_devices, pb_d_file_avn_connect_v1_dimensions as file_avn_connect_v1_dimensions, pb_d_file_avn_connect_v1_embedding as file_avn_connect_v1_embedding, pb_d_file_avn_connect_v1_entities as file_avn_connect_v1_entities, pb_d_file_avn_connect_v1_features as file_avn_connect_v1_features, pb_d_file_avn_connect_v1_geo as file_avn_connect_v1_geo, pb_d_file_avn_connect_v1_geometry as file_avn_connect_v1_geometry, pb_d_file_avn_connect_v1_grants as file_avn_connect_v1_grants, pb_d_file_avn_connect_v1_http as file_avn_connect_v1_http, pb_d_file_avn_connect_v1_info as file_avn_connect_v1_info, pb_d_file_avn_connect_v1_interaction_permissions as file_avn_connect_v1_interaction_permissions, pb_d_file_avn_connect_v1_ktx as file_avn_connect_v1_ktx, pb_d_file_avn_connect_v1_languages as file_avn_connect_v1_languages, pb_d_file_avn_connect_v1_lesson_context as file_avn_connect_v1_lesson_context, pb_d_file_avn_connect_v1_media as file_avn_connect_v1_media, pb_d_file_avn_connect_v1_metadata as file_avn_connect_v1_metadata, pb_d_file_avn_connect_v1_neighbors as file_avn_connect_v1_neighbors, pb_d_file_avn_connect_v1_operations as file_avn_connect_v1_operations, pb_d_file_avn_connect_v1_organization_membership as file_avn_connect_v1_organization_membership, pb_d_file_avn_connect_v1_organizations as file_avn_connect_v1_organizations, pb_d_file_avn_connect_v1_packages as file_avn_connect_v1_packages, pb_d_file_avn_connect_v1_partners as file_avn_connect_v1_partners, pb_d_file_avn_connect_v1_passes as file_avn_connect_v1_passes, pb_d_file_avn_connect_v1_permissions as file_avn_connect_v1_permissions, pb_d_file_avn_connect_v1_presence as file_avn_connect_v1_presence, pb_d_file_avn_connect_v1_profiles as file_avn_connect_v1_profiles, pb_d_file_avn_connect_v1_properties as file_avn_connect_v1_properties, pb_d_file_avn_connect_v1_roles as file_avn_connect_v1_roles, pb_d_file_avn_connect_v1_rooms as file_avn_connect_v1_rooms, pb_d_file_avn_connect_v1_search as file_avn_connect_v1_search, pb_d_file_avn_connect_v1_speech as file_avn_connect_v1_speech, pb_d_file_avn_connect_v1_tags as file_avn_connect_v1_tags, pb_d_file_avn_connect_v1_thinglink as file_avn_connect_v1_thinglink, pb_d_file_avn_connect_v1_three_sixty_cities as file_avn_connect_v1_three_sixty_cities, pb_d_file_avn_connect_v1_transcriptions as file_avn_connect_v1_transcriptions, pb_d_file_avn_connect_v1_translations as file_avn_connect_v1_translations, pb_d_file_avn_connect_v1_user as file_avn_connect_v1_user, pb_d_file_avn_connect_v1_users as file_avn_connect_v1_users, pb_d_file_avn_connect_v1_wifi_ap as file_avn_connect_v1_wifi_ap, pb_d_file_grpc_health_v1_healthcheck as file_grpc_health_v1_healthcheck, pb_d_translatable as translatable };
  export type { pb_d_AccessLimits as AccessLimits, pb_d_Activity as Activity, pb_d_AddActivityFilesRequest as AddActivityFilesRequest, pb_d_AddChildrenRequest as AddChildrenRequest, pb_d_AddCloudFilesRequest as AddCloudFilesRequest, pb_d_AddCloudFilesResponse as AddCloudFilesResponse, pb_d_AddTagsRequest as AddTagsRequest, pb_d_AltServer as AltServer, pb_d_AndroidPackage as AndroidPackage, pb_d_AuthOnlyRequest as AuthOnlyRequest, pb_d_Authorization as Authorization, pb_d_AuthorizeDeviceRequest as AuthorizeDeviceRequest, pb_d_AuthorizeDeviceResponse as AuthorizeDeviceResponse, pb_d_AvailableContent as AvailableContent, pb_d_AwsPlacesAddress as AwsPlacesAddress, pb_d_BlockadeSkyboxStyle as BlockadeSkyboxStyle, pb_d_BlockadeSkyboxStyleFamily as BlockadeSkyboxStyleFamily, pb_d_Category as Category, pb_d_Certificate as Certificate, pb_d_Channel as Channel, pb_d_CheckMediaCompatibilityRequest as CheckMediaCompatibilityRequest, pb_d_CheckMediaCompatibilityResponse as CheckMediaCompatibilityResponse, pb_d_ClientCredentials as ClientCredentials, pb_d_CloudFile as CloudFile, pb_d_CommandRequest as CommandRequest, pb_d_CommandResponse as CommandResponse, pb_d_ConnectionCredentials as ConnectionCredentials, pb_d_ConnectionInstance as ConnectionInstance, pb_d_CopyEntityRequest as CopyEntityRequest, pb_d_Country as Country, pb_d_CreateAccessPointRequest as CreateAccessPointRequest, pb_d_CreateAccessPointResponse as CreateAccessPointResponse, pb_d_CreateActivityRequest as CreateActivityRequest, pb_d_CreateAndroidPackageRequest as CreateAndroidPackageRequest, pb_d_CreateAndroidPackageResponse as CreateAndroidPackageResponse, pb_d_CreateClientCredentialsRequest as CreateClientCredentialsRequest, pb_d_CreateClientCredentialsResponse as CreateClientCredentialsResponse, pb_d_CreateDimensionRequest as CreateDimensionRequest, pb_d_CreateDimensionResponse as CreateDimensionResponse, pb_d_CreateEntityRequest as CreateEntityRequest, pb_d_CreateEntityResponse as CreateEntityResponse, pb_d_CreateOrganizationRequest as CreateOrganizationRequest, pb_d_CreateOrganizationResponse as CreateOrganizationResponse, pb_d_CreatePassRequest as CreatePassRequest, pb_d_CreatePassResponse as CreatePassResponse, pb_d_DeleteAccessPointRequest as DeleteAccessPointRequest, pb_d_DeleteAndroidPackageRequest as DeleteAndroidPackageRequest, pb_d_DeleteDeviceRequest as DeleteDeviceRequest, pb_d_DeleteEntityRequest as DeleteEntityRequest, pb_d_DeletePassRequest as DeletePassRequest, pb_d_DelightexCreateLoginLinkRequest as DelightexCreateLoginLinkRequest, pb_d_DelightexCreateLoginLinkResponse as DelightexCreateLoginLinkResponse, pb_d_DelightexGetStatusRequest as DelightexGetStatusRequest, pb_d_DelightexProvisionSchoolRequest as DelightexProvisionSchoolRequest, pb_d_DelightexProvisionUserRequest as DelightexProvisionUserRequest, pb_d_DelightexResolveShareLinkRequest as DelightexResolveShareLinkRequest, pb_d_DelightexResolveShareLinkResponse as DelightexResolveShareLinkResponse, pb_d_DelightexSchoolInfo as DelightexSchoolInfo, pb_d_DelightexStatus as DelightexStatus, pb_d_Device as Device, pb_d_DeviceCommand as DeviceCommand, pb_d_DeviceCredentials as DeviceCredentials, pb_d_DeviceInfo as DeviceInfo, pb_d_DeviceLog as DeviceLog, pb_d_DeviceProperties as DeviceProperties, pb_d_DimensionBroadcast as DimensionBroadcast, pb_d_DimensionEvent as DimensionEvent, pb_d_DimensionInfo as DimensionInfo, pb_d_DimensionInstance as DimensionInstance, pb_d_DimensionOrigin as DimensionOrigin, pb_d_DimensionStatus as DimensionStatus, pb_d_EmbeddingTransform as EmbeddingTransform, pb_d_EmbeddingTransformRequest as EmbeddingTransformRequest, pb_d_EmbeddingTransformResponse as EmbeddingTransformResponse, pb_d_EnterRoomRequest as EnterRoomRequest, pb_d_EnterRoomResponse as EnterRoomResponse, pb_d_EntityInfo as EntityInfo, pb_d_EntityInfoListRequest as EntityInfoListRequest, pb_d_EntityInfoListResponse as EntityInfoListResponse, pb_d_EntityMetadata as EntityMetadata, pb_d_EntityProperties as EntityProperties, pb_d_EntityPropertyState as EntityPropertyState, pb_d_GenerateSkyboxRequest as GenerateSkyboxRequest, pb_d_GenerateSkyboxResponse as GenerateSkyboxResponse, pb_d_GenerateSkyboxTask as GenerateSkyboxTask, pb_d_GeoAddress as GeoAddress, pb_d_GeoBounds as GeoBounds, pb_d_GeoContact as GeoContact, pb_d_GeoFeedCell as GeoFeedCell, pb_d_GeoLocation as GeoLocation, pb_d_GeoPlace as GeoPlace, pb_d_GeoSuggestRequest as GeoSuggestRequest, pb_d_GeoSuggestResponse as GeoSuggestResponse, pb_d_GetAccessPointRequest as GetAccessPointRequest, pb_d_GetActivityTranscriptRequest as GetActivityTranscriptRequest, pb_d_GetAltServersRequest as GetAltServersRequest, pb_d_GetAltServersResponse as GetAltServersResponse, pb_d_GetAndroidPackageRequest as GetAndroidPackageRequest, pb_d_GetCapabilitiesRequest as GetCapabilitiesRequest, pb_d_GetCapabilitiesResponse as GetCapabilitiesResponse, pb_d_GetCloudFilesRequest as GetCloudFilesRequest, pb_d_GetCloudFilesResponse as GetCloudFilesResponse, pb_d_GetCloudSummaryRequest as GetCloudSummaryRequest, pb_d_GetCloudSummaryResponse as GetCloudSummaryResponse, pb_d_GetCountriesRequest as GetCountriesRequest, pb_d_GetCountriesResponse as GetCountriesResponse, pb_d_GetCountryRequest as GetCountryRequest, pb_d_GetCurrentUserRequest as GetCurrentUserRequest, pb_d_GetDeviceLogsRequest as GetDeviceLogsRequest, pb_d_GetDeviceLogsResponse as GetDeviceLogsResponse, pb_d_GetDevicePropertiesRequest as GetDevicePropertiesRequest, pb_d_GetDevicePropertiesResponse as GetDevicePropertiesResponse, pb_d_GetDeviceRequest as GetDeviceRequest, pb_d_GetDevicesForOrganizationRequest as GetDevicesForOrganizationRequest, pb_d_GetDevicesForOrganizationResponse as GetDevicesForOrganizationResponse, pb_d_GetDimensionRequest as GetDimensionRequest, pb_d_GetEntityPropertiesRequest as GetEntityPropertiesRequest, pb_d_GetEntityPropertiesResponse as GetEntityPropertiesResponse, pb_d_GetEntityRequest as GetEntityRequest, pb_d_GetFileUrlRequest as GetFileUrlRequest, pb_d_GetFileUrlResponse as GetFileUrlResponse, pb_d_GetGeoFeedRequest as GetGeoFeedRequest, pb_d_GetGeoFeedResponse as GetGeoFeedResponse, pb_d_GetGeoPlaceRequest as GetGeoPlaceRequest, pb_d_GetGeoPlaceResponse as GetGeoPlaceResponse, pb_d_GetGrantsResponse as GetGrantsResponse, pb_d_GetHostnameCertificatesRequest as GetHostnameCertificatesRequest, pb_d_GetImageMetadataResponse as GetImageMetadataResponse, pb_d_GetLanguagesRequest as GetLanguagesRequest, pb_d_GetLanguagesResponse as GetLanguagesResponse, pb_d_GetLighthouseServersRequest as GetLighthouseServersRequest, pb_d_GetLighthouseServersResponse as GetLighthouseServersResponse, pb_d_GetManifestRequest as GetManifestRequest, pb_d_GetMediaDeviceSpecsRequest as GetMediaDeviceSpecsRequest, pb_d_GetMediaDeviceSpecsResponse as GetMediaDeviceSpecsResponse, pb_d_GetMediaSpectrumRequest as GetMediaSpectrumRequest, pb_d_GetMediaSpectrumResponse as GetMediaSpectrumResponse, pb_d_GetMediaTranscriptRequest as GetMediaTranscriptRequest, pb_d_GetMediaTypeExtensionMapRequest as GetMediaTypeExtensionMapRequest, pb_d_GetMediaTypeExtensionMapResponse as GetMediaTypeExtensionMapResponse, pb_d_GetMetadataRequest as GetMetadataRequest, pb_d_GetMetadataResponse as GetMetadataResponse, pb_d_GetNewsRequest as GetNewsRequest, pb_d_GetNewsResponse as GetNewsResponse, pb_d_GetOrganizationAccessPointsRequest as GetOrganizationAccessPointsRequest, pb_d_GetOrganizationAccessPointsResponse as GetOrganizationAccessPointsResponse, pb_d_GetOrganizationGrantsRequest as GetOrganizationGrantsRequest, pb_d_GetOrganizationMembershipRequest as GetOrganizationMembershipRequest, pb_d_GetOrganizationMembershipResponse as GetOrganizationMembershipResponse, pb_d_GetOrganizationUsersRequest as GetOrganizationUsersRequest, pb_d_GetOrganizationUsersResponse as GetOrganizationUsersResponse, pb_d_GetPassRequest as GetPassRequest, pb_d_GetPassResponse as GetPassResponse, pb_d_GetPermissionsRequest as GetPermissionsRequest, pb_d_GetPermissionsResponse as GetPermissionsResponse, pb_d_GetPreviewImageRequest as GetPreviewImageRequest, pb_d_GetPreviewImageResponse as GetPreviewImageResponse, pb_d_GetRecentOrganizationsRequest as GetRecentOrganizationsRequest, pb_d_GetRecentOrganizationsResponse as GetRecentOrganizationsResponse, pb_d_GetRolesRequest as GetRolesRequest, pb_d_GetRolesResponse as GetRolesResponse, pb_d_GetRoomRequest as GetRoomRequest, pb_d_GetRoomResponse as GetRoomResponse, pb_d_GetSkyboxStyleFamiliesRequest as GetSkyboxStyleFamiliesRequest, pb_d_GetSkyboxStyleFamiliesResponse as GetSkyboxStyleFamiliesResponse, pb_d_GetSubordinateOrganizationsRequest as GetSubordinateOrganizationsRequest, pb_d_GetSubordinateOrganizationsResponse as GetSubordinateOrganizationsResponse, pb_d_GetTagGroupRequest as GetTagGroupRequest, pb_d_GetTagGroupResponse as GetTagGroupResponse, pb_d_GetTagsRequest as GetTagsRequest, pb_d_GetTagsResponse as GetTagsResponse, pb_d_GetTranscriptResponse as GetTranscriptResponse, pb_d_GetUserGrantsRequest as GetUserGrantsRequest, pb_d_GetVideoMetadataResponse as GetVideoMetadataResponse, pb_d_GrantInfo as GrantInfo, pb_d_HeaderField as HeaderField, pb_d_HealthCheckRequest as HealthCheckRequest, pb_d_HealthCheckResponse as HealthCheckResponse, pb_d_Hyperlink as Hyperlink, pb_d_ImportUrlRequest as ImportUrlRequest, pb_d_ImportUrlResponse as ImportUrlResponse, pb_d_InteractionPermissions as InteractionPermissions, pb_d_IsPermittedRequest as IsPermittedRequest, pb_d_IsPermittedResponse as IsPermittedResponse, pb_d_Job as Job, pb_d_JoinDimensionRequest as JoinDimensionRequest, pb_d_JoinOrganizationRequest as JoinOrganizationRequest, pb_d_JoinOrganizationResponse as JoinOrganizationResponse, pb_d_Language as Language, pb_d_LessonContext as LessonContext, pb_d_LessonFocus as LessonFocus, pb_d_LighthouseServer as LighthouseServer, pb_d_MatchActivityFromCloudRequest as MatchActivityFromCloudRequest, pb_d_MatchActivityFromFilesRequest as MatchActivityFromFilesRequest, pb_d_MatchActivityFromUrlRequest as MatchActivityFromUrlRequest, pb_d_MatchActivityResponse as MatchActivityResponse, pb_d_MediaCompatibilityIssue as MediaCompatibilityIssue, pb_d_MediaDeviceSpec as MediaDeviceSpec, pb_d_MediaFormatMetadata as MediaFormatMetadata, pb_d_MediaFormatSpec as MediaFormatSpec, pb_d_MediaRational as MediaRational, pb_d_MediaSpectrum as MediaSpectrum, pb_d_MediaStreamMetadata as MediaStreamMetadata, pb_d_MediaTypeExtension as MediaTypeExtension, pb_d_MetadataFilter as MetadataFilter, pb_d_MetadataRequest as MetadataRequest, pb_d_NeighborServer as NeighborServer, pb_d_OpenRoomRequest as OpenRoomRequest, pb_d_OpenRoomResponse as OpenRoomResponse, pb_d_OrderClause as OrderClause, pb_d_Organization as Organization, pb_d_OrganizationInfo as OrganizationInfo, pb_d_OrganizationMembership as OrganizationMembership, pb_d_OrganizationSpec as OrganizationSpec, pb_d_OrganizationUser as OrganizationUser, pb_d_PartnerSession as PartnerSession, pb_d_Pass as Pass, pb_d_Permission as Permission, pb_d_PhonemeDetail as PhonemeDetail, pb_d_PresenceInfo as PresenceInfo, pb_d_PresenceUpdate as PresenceUpdate, pb_d_Profile as Profile, pb_d_PronunciationAnalysisRequest as PronunciationAnalysisRequest, pb_d_PronunciationAnalysisResponse as PronunciationAnalysisResponse, pb_d_Quaternion as Quaternion, pb_d_RecordActionRequest as RecordActionRequest, pb_d_RecordFeedbackRequest as RecordFeedbackRequest, pb_d_RecordLogRequest as RecordLogRequest, pb_d_RegisterLighthouseServerRequest as RegisterLighthouseServerRequest, pb_d_RegisterLighthouseServerResponse as RegisterLighthouseServerResponse, pb_d_RegisterNeighborServerRequest as RegisterNeighborServerRequest, pb_d_RegisterNeighborServerResponse as RegisterNeighborServerResponse, pb_d_RemoveActivityFilesRequest as RemoveActivityFilesRequest, pb_d_RemoveChildrenRequest as RemoveChildrenRequest, pb_d_RemoveCloudFilesRequest as RemoveCloudFilesRequest, pb_d_RemoveOrganizationUserRequest as RemoveOrganizationUserRequest, pb_d_RemoveTagsRequest as RemoveTagsRequest, pb_d_ResolveAssetRequest as ResolveAssetRequest, pb_d_ResolveMediaRequest as ResolveMediaRequest, pb_d_ResolveMediaResponse as ResolveMediaResponse, pb_d_Role as Role, pb_d_RoomInfo as RoomInfo, pb_d_SearchCloudFilesRequest as SearchCloudFilesRequest, pb_d_SearchCloudFilesResponse as SearchCloudFilesResponse, pb_d_SearchImagesRequest as SearchImagesRequest, pb_d_SearchImagesResponse as SearchImagesResponse, pb_d_SearchMemberOrganizationsRequest as SearchMemberOrganizationsRequest, pb_d_SearchMemberOrganizationsResponse as SearchMemberOrganizationsResponse, pb_d_SetActivityTranscriptRequest as SetActivityTranscriptRequest, pb_d_SetDeviceCommandRequest as SetDeviceCommandRequest, pb_d_SetDevicePropertiesRequest as SetDevicePropertiesRequest, pb_d_SetEntityPropertiesRequest as SetEntityPropertiesRequest, pb_d_SetLessonContextRequest as SetLessonContextRequest, pb_d_SetLessonContextResponse as SetLessonContextResponse, pb_d_SetOrganizationMembershipRequest as SetOrganizationMembershipRequest, pb_d_Speaker as Speaker, pb_d_Speech as Speech, pb_d_SpeechFileSpec as SpeechFileSpec, pb_d_SpeechMark as SpeechMark, pb_d_SpeechMarks as SpeechMarks, pb_d_SpeechSegment as SpeechSegment, pb_d_SubmitCommunityCategoryRequest as SubmitCommunityCategoryRequest, pb_d_SynthesizeSpeechRequest as SynthesizeSpeechRequest, pb_d_SynthesizeSpeechResponse as SynthesizeSpeechResponse, pb_d_SynthesizeTranscriptRequest as SynthesizeTranscriptRequest, pb_d_SynthesizeTranscriptResponse as SynthesizeTranscriptResponse, pb_d_Tag as Tag, pb_d_TagFilter as TagFilter, pb_d_TagGroup as TagGroup, pb_d_TextSearch as TextSearch, pb_d_ToKtxParameters as ToKtxParameters, pb_d_ToKtxRequest as ToKtxRequest, pb_d_ToKtxResponse as ToKtxResponse, pb_d_TranscodeImageRequest as TranscodeImageRequest, pb_d_TranscodeImageResponse as TranscodeImageResponse, pb_d_TranscodeImageSpec as TranscodeImageSpec, pb_d_TranscodeVideoRequest as TranscodeVideoRequest, pb_d_TranscodeVideoResponse as TranscodeVideoResponse, pb_d_TranscodeVideoResult as TranscodeVideoResult, pb_d_TranscodeVideoTask as TranscodeVideoTask, pb_d_Transcript as Transcript, pb_d_TranscriptSegment as TranscriptSegment, pb_d_TransformMediaRequest as TransformMediaRequest, pb_d_TransformMediaResponse as TransformMediaResponse, pb_d_TranslationLookupRequest as TranslationLookupRequest, pb_d_TranslationLookupResponse as TranslationLookupResponse, pb_d_TranslationRequest as TranslationRequest, pb_d_TranslationResponse as TranslationResponse, pb_d_TranslationSpec as TranslationSpec, pb_d_TranslationUpdateRequest as TranslationUpdateRequest, pb_d_UploadManifest as UploadManifest, pb_d_User as User, pb_d_UserInterfaceFeatures as UserInterfaceFeatures, pb_d_Vector3 as Vector3, pb_d_WifiAccessPoint as WifiAccessPoint, pb_d_WifiAccessPointInfo as WifiAccessPointInfo };
}

declare const Hostname = "avnfs.com";
declare const UrlPrefix = "https://avnfs.com";
declare const DuplicateUploadEventType = "duplicate";
declare const TypeQueryParam = "type";
declare const SizeQueryParam = "size";
declare const NameQueryParam = "name";
declare const MaxSinglePartUploadSizeBytes = 5368709120;
type FileSpec = {
    hash: string;
    sizeBytes: number;
    mediaType: string;
    fileName?: string;
};
declare function isValidUrl(url: URL): boolean;
declare function decodeUrl(url: URL): FileSpec;
declare function encodeUrl(spec: FileSpec): URL;
declare function updateFilename(url: URL, name: string | undefined): URL;
declare function uploadBuffer(buffer: BufferSource, ConnectServices: ConnectServices, auth: Authorization, mediaType: string, fileName?: string | undefined, progressCallback?: ((event: ProgressEvent) => any) | undefined, signal?: AbortSignal | undefined): Promise<URL>;
declare function uploadFilePath(path: string, Connect: ConnectServices, auth: Authorization, mediaType: string, fileName?: string | undefined, progressCallback?: ((event: ProgressEvent) => any) | undefined, signal?: AbortSignal | undefined): Promise<URL>;
declare function uploadFile(file: File, hash: string | undefined, ConnectServices: ConnectServices, auth: Authorization, mediaTypeOverride?: string | undefined, fileNameOverride?: string | undefined, progressCallback?: ((event: ProgressEvent) => any) | undefined, signal?: AbortSignal | undefined): Promise<URL>;

declare const avnfsClient_d_DuplicateUploadEventType: typeof DuplicateUploadEventType;
type avnfsClient_d_FileSpec = FileSpec;
declare const avnfsClient_d_Hostname: typeof Hostname;
declare const avnfsClient_d_MaxSinglePartUploadSizeBytes: typeof MaxSinglePartUploadSizeBytes;
declare const avnfsClient_d_NameQueryParam: typeof NameQueryParam;
declare const avnfsClient_d_SizeQueryParam: typeof SizeQueryParam;
declare const avnfsClient_d_TypeQueryParam: typeof TypeQueryParam;
declare const avnfsClient_d_UrlPrefix: typeof UrlPrefix;
declare const avnfsClient_d_decodeUrl: typeof decodeUrl;
declare const avnfsClient_d_encodeUrl: typeof encodeUrl;
declare const avnfsClient_d_isValidUrl: typeof isValidUrl;
declare const avnfsClient_d_updateFilename: typeof updateFilename;
declare const avnfsClient_d_uploadBuffer: typeof uploadBuffer;
declare const avnfsClient_d_uploadFile: typeof uploadFile;
declare const avnfsClient_d_uploadFilePath: typeof uploadFilePath;
declare namespace avnfsClient_d {
  export { avnfsClient_d_DuplicateUploadEventType as DuplicateUploadEventType, avnfsClient_d_Hostname as Hostname, avnfsClient_d_MaxSinglePartUploadSizeBytes as MaxSinglePartUploadSizeBytes, avnfsClient_d_NameQueryParam as NameQueryParam, avnfsClient_d_SizeQueryParam as SizeQueryParam, avnfsClient_d_TypeQueryParam as TypeQueryParam, avnfsClient_d_UrlPrefix as UrlPrefix, avnfsClient_d_decodeUrl as decodeUrl, avnfsClient_d_encodeUrl as encodeUrl, avnfsClient_d_isValidUrl as isValidUrl, avnfsClient_d_updateFilename as updateFilename, avnfsClient_d_uploadBuffer as uploadBuffer, avnfsClient_d_uploadFile as uploadFile, avnfsClient_d_uploadFilePath as uploadFilePath };
  export type { avnfsClient_d_FileSpec as FileSpec };
}

declare function isTerminal(state: OperationState): boolean;

declare const jobsClient_d_isTerminal: typeof isTerminal;
declare namespace jobsClient_d {
  export {
    jobsClient_d_isTerminal as isTerminal,
  };
}

declare const GenericMediaType = "application/octet-stream";
declare function guessMimeTypeForFile(ConnectServices: ConnectServices, file: File): Promise<string | undefined>;
declare function guessMimeTypeForExtension(ConnectServices: ConnectServices, extension: string): Promise<string | undefined>;
declare function iconForMediaType(mediaType: string): URL;

declare const mediaUtilsClient_d_GenericMediaType: typeof GenericMediaType;
declare const mediaUtilsClient_d_guessMimeTypeForExtension: typeof guessMimeTypeForExtension;
declare const mediaUtilsClient_d_guessMimeTypeForFile: typeof guessMimeTypeForFile;
declare const mediaUtilsClient_d_iconForMediaType: typeof iconForMediaType;
declare namespace mediaUtilsClient_d {
  export {
    mediaUtilsClient_d_GenericMediaType as GenericMediaType,
    mediaUtilsClient_d_guessMimeTypeForExtension as guessMimeTypeForExtension,
    mediaUtilsClient_d_guessMimeTypeForFile as guessMimeTypeForFile,
    mediaUtilsClient_d_iconForMediaType as iconForMediaType,
  };
}

declare function base64UintArrayToBase64UrlHashString(ua: Uint8Array): string;
declare function base64ArrayBufferToBase64UrlHashString(ab: ArrayBuffer): string;
declare function base64UrlHashForArrayBuffer(buffer: BufferSource, signal?: AbortSignal | undefined): Promise<string>;
declare function base64UrlHashForFile(file: File, signal?: AbortSignal | undefined): Promise<string>;
declare function base64UrlHashForFilePath(path: string): Promise<string>;

declare const cryptoUtilsClient_d_base64ArrayBufferToBase64UrlHashString: typeof base64ArrayBufferToBase64UrlHashString;
declare const cryptoUtilsClient_d_base64UintArrayToBase64UrlHashString: typeof base64UintArrayToBase64UrlHashString;
declare const cryptoUtilsClient_d_base64UrlHashForArrayBuffer: typeof base64UrlHashForArrayBuffer;
declare const cryptoUtilsClient_d_base64UrlHashForFile: typeof base64UrlHashForFile;
declare const cryptoUtilsClient_d_base64UrlHashForFilePath: typeof base64UrlHashForFilePath;
declare namespace cryptoUtilsClient_d {
  export {
    cryptoUtilsClient_d_base64ArrayBufferToBase64UrlHashString as base64ArrayBufferToBase64UrlHashString,
    cryptoUtilsClient_d_base64UintArrayToBase64UrlHashString as base64UintArrayToBase64UrlHashString,
    cryptoUtilsClient_d_base64UrlHashForArrayBuffer as base64UrlHashForArrayBuffer,
    cryptoUtilsClient_d_base64UrlHashForFile as base64UrlHashForFile,
    cryptoUtilsClient_d_base64UrlHashForFilePath as base64UrlHashForFilePath,
  };
}

declare const Reset = "\u001B[0m";
declare const Bright = "\u001B[1m";
declare const Dim = "\u001B[2m";
declare const Underscore = "\u001B[4m";
declare const Blink = "\u001B[5m";
declare const Reverse = "\u001B[7m";
declare const Hidden = "\u001B[8m";
declare const FgBlack = "\u001B[30m";
declare const FgRed = "\u001B[31m";
declare const FgGreen = "\u001B[32m";
declare const FgYellow = "\u001B[33m";
declare const FgBlue = "\u001B[34m";
declare const FgMagenta = "\u001B[35m";
declare const FgCyan = "\u001B[36m";
declare const FgWhite = "\u001B[37m";
declare const FgGray = "\u001B[90m";
declare const BgBlack = "\u001B[40m";
declare const BgRed = "\u001B[41m";
declare const BgGreen = "\u001B[42m";
declare const BgYellow = "\u001B[43m";
declare const BgBlue = "\u001B[44m";
declare const BgMagenta = "\u001B[45m";
declare const BgCyan = "\u001B[46m";
declare const BgWhite = "\u001B[47m";
declare const BgGray = "\u001B[100m";

declare const consoleUtilsClient_d_BgBlack: typeof BgBlack;
declare const consoleUtilsClient_d_BgBlue: typeof BgBlue;
declare const consoleUtilsClient_d_BgCyan: typeof BgCyan;
declare const consoleUtilsClient_d_BgGray: typeof BgGray;
declare const consoleUtilsClient_d_BgGreen: typeof BgGreen;
declare const consoleUtilsClient_d_BgMagenta: typeof BgMagenta;
declare const consoleUtilsClient_d_BgRed: typeof BgRed;
declare const consoleUtilsClient_d_BgWhite: typeof BgWhite;
declare const consoleUtilsClient_d_BgYellow: typeof BgYellow;
declare const consoleUtilsClient_d_Blink: typeof Blink;
declare const consoleUtilsClient_d_Bright: typeof Bright;
declare const consoleUtilsClient_d_Dim: typeof Dim;
declare const consoleUtilsClient_d_FgBlack: typeof FgBlack;
declare const consoleUtilsClient_d_FgBlue: typeof FgBlue;
declare const consoleUtilsClient_d_FgCyan: typeof FgCyan;
declare const consoleUtilsClient_d_FgGray: typeof FgGray;
declare const consoleUtilsClient_d_FgGreen: typeof FgGreen;
declare const consoleUtilsClient_d_FgMagenta: typeof FgMagenta;
declare const consoleUtilsClient_d_FgRed: typeof FgRed;
declare const consoleUtilsClient_d_FgWhite: typeof FgWhite;
declare const consoleUtilsClient_d_FgYellow: typeof FgYellow;
declare const consoleUtilsClient_d_Hidden: typeof Hidden;
declare const consoleUtilsClient_d_Reset: typeof Reset;
declare const consoleUtilsClient_d_Reverse: typeof Reverse;
declare const consoleUtilsClient_d_Underscore: typeof Underscore;
declare namespace consoleUtilsClient_d {
  export {
    consoleUtilsClient_d_BgBlack as BgBlack,
    consoleUtilsClient_d_BgBlue as BgBlue,
    consoleUtilsClient_d_BgCyan as BgCyan,
    consoleUtilsClient_d_BgGray as BgGray,
    consoleUtilsClient_d_BgGreen as BgGreen,
    consoleUtilsClient_d_BgMagenta as BgMagenta,
    consoleUtilsClient_d_BgRed as BgRed,
    consoleUtilsClient_d_BgWhite as BgWhite,
    consoleUtilsClient_d_BgYellow as BgYellow,
    consoleUtilsClient_d_Blink as Blink,
    consoleUtilsClient_d_Bright as Bright,
    consoleUtilsClient_d_Dim as Dim,
    consoleUtilsClient_d_FgBlack as FgBlack,
    consoleUtilsClient_d_FgBlue as FgBlue,
    consoleUtilsClient_d_FgCyan as FgCyan,
    consoleUtilsClient_d_FgGray as FgGray,
    consoleUtilsClient_d_FgGreen as FgGreen,
    consoleUtilsClient_d_FgMagenta as FgMagenta,
    consoleUtilsClient_d_FgRed as FgRed,
    consoleUtilsClient_d_FgWhite as FgWhite,
    consoleUtilsClient_d_FgYellow as FgYellow,
    consoleUtilsClient_d_Hidden as Hidden,
    consoleUtilsClient_d_Reset as Reset,
    consoleUtilsClient_d_Reverse as Reverse,
    consoleUtilsClient_d_Underscore as Underscore,
  };
}

declare function urlIfValid(url: string | undefined): URL | undefined;

declare const httpUtilsClient_d_urlIfValid: typeof urlIfValid;
declare namespace httpUtilsClient_d {
  export {
    httpUtilsClient_d_urlIfValid as urlIfValid,
  };
}

declare function delay(ms: number): Promise<unknown>;

declare const utilsClient_d_delay: typeof delay;
declare namespace utilsClient_d {
  export {
    utilsClient_d_delay as delay,
  };
}

interface WifiQrNetwork {
    ssid: string;
    encryption: WifiEncryption;
    password?: string;
    username?: string;
    phase2?: WifiPhase2;
    hidden?: boolean;
    macRandomisation?: boolean;
    ipAddress?: string;
    gateway?: string;
    prefixLength?: number | string;
    dns?: string;
}
declare function formatWifiQrText(network: WifiQrNetwork): string;
declare function wifiQrTextForAccessPoint(accessPoint: WifiAccessPoint): string;
declare function wifiQrSupported(accessPoint: WifiAccessPoint): boolean;

type wifiQrClient_d_WifiQrNetwork = WifiQrNetwork;
declare const wifiQrClient_d_formatWifiQrText: typeof formatWifiQrText;
declare const wifiQrClient_d_wifiQrSupported: typeof wifiQrSupported;
declare const wifiQrClient_d_wifiQrTextForAccessPoint: typeof wifiQrTextForAccessPoint;
declare namespace wifiQrClient_d {
  export { wifiQrClient_d_formatWifiQrText as formatWifiQrText, wifiQrClient_d_wifiQrSupported as wifiQrSupported, wifiQrClient_d_wifiQrTextForAccessPoint as wifiQrTextForAccessPoint };
  export type { wifiQrClient_d_WifiQrNetwork as WifiQrNetwork };
}

export { avnfsClient_d as Avnfs, ConnectServices, consoleUtilsClient_d as ConsoleUtils, cryptoUtilsClient_d as CryptoUtils, GwebAlphaUrl, GwebUrl, httpUtilsClient_d as HttpUtils, jobsClient_d as Jobs, mediaUtilsClient_d as MediaUtils, pb_d as PB, UserJwtRefreshMarginSeconds, utilsClient_d as Utils, wifiQrClient_d as WifiQr, createUserJwtInterceptor, jwtExpiry, jwtNeedsRefresh };
export type { ConnectServicesOptions, UserJwtProvider };
